<?php
session_start();
require_once "db.php";

header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "message" => "Not logged in"]);
    exit();
}

$action = $_POST['action'] ?? '';

if ($action === 'upgrade') {
    $stmt = $pdo->prepare("UPDATE users SET is_premium = 1 WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $_SESSION['is_premium'] = 1;
    echo json_encode(["success" => true, "message" => "🎉 You are now a Premium member!"]);
} elseif ($action === 'unsubscribe') {
    $stmt = $pdo->prepare("UPDATE users SET is_premium = 0 WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $_SESSION['is_premium'] = 0;
    echo json_encode(["success" => true, "message" => "✅ You have unsubscribed from Premium."]);
} else {
    echo json_encode(["success" => false, "message" => "Invalid action"]);
}
