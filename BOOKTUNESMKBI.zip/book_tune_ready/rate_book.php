<?php
session_start();
require_once "db.php";

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "message" => "You must be logged in to rate."]);
    exit;
}

$userId = $_SESSION['user_id'];
$bookId = $_POST['book_id'] ?? 0;
$rating = $_POST['rating'] ?? 0;

if (!$bookId || !$rating || $rating < 1 || $rating > 5) {
    echo json_encode(["success" => false, "message" => "Invalid rating."]);
    exit;
}

// Insert or update rating
$stmt = $pdo->prepare("INSERT INTO ratings (user_id, book_id, rating) 
                       VALUES (?, ?, ?)
                       ON DUPLICATE KEY UPDATE rating = VALUES(rating), created_at = CURRENT_TIMESTAMP");
$stmt->execute([$userId, $bookId, $rating]);

echo json_encode(["success" => true, "message" => "Your rating has been saved!"]);
