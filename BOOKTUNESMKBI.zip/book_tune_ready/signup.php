<?php
session_start();
require_once "db.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    $password = $_POST["password"];
    $confirm_password = $_POST["confirm_password"];

    // Basic validation
    if ($password !== $confirm_password) {
        $message = "Passwords do not match.";
    } elseif (strlen($username) < 3 || strlen($password) < 4) {
        $message = "Username or password too short.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Invalid email format.";
    } else {
        // Check if username or email already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->fetch()) {
            $message = "Username or email already taken.";
        } else {
            // Hash password and insert
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, is_premium) VALUES (?, ?, ?, 0)");
            $stmt->execute([$username, $email, $hashed_password]);
            
            $_SESSION["user_id"] = $pdo->lastInsertId();
            $_SESSION["username"] = $username;
            $_SESSION["is_premium"] = 0;
            header("Location: index.php");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Sign Up - Book-Tune</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@500;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
/* Design Variables */
:root {
    --bg: #0b0f14;
    --panel: #10151d;
    --panel-2: #0f141b;
    --border: #1a2430;
    --text: #e7edf6;
    --text-muted: #a0a8b4;
    --brand: #7aa2ff;
}

/* General Styles */
body {
    margin: 0;
    font-family: 'Inter', sans-serif;
    background: var(--bg);
    color: var(--text);
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
    background: url('assets/login-bg.jpg') no-repeat center center/cover;
}

.overlay {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.6);
}

.signup-container {
    position: relative;
    z-index: 2;
    background: var(--panel);
    padding: 2.5rem;
    border-radius: 12px;
    width: 100%;
    max-width: 400px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.4);
    border: 1px solid var(--border);
    text-align: center;
}

.welcome-text {
    font-size: 1.8rem;
    font-weight: 800;
    color: var(--brand);
    margin-bottom: 0.5rem;
}

.subtitle {
    color: var(--text-muted);
    font-size: 1rem;
    margin-bottom: 2rem;
}

h2 {
    text-align: center;
    margin-bottom: 1rem;
}

form {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

input {
    width: 100%;
    padding: 0.8rem;
    border-radius: 8px;
    border: 1px solid var(--border);
    background: var(--panel-2);
    color: var(--text);
    transition: border-color 0.3s;
}

input:focus {
    outline: none;
    border-color: var(--brand);
}

button {
    width: 100%;
    padding: 0.8rem;
    border-radius: 8px;
    border: none;
    background: var(--brand);
    color: #fff;
    font-size: 1rem;
    cursor: pointer;
    font-weight: 700;
    transition: background-color 0.3s;
}

button:hover {
    background: #5e8cff;
}

.alert {
    background: rgba(255,0,0,0.2);
    padding: 0.8rem;
    border-radius: 6px;
    margin-bottom: 1rem;
    text-align: center;
}

.login-link {
    text-align: center;
    font-size: 0.9rem;
    margin-top: 1.5rem;
}

.login-link a {
    color: var(--brand);
    text-decoration: none;
    font-weight: 600;
}

.login-link a:hover {
    text-decoration: underline;
}
</style>
</head>
<body>
<div class="overlay"></div>
<div class="signup-container">
    <div class="welcome-text">Welcome to Book-Tune</div>
    <div class="subtitle">Create a new account</div>
    <?php if ($message): ?>
        <div class="alert"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
        <button type="submit">Create Account</button>
    </form>
    <div class="login-link">
        Already have an account? <a href="login.php">Log In</a>
    </div>
</div>
</body>
</html>