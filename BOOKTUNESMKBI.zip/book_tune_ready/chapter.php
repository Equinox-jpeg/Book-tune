<?php
session_start();
require_once "db.php";

// Helper: cover src
function bt_cover_src($val) {
    return (preg_match('/^https?:\\/\\//', $val) ? $val : 'covers/' . htmlspecialchars($val));
}

// Default avatar
$defaultAvatar = "assets/default-profile.png";
if (isset($_SESSION['user_id'])) {
    $possibleAvatar = "uploads/profile_" . $_SESSION['user_id'] . ".png";
    $profileImage = file_exists($possibleAvatar) ? $possibleAvatar : $defaultAvatar;
} else {
    $profileImage = $defaultAvatar;
}

// Get chapter
$chapterId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT c.*, b.title AS book_title, b.is_premium 
                       FROM chapters c
                       JOIN books b ON c.book_id = b.id
                       WHERE c.id = ?");
$stmt->execute([$chapterId]);
$chapter = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$chapter) {
    die("Chapter not found.");
}

// ✅ Premium lock check
if ($chapter['is_premium'] == 1) {
    if (!isset($_SESSION['user_id']) || $_SESSION['is_premium'] != 1) {
        header("Location: premium.php?locked=1");
        exit;
    }
}

// Fetch chapter pages
$stmt = $pdo->prepare("SELECT * FROM chapter_pages WHERE chapter_id = ? ORDER BY page_number ASC");
$stmt->execute([$chapterId]);
$pages = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Log reading progress
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("INSERT INTO read_history (user_id, book_id, chapter_id, read_at)
                           VALUES (?, ?, ?, NOW())
                           ON DUPLICATE KEY UPDATE read_at = NOW()");
    $stmt->execute([$_SESSION['user_id'], $chapter['book_id'], $chapter['id']]);
}

// Previous & Next chapters
$stmt = $pdo->prepare("SELECT id, title FROM chapters WHERE book_id = ? AND id < ? ORDER BY id DESC LIMIT 1");
$stmt->execute([$chapter['book_id'], $chapter['id']]);
$prevChapter = $stmt->fetch(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("SELECT id, title FROM chapters WHERE book_id = ? AND id > ? ORDER BY id ASC LIMIT 1");
$stmt->execute([$chapter['book_id'], $chapter['id']]);
$nextChapter = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($chapter['book_title']) ?> - Ch. <?= htmlspecialchars($chapter['title']) ?> | Book-Tune</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@500;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<!-- Sidebar -->
<aside class="bt-sidebar" id="sidebar">
    <div class="bt-sidebar__brand">
        Menu
        <button id="closeSidebar" class="bt-sidebar__toggle"><i class="fas fa-chevron-left"></i></button>
    </div>

    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="profile.php" class="sidebar-profile">
            <img src="<?= $profileImage ?>" alt="Profile" class="sidebar-avatar">
            <span class="sidebar-username"><?= htmlspecialchars($_SESSION['username']) ?></span>
        </a>
    <?php endif; ?>

    <nav class="bt-nav">
        <a href="index.php" class="bt-nav__item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="genres.php" class="bt-nav__item"><i class="fas fa-th-large"></i><span>Genres</span></a>
        <a href="premium.php" class="bt-nav__item"><i class="fas fa-crown"></i><span>Premium</span></a>
        <a href="upload.php" class="bt-nav__item"><i class="fas fa-upload"></i><span>Upload</span></a>
    </nav>
</aside>

<!-- Header -->
<header class="bt-header" id="topbar">
    <div class="bt-header__left">
        <button id="toggleSidebar" class="bt-sidebar__toggle"><i class="fas fa-bars"></i></button>
        <div class="bt-logo">BOOK-TUNE</div>
    </div>
    <nav class="bt-header__right">
        <?php if (isset($_SESSION['user_id'])): ?>
            <div class="user-menu">
                <img src="<?= $profileImage ?>" alt="Profile" class="user-avatar">
                <span class="username"><?= htmlspecialchars($_SESSION['username']) ?></span>
                <a href="logout.php" class="bt-btn bt-btn--ghost">Logout</a>
            </div>
        <?php else: ?>
            <a class="bt-btn bt-btn--ghost" href="login.php">Login</a>
            <a class="bt-btn bt-btn--ghost" href="signup.php">Sign Up</a>
            <a class="bt-btn bt-btn--gold" href="premium.php">Go Premium</a>
        <?php endif; ?>
    </nav>
</header>

<!-- Main -->
<main class="bt-main">
    <div class="chapter-header">
        <h1><?= htmlspecialchars($chapter['book_title']) ?> - <?= htmlspecialchars($chapter['title']) ?></h1>
        <div class="chapter-nav">
            <?php if ($prevChapter): ?>
                <a href="chapter.php?id=<?= $prevChapter['id'] ?>" class="bt-btn bt-btn--ghost">⬅ Prev</a>
            <?php endif; ?>
            <?php if ($nextChapter): ?>
                <a href="chapter.php?id=<?= $nextChapter['id'] ?>" class="bt-btn bt-btn--ghost">Next ➡</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="chapter-pages">
        <?php if ($pages): ?>
            <?php foreach ($pages as $pg): ?>
                <div class="chapter-page">
                    <img src="<?= bt_cover_src($pg['image_path']) ?>" alt="Page <?= $pg['page_number'] ?>">
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="no-pages">No pages uploaded for this chapter yet.</p>
        <?php endif; ?>
    </div>
</main>

<script>
// Sidebar toggle
document.getElementById('toggleSidebar').addEventListener('click', () => {
    document.getElementById('sidebar').classList.add('is-expanded');
});
document.getElementById('closeSidebar').addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('is-expanded');
});
</script>
</body>
</html>
