<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$message = "";
$isPremium = false;

// Get current premium status
$stmt = $pdo->prepare("SELECT is_premium FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();
if ($user) {
    $isPremium = (bool)$user['is_premium'];
}

// Handle subscribe
if (isset($_POST['subscribe'])) {
    $pdo->prepare("UPDATE users SET is_premium = 1 WHERE id = ?")->execute([$_SESSION['user_id']]);
    $isPremium = true;
    $message = "🎉 You are now a Premium member!";
}

// Handle unsubscribe
if (isset($_POST['unsubscribe'])) {
    $pdo->prepare("UPDATE users SET is_premium = 0 WHERE id = ?")->execute([$_SESSION['user_id']]);
    $isPremium = false;
    $message = "✅ You have unsubscribed from Premium.";
}

// Cover helper
function bt_cover_src($val) {
    return (preg_match('/^https?:\\/\\//', $val) ? $val : 'covers/' . htmlspecialchars($val));
}

// Default avatar
$defaultAvatar = "assets/default-profile.png";
if (isset($_SESSION['user_id'])) {
    // Corrected logic to use session data for the image path
    if (isset($_SESSION['profile_pic']) && !empty($_SESSION['profile_pic'])) {
        $profileImage = htmlspecialchars($_SESSION['profile_pic']);
    } else {
        $profileImage = $defaultAvatar;
    }
} else {
    $profileImage = $defaultAvatar;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Premium - Book-Tune</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@500;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
/* --- Added/Corrected CSS for header spacing --- */
.user-menu {
    display: flex;
    align-items: center;
    gap: 12px;
}
.user-profile-link {
    display: flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    color: var(--text);
    transition: opacity 0.2s;
}
.user-profile-link:hover {
    opacity: 0.8;
}
.user-avatar {
    width: 32px;
    height: 32px;
    border-radius: 999px;
    object-fit: cover;
}
/* --- Other page styles --- */
.premium-section {
    max-width: 600px;
    margin: 50px auto;
    padding: 0 18px;
    text-align: center;
}
.premium-card {
    background: var(--panel, #0f141b);
    border: 1px solid var(--border, #1a2430);
    border-radius: 14px;
    padding: 25px;
    box-shadow: 0 8px 30px rgba(0,0,0,0.35);
}
.premium-card h1 {
    font-size: 1.8rem;
    margin-bottom: 10px;
}
.premium-card p {
    color: var(--muted, #9aa8bb);
    margin-bottom: 18px;
}
.premium-card ul {
    list-style: none;
    padding: 0;
    text-align: left;
    margin-bottom: 20px;
}
.premium-card ul li {
    margin-bottom: 10px;
    font-size: 0.95rem;
}
.premium-card button {
    padding: 10px 20px;
    font-size: 1rem;
    border-radius: 8px;
    border: none;
    cursor: pointer;
}
.subscribe-btn {
    background: var(--brand, #7aa2ff);
    color: white;
}
.unsubscribe-btn {
    background: #ff5e5e;
    color: white;
}
.notification {
    background: var(--brand-2, #ff7ac6);
    padding: 10px;
    margin-bottom: 15px;
    border-radius: 8px;
    font-weight: 600;
    animation: fadeOut 0.5s ease-out 2.5s forwards;
}
@keyframes fadeOut {
    to { opacity: 0; visibility: hidden; }
}
</style>
</head>
<body class="<?= isset($_SESSION['user_id']) ? 'logged-in' : '' ?>">

<aside class="bt-sidebar" id="sidebar">
    <div class="bt-sidebar__brand">
        Menu
        <button id="closeSidebar" class="bt-sidebar__toggle">
            <i class="fas fa-chevron-left"></i>
        </button>
    </div>

    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="profile.php" class="sidebar-profile">
            <img src="<?= $profileImage ?>" alt="Profile" class="sidebar-avatar">
            <span class="sidebar-username"><?= htmlspecialchars($_SESSION['username']) ?></span>
        </a>
    <?php endif; ?>

    <button id="sidebarCloseInside" class="bt-sidebar__close-top">
        <i class="fas fa-arrow-left"></i>
    </button>

    <nav class="bt-nav">
        <a href="index.php" class="bt-nav__item"><i class="fas fa-home"></i><span class="bt-nav__text">Home</span></a>
        <a href="genres.php" class="bt-nav__item"><i class="fas fa-th-large"></i><span class="bt-nav__text">Genres</span></a>
        <a href="index.php#popular" class="bt-nav__item scroll-link"><i class="fas fa-fire"></i><span class="bt-nav__text">Popular</span></a>
        <a href="index.php#new-releases" class="bt-nav__item scroll-link"><i class="fas fa-star"></i><span class="bt-nav__text">New Releases</span></a>
        <a href="premium.php" class="bt-nav__item"><i class="fas fa-crown"></i><span class="bt-nav__text">Premium</span></a>
        <a href="upload.php" class="bt-nav__item"><i class="fas fa-upload"></i><span class="bt-nav__text">Upload</span></a>
    </nav>
</aside>

<header class="bt-header" id="topbar">
    <div class="bt-header__left">
        <button id="toggleSidebar" class="bt-sidebar__toggle"><i class="fas fa-bars"></i></button>
        <div class="bt-logo">BOOK-TUNE</div>
        <form class="bt-search" method="GET" action="search.php">
            <input type="text" name="q" placeholder="Search books..." required>
            <button type="submit" class="bt-btn bt-btn--search"><i class="fas fa-search"></i></button>
        </form>
    </div>
    <nav class="bt-header__right">
        <?php if (isset($_SESSION['user_id'])): ?>
            <div class="user-menu">
                <a href="profile.php" class="user-profile-link">
                    <img src="<?= $profileImage ?>" alt="Profile" class="user-avatar">
                    <span class="username"><?= htmlspecialchars($_SESSION['username']) ?></span>
                </a>
                <a href="logout.php" class="bt-btn bt-btn--ghost">Logout</a>
            </div>
        <?php else: ?>
            <a class="bt-btn bt-btn--ghost" href="login.php">Login</a>
            <a class="bt-btn bt-btn--ghost" href="signup.php">Sign Up</a>
            <a class="bt-btn bt-btn--gold" href="premium.php">Go Premium</a>
        <?php endif; ?>
    </nav>
</header>

<main class="bt-main">
    <div class="premium-section">
        <?php if ($message): ?>
            <div class="notification"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <div class="premium-card">
            <h1>Premium Membership</h1>
            <p>Unlock exclusive features and support the platform.</p>
            <ul>
                <li>🚀 Access to exclusive premium-only books</li>
                <li>🔒 More features coming soon...</li>
            </ul>
            <form method="POST">
                <?php if ($isPremium): ?>
                    <button type="submit" name="unsubscribe" class="unsubscribe-btn">Unsubscribe</button>
                <?php else: ?>
                    <button type="submit" name="subscribe" class="subscribe-btn">Subscribe Now</button>
                <?php endif; ?>
            </form>
        </div>
    </div>
</main>

<script>
// Sidebar toggle
document.getElementById('toggleSidebar').addEventListener('click', function() {
    document.getElementById('sidebar').classList.add('is-expanded');
});
document.getElementById('closeSidebar').addEventListener('click', function() {
    document.getElementById('sidebar').classList.remove('is-expanded');
});
document.getElementById('sidebarCloseInside').addEventListener('click', function() {
    document.getElementById('sidebar').classList.remove('is-expanded');
});

// Auto-hide notification
setTimeout(() => {
    const notif = document.querySelector('.notification');
    if (notif) notif.style.display = 'none';
}, 3000);
</script>

</body>
</html>