<?php
require_once "db.php";

/* helper to return usable cover paths */
function bt_cover_src($val) {
    $fallback = 'covers/placeholder.jpg';
    if (!is_string($val) || trim($val) === '') return $fallback;
    if (preg_match('~^https?://~i', $val)) return $val;
    $file = ltrim($val, '/');
    foreach (["covers/$file", $file] as $p) {
        if (is_file($p)) return $p;
    }
    return $fallback;
}

$genre = isset($_GET['genre']) ? trim($_GET['genre']) : 'all';
$offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 12;

if ($limit <= 0) $limit = 12;
if ($offset < 0) $offset = 0;

if (strtolower($genre) === 'all' || $genre === '') {
    $sql = "SELECT id, title, author, cover, rating, views FROM books ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
} else {
    $sql = "SELECT id, title, author, cover, rating, views FROM books WHERE category = :cat ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':cat', $genre, PDO::PARAM_STR);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
}

$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
$output = [];

foreach ($rows as $r) {
    $cover = bt_cover_src($r['cover']);
    $isLocal = !preg_match('~^https?://~i', $r['cover']);
    $output[] = [
        'id' => (int)$r['id'],
        'title' => $r['title'],
        'author' => $r['author'],
        'cover' => $cover,
        'cover_local' => $isLocal ? 1 : 0,
        'rating' => (float)$r['rating'],
        'views' => (int)$r['views'],
    ];
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode($output);
