<?php
session_start();
require_once "db.php";

// Redirect to login if user not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

try {
    // Set user as non-premium
    $stmt = $pdo->prepare("UPDATE users SET is_premium = 0 WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);

    // Update session
    $_SESSION['is_premium'] = 0;

    // Redirect with unsubscribed flag
    header("Location: premium.php?unsubscribed=1");
    exit();
} catch (Exception $e) {
    die("Error unsubscribing: " . $e->getMessage());
}
