<?php
require_once "db.php";

$section = isset($_GET['section']) ? $_GET['section'] : '';
$offset  = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
$limit   = 12;

switch ($section) {
    case 'recommended':
        $sql = "SELECT * FROM books ORDER BY RAND() LIMIT :limit OFFSET :offset";
        break;
    case 'new-releases':
        $sql = "SELECT * FROM books ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
        break;
    case 'popular':
        $sql = "SELECT * FROM books ORDER BY views DESC LIMIT :limit OFFSET :offset";
        break;
    default:
        echo json_encode([]);
        exit;
}

$stmt = $pdo->prepare($sql);
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: application/json');
echo json_encode($books);
