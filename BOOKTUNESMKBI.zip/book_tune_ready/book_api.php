<?php

function get_openlibrary_cover($title, $author) {
    $url = "https://openlibrary.org/search.json?" . http_build_query([
        'title' => $title,
        'author' => $author
    ]);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Book-Tune App/1.0 (contact@your-domain.com)');
    $response = curl_exec($ch);
    curl_close($ch);

    if (!$response) {
        return null;
    }

    $data = json_decode($response, true);

    if (empty($data['docs'])) {
        return null;
    }

    // Find the first document with a cover ID
    foreach ($data['docs'] as $doc) {
        if (!empty($doc['cover_i'])) {
            $cover_id = $doc['cover_i'];
            return "https://covers.openlibrary.org/b/id/{$cover_id}-M.jpg";
        }
    }

    return null;
}

?>