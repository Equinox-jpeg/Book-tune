<?php
session_start();
require_once "db.php";
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
$msg = "";
if($_SERVER['REQUEST_METHOD']==='POST'){
  $title = trim($_POST['title'] ?? '');
  $author = trim($_POST['author'] ?? '');
  $category = trim($_POST['category'] ?? '');
  $description = trim($_POST['description'] ?? '');
  $cover = trim($_POST['cover'] ?? '');
  $is_premium = isset($_POST['is_premium']) ? 1 : 0;
  if($title && $author && $category && $description && $cover){
    $stmt = $pdo->prepare("INSERT INTO books (title,author,description,category,cover,is_premium) VALUES (?,?,?,?,?,?)");
    $stmt->execute([$title,$author,$description,$category,$cover,$is_premium]);
    $msg = "Book added!";
  } else { $msg = "Please fill in all fields."; }
}
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Add Book - Book‑Tune</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css" /></head><body>
<header class="site-header"><h1 class="logo">📚 Book‑Tune</h1><a class="back-btn" href="index.php">← Back</a></header>
<?php if($msg): ?><div class="alert"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
<div class="card form modern">
<form method="POST"><div class="grid2">
<div class="row"><label>Title</label><input name="title" required></div>
<div class="row"><label>Author</label><input name="author" required></div>
<div class="row"><label>Category</label><input name="category" placeholder="Fantasy, Sci‑Fi, Romance…" required></div>
<div class="row full"><label>Description</label><textarea name="description" rows="6" required></textarea></div>
<div class="row"><label>Cover filename</label><input name="cover" placeholder="e.g. dune.jpg" required></div>
<div class="row"><label><input type="checkbox" name="is_premium"> Premium</label></div>
</div><button class="submit" type="submit">Add Book</button></form></div>
<footer class="site-footer"><p>© <?php echo date('Y'); ?> Book‑Tune</p></footer></body></html>
