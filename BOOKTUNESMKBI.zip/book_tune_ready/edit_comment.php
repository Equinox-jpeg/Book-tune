<?php
session_start();
require_once "db.php";

// Must be logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$commentId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$bookId = isset($_GET['book_id']) ? (int)$_GET['book_id'] : 0;

// Fetch comment
$stmt = $pdo->prepare("SELECT * FROM comments WHERE id = ?");
$stmt->execute([$commentId]);
$comment = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$comment) {
    die("Comment not found.");
}

// Check permissions
if ($comment['user_id'] != $_SESSION['user_id'] && ($_SESSION['is_admin'] ?? 0) != 1) {
    die("Permission denied.");
}

// Handle form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newComment = trim($_POST['comment']);
    if ($newComment !== "") {
        $stmt = $pdo->prepare("UPDATE comments SET comment = ?, created_at = NOW() WHERE id = ?");
        $stmt->execute([$newComment, $commentId]);

        header("Location: book.php?id=" . $bookId . "&edited=1");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Comment</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Edit Comment</h1>
    <form method="post">
        <textarea name="comment" required><?= htmlspecialchars($comment['comment']) ?></textarea><br>
        <button type="submit" class="bt-btn bt-btn--gold">Save Changes</button>
        <a href="book.php?id=<?= $bookId ?>" class="bt-btn bt-btn--ghost">Cancel</a>
    </form>
</body>
</html>
