<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['user_id'])) {
    $response = ["success" => false, "message" => "You must be logged in."];
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
        header("Content-Type: application/json");
        echo json_encode($response);
        exit;
    }
    die("You must be logged in.");
}

$user_id = $_SESSION['user_id'];
$book_id = isset($_POST['book_id']) ? intval($_POST['book_id']) : 0;

if (!$book_id) {
    $response = ["success" => false, "message" => "Invalid book."];
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
        header("Content-Type: application/json");
        echo json_encode($response);
        exit;
    }
    die("Invalid book.");
}

try {
    // Check if already in library
    $check = $pdo->prepare("SELECT id FROM library WHERE user_id = ? AND book_id = ?");
    $check->execute([$user_id, $book_id]);

    if ($check->fetch()) {
        // Remove if already exists (toggle behavior)
        $del = $pdo->prepare("DELETE FROM library WHERE user_id = ? AND book_id = ?");
        $del->execute([$user_id, $book_id]);
        $response = ["success" => true, "action" => "removed", "message" => "Removed from your library."];
    } else {
        // Insert new
        $stmt = $pdo->prepare("INSERT INTO library (user_id, book_id) VALUES (?, ?)");
        $stmt->execute([$user_id, $book_id]);
        $response = ["success" => true, "action" => "added", "message" => "Added to your library!"];
    }

    if (isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
        header("Content-Type: application/json");
        echo json_encode($response);
        exit;
    } else {
        header("Location: book.php?id=" . $book_id);
        exit;
    }
} catch (Exception $e) {
    $response = ["success" => false, "message" => "Database error."];
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
        header("Content-Type: application/json");
        echo json_encode($response);
        exit;
    }
    die("Database error.");
}
