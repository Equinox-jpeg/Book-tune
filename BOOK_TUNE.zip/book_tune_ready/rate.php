<?php
session_start();
require_once "db.php";

function wants_json(): bool {
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') return true;
    if (!empty($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) return true;
    return false;
}

if (!isset($_SESSION['user_id'])) {
    if (wants_json()) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['success'=>false,'message'=>'You must be logged in to rate.']);
        exit;
    }
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (wants_json()) {
        http_response_code(405);
        header('Content-Type: application/json');
        echo json_encode(['success'=>false,'message'=>'Method not allowed']);
        exit;
    }
    header('Location: index.php');
    exit;
}

$book_id = filter_input(INPUT_POST,'book_id',FILTER_VALIDATE_INT);
$rating  = filter_input(INPUT_POST,'rating',FILTER_VALIDATE_INT);

if (!$book_id || !$rating || $rating < 1 || $rating > 5) {
    if (wants_json()) {
        http_response_code(400);
        header('Content-Type: application/json');
        echo json_encode(['success'=>false,'message'=>'Invalid input']);
        exit;
    }
    $_SESSION['error'] = 'Invalid input';
    header('Location: book.php?id=' . ($book_id ?: ''));
    exit;
}

try {
    // make sure PDO throws exceptions
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Insert or update rating (unique key: user+book)
    $ins = $pdo->prepare("
        INSERT INTO ratings (user_id, book_id, rating)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE rating = VALUES(rating), created_at = CURRENT_TIMESTAMP
    ");
    $ins->execute([$_SESSION['user_id'], $book_id, $rating]);

    // Recalculate average and total
    $r = $pdo->prepare("SELECT IFNULL(ROUND(AVG(rating),2),0) AS avg_rating, COUNT(*) AS total FROM ratings WHERE book_id = ?");
    $r->execute([$book_id]);
    $row = $r->fetch(PDO::FETCH_ASSOC);
    $avg = isset($row['avg_rating']) ? (float)$row['avg_rating'] : 0.0;
    $total = isset($row['total']) ? (int)$row['total'] : 0;

    if (wants_json()) {
        header('Content-Type: application/json');
        echo json_encode(['success'=>true,'message'=>'Rating saved','avg'=>$avg,'total'=>$total]);
        exit;
    }

    $_SESSION['success'] = 'Rating saved';
    header('Location: book.php?id=' . $book_id);
    exit;

} catch (PDOException $e) {
    // don't leak stack trace in production — but helpful while debugging locally
    if (wants_json()) {
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(['success'=>false,'message'=>'DB error: '.$e->getMessage()]);
        exit;
    }
    $_SESSION['error'] = 'DB error: ' . $e->getMessage();
    header('Location: book.php?id=' . $book_id);
    exit;
}
