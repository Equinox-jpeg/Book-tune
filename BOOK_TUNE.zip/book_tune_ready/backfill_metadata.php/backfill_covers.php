<?php
// backfill_covers.php
// Run once to populate `books.cover` with covers from Open Library using title+author.
// Usage: php backfill_covers.php  OR http://yourdomain/backfill_covers.php

require_once 'db.php';

function http_get_json($url, $timeout = 8) {
    $opts = ['http' => ['method' => 'GET', 'timeout' => $timeout, 'header' => "User-Agent: BookTuneCoverBackfill/1.0\r\n"]];
    $ctx = stream_context_create($opts);
    $raw = @file_get_contents($url, false, $ctx);
    if ($raw === false) return null;
    $data = json_decode($raw, true);
    return $data ?: null;
}

function build_cover_url_from_doc($doc) {
    if (!is_array($doc)) return null;
    if (!empty($doc['cover_edition_key'])) {
        return "https://covers.openlibrary.org/b/olid/{$doc['cover_edition_key']}-L.jpg";
    }
    if (!empty($doc['isbn']) && is_array($doc['isbn'])) {
        $isbn = $doc['isbn'][0];
        return "https://covers.openlibrary.org/b/isbn/{$isbn}-L.jpg";
    }
    if (isset($doc['cover_i'])) {
        return "https://covers.openlibrary.org/b/id/{$doc['cover_i']}-L.jpg";
    }
    return null;
}

function resolve_cover_url($title, $author) {
    $qs = http_build_query(['title' => $title, 'author' => $author, 'limit' => 1]);
    $url = "https://openlibrary.org/search.json?$qs";
    $data = http_get_json($url);
    if (!$data || empty($data['docs'])) return null;
    return build_cover_url_from_doc($data['docs'][0]);
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt = $pdo->query("SELECT id, title, author, cover FROM books ORDER BY id");
$upd = $pdo->prepare("UPDATE books SET cover = :cover WHERE id = :id");

$total = 0; $updated = 0; $skipped = 0;

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $total++;
    $id = (int)$row['id'];
    $title = $row['title'] ?? '';
    $author = $row['author'] ?? '';
    $cover = $row['cover'] ?? '';
    if (preg_match('#^https?://#i', $cover)) {
        echo "[SKIP] #$id already URL\n";
        $skipped++;
        continue;
    }
    $url = resolve_cover_url($title, $author);
    if ($url) {
        $upd->execute([':cover'=>$url, ':id'=>$id]);
        echo "[OK]   #$id -> $url\n";
        $updated++;
    } else {
        echo "[MISS] #$id (no cover found)\n";
    }
    // be gentle to API
    usleep(250000);
}

echo \"\\nDone. Total: $total, Updated: $updated, Already URL: $skipped\\n\";
