<?php
session_start();
require_once "db.php";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Get user data
$stmt = $pdo->prepare("SELECT username, bio, profile_pic FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    header("Location: logout.php");
    exit;
}

// Default profile avatar
$defaultAvatar = "assets/default-profile.png";
$profileImage = $user['profile_pic'] && file_exists($user['profile_pic']) ? $user['profile_pic'] : $defaultAvatar;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Profile - Book-Tune</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* === Redesigned Dark Theme CSS (Fully self-contained) === */
        :root {
            --bg-primary: #080d15;
            --bg-secondary: #101620;
            --card-bg: #1c2433;
            --text-primary: #e8eef8;
            --text-secondary: #a0a8b4;
            --brand-color: #5d83ff;
            --brand-hover: #7a9aff;
            --border-color: #2e3b50;
            --brand-premium: #f3c74c;
            --shadow: 0 10px 40px rgba(0, 0, 0, 0.4);
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-primary);
            color: var(--text-primary);
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        
        a { text-decoration: none; color: inherit; }
        
        /* === Sidebar & Topbar Styles === */
        .bt-sidebar {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            width: 250px;
            background-color: var(--bg-secondary);
            border-right: 1px solid var(--border-color);
            padding: 25px 20px;
            display: flex;
            flex-direction: column;
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 100;
        }
        .bt-sidebar.is-expanded { transform: translateX(0); }
        .bt-sidebar__brand {
            font-weight: 800;
            font-size: 1.5rem;
            margin-bottom: 30px;
            color: var(--brand-color);
            position: relative;
        }
        .bt-sidebar__toggle {
            background: none;
            border: none;
            color: var(--text-secondary);
            font-size: 1.5rem;
            cursor: pointer;
            transition: color 0.2s;
        }
        .bt-sidebar #closeSidebar {
            position: absolute;
            top: 0;
            right: 0;
        }
        .bt-sidebar .sidebar-profile {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 10px 15px;
            margin-bottom: 25px;
            background: var(--card-bg);
            border-radius: 12px;
        }
        .bt-sidebar .sidebar-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--brand-color);
        }
        .bt-sidebar .sidebar-username { font-weight: 600; }
        .bt-nav { display: flex; flex-direction: column; gap: 10px; }
        .bt-nav__item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            color: var(--text-secondary);
            font-weight: 500;
            border-radius: 12px;
            transition: all 0.2s;
        }
        .bt-nav__item:hover {
            background-color: var(--brand-color);
            color: #fff;
        }
        .bt-header {
            position: sticky;
            top: 0;
            left: 0;
            right: 0;
            background-color: var(--bg-primary);
            border-bottom: 1px solid var(--border-color);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 50;
            box-shadow: 0 4px 10px var(--shadow);
        }
        .bt-header__left {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .bt-logo {
            color: var(--brand-color);
            font-size: 1.2rem;
            font-weight: 700;
            display: none;
        }
        .bt-search {
            position: relative;
            width: 100%;
            max-width: 350px;
            margin-left: 20px;
        }
        .bt-search input {
            width: 100%;
            padding: 10px 45px 10px 20px;
            border-radius: 50px;
            border: 1px solid var(--border-color);
            background: var(--bg-secondary);
            color: var(--text-primary);
            font-size: 1rem;
            transition: border-color 0.2s;
        }
        .bt-search input:focus { outline: none; border-color: var(--brand-color); }
        .bt-search button {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--text-secondary);
            font-size: 1rem;
            cursor: pointer;
        }
        .bt-header__right {
            display: flex;
            align-items: center;
            gap: 15px;
            /* Force content to the far right */
            justify-content: flex-end;
            margin-left: auto;
        }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .user-avatar { width: 35px; height: 35px; border-radius: 50%; object-fit: cover; }
        .username { font-weight: 600; color: var(--text-primary); }
        .bt-btn {
            padding: 12px 24px;
            border-radius: 50px;
            border: 1px solid var(--border-color);
            background: var(--card-bg);
            color: var(--text-primary);
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all .2s ease;
        }
        .bt-btn:hover { background: var(--brand-color); color:#fff; border-color: var(--brand-color); transform: translateY(-2px); }
        .bt-btn--primary { background: var(--brand-color); color: #fff; border: none; }
        .bt-btn--primary:hover { background: var(--brand-hover); }
        .bt-btn--gold { background: var(--brand-premium); color: var(--bg-primary); border: none; }
        .bt-btn--gold:hover { background: #ffd740; transform: translateY(-2px); }

        /* === Main Content Area and Form Styles === */
        .bt-main {
            padding: 40px 20px;
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: calc(100vh - 80px); /* Centers vertically */
        }
        
        @media (min-width: 768px) {
            .bt-main {
                margin: 40px auto 40px 280px;
                padding: 0 20px;
                min-height: calc(100vh - 120px);
            }
            .bt-sidebar { transform: translateX(0); }
            .bt-sidebar__toggle { display: none; }
            .bt-header__left { display: none; }
            .bt-header { left: 250px; width: calc(100% - 250px); }
            .bt-logo { display: block; }
        }

        .edit-profile-container {
            width: 100%;
            max-width: 600px;
            background: var(--card-bg);
            padding: 40px;
            border-radius: 16px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border-color);
        }
        .edit-profile-container h1 {
            font-size: 2.5rem;
            margin-top: 0;
            margin-bottom: 30px;
            font-weight: 800;
            text-align: center;
            color: var(--brand-color);
        }
        .form-group {
            margin-bottom: 25px;
        }
        .form-group label {
            display: block;
            margin-bottom: 10px;
            color: var(--text-secondary);
            font-weight: 600;
        }
        .form-group textarea,
        .form-group input[type="text"] {
            width: 100%;
            padding: 15px;
            border-radius: 12px;
            border: 1px solid var(--border-color);
            background: var(--bg-secondary);
            color: var(--text-primary);
            resize: vertical;
            min-height: 120px;
            font-size: 1rem;
            transition: border-color 0.2s;
        }
        .form-group input:focus, .form-group textarea:focus {
            outline: none;
            border-color: var(--brand-color);
            box-shadow: 0 0 0 3px rgba(93, 131, 255, 0.2);
        }
        .profile-pic-upload {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
            margin-top: 30px;
        }
        .profile-pic-upload img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid var(--brand-color);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
        }
        .file-input-wrapper {
            position: relative;
            display: inline-block;
        }
        .file-input-wrapper input[type="file"] {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            height: 100%;
            width: 100%;
            cursor: pointer;
        }
        .custom-file-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 20px;
            border-radius: 50px;
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: all .2s ease;
        }
        .custom-file-btn:hover {
            background: var(--brand-color);
            color: #fff;
            border-color: var(--brand-color);
        }
        .submit-btn {
            width: 100%;
            padding: 15px;
            font-size: 1.1rem;
            font-weight: 700;
            border-radius: 12px;
        }
        @media (min-width: 500px) {
            .profile-pic-upload {
                flex-direction: row;
                justify-content: center;
            }
        }
    </style>
</head>
<body>

<aside class="bt-sidebar" id="sidebar">
    <div class="bt-sidebar__brand">Menu</div>
    <button id="closeSidebar" class="bt-sidebar__toggle"><i class="fas fa-arrow-left"></i></button>

    <?php if (isset($_SESSION['user_id'])): ?>
    <a href="profile.php" class="sidebar-profile">
        <img src="<?= htmlspecialchars($profileImage) ?>" alt="Profile" class="sidebar-avatar">
        <span class="sidebar-username"><?= htmlspecialchars($user['username']) ?></span>
    </a>
    <?php endif; ?>

    <nav class="bt-nav">
        <a href="index.php" class="bt-nav__item"><i class="fas fa-home"></i><span class="bt-nav__text">Home</span></a>
        <a href="genres.php" class="bt-nav__item"><i class="fas fa-th-large"></i><span class="bt-nav__text">Genres</span></a>
        <a href="index.php#popular" class="bt-nav__item scroll-link"><i class="fas fa-fire"></i><span class="bt-nav__text">Popular</span></a>
        <a href="index.php#new-releases" class="bt-nav__item scroll-link"><i class="fas fa-star"></i><span class="bt-nav__text">New Releases</span></a>
        <a href="premium.php" class="bt-nav__item"><i class="fas fa-crown"></i><span class="bt-nav__text">Premium</span></a>
        <a href="upload.php" class="bt-nav__item"><i class="fas fa-upload"></i><span class="bt-nav__text">Upload</span></a>
        <a href="logout.php" class="bt-nav__item"><i class="fas fa-sign-out-alt"></i><span class="bt-nav__text">Logout</span></a>
    </nav>
</aside>

<header class="bt-header" id="topbar">
    <div class="bt-header__left">
        <button id="toggleSidebar" class="bt-sidebar__toggle"><i class="fas fa-bars"></i></button>
        <div class="bt-logo">BOOK-TUNE</div>
        <form class="bt-search" method="GET" action="search.php">
            <input type="text" name="q" placeholder="Search books..." required>
            <button type="submit" class="bt-btn bt-btn--search"><i class="fas fa-search"></i></button>
        </form>
    </div>

    <nav class="bt-header__right">
        <?php if (isset($_SESSION['user_id'])): ?>
            <div class="user-menu">
                <img src="<?= htmlspecialchars($profileImage) ?>" alt="Profile" class="user-avatar">
                <span class="username"><?= htmlspecialchars($user['username']) ?></span>
                <a href="logout.php" class="bt-btn bt-btn--ghost">Logout</a>
            </div>
        <?php else: ?>
            <a class="bt-btn bt-btn--ghost" href="login.php">Login</a>
            <a class="bt-btn bt-btn--ghost" href="signup.php">Sign Up</a>
            <a class="bt-btn bt-btn--gold" href="premium.php">Go Premium</a>
        <?php endif; ?>
    </nav>
</header>

<main class="bt-main">
    <div class="edit-profile-container">
        <h1>Edit Profile</h1>
        <form method="post" action="update_profile.php" enctype="multipart/form-data">
            <div class="form-group">
                <label for="bio">Bio</label>
                <textarea id="bio" name="bio" placeholder="Write about yourself..."><?= htmlspecialchars($user['bio']) ?></textarea>
            </div>

            <div class="form-group">
                <label>Profile Picture</label>
                <div class="profile-pic-upload">
                    <img src="<?= htmlspecialchars($profileImage) ?>" alt="Current Profile Picture">
                    <div class="file-input-wrapper">
                        <input type="file" name="profile_pic" id="profile_pic">
                        <label for="profile_pic" class="custom-file-btn"><i class="fas fa-upload"></i> Choose File</label>
                    </div>
                </div>
            </div>

            <button type="submit" class="bt-btn bt-btn--primary submit-btn">Save</button>
        </form>
    </div>
</main>

<script>
// Sidebar toggle logic
const sidebar = document.getElementById("sidebar");
const toggleBtn = document.getElementById("toggleSidebar");
const closeBtn = document.getElementById("closeSidebar");

if (sidebar && toggleBtn && closeBtn) {
    toggleBtn.addEventListener("click", () => {
        sidebar.classList.add("is-expanded");
    });
    closeBtn.addEventListener("click", () => {
        sidebar.classList.remove("is-expanded");
    });
    document.addEventListener("click", function(e) {
        if (sidebar.classList.contains("is-expanded") && !sidebar.contains(e.target) && e.target !== toggleBtn) {
            sidebar.classList.remove("is-expanded");
        }
    });
}

// Update custom file button text
const fileInput = document.getElementById('profile_pic');
const customFileBtn = document.querySelector('.custom-file-btn');

if (fileInput && customFileBtn) {
    fileInput.addEventListener('change', function() {
        if (this.files.length > 0) {
            customFileBtn.innerHTML = '<i class="fas fa-file-image"></i> ' + this.files[0].name;
        } else {
            customFileBtn.innerHTML = '<i class="fas fa-upload"></i> Choose File';
        }
    });
}
</script>
</body>
</html>