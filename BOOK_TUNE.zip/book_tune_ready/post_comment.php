<?php
session_start();
require_once "db.php";

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "message" => "You must be logged in to comment."]);
    exit;
}

$username = $_SESSION['username'];
$bookId = $_POST['book_id'] ?? 0;
$comment = trim($_POST['comment'] ?? '');

if (!$bookId || !$comment) {
    echo json_encode(["success" => false, "message" => "Comment cannot be empty."]);
    exit;
}

$stmt = $pdo->prepare("INSERT INTO comments (book_id, username, comment) VALUES (?, ?, ?)");
$stmt->execute([$bookId, $username, $comment]);

echo json_encode(["success" => true, "message" => "Comment posted successfully!"]);
