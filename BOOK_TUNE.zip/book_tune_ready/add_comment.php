<?php
session_start();
require_once "db.php";

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $bookId = $_POST['book_id'];
    $commentText = $_POST['comment'];
    $userId = $_SESSION['user_id'];

    // Validate input
    if (empty($bookId) || empty($commentText)) {
        header("Location: book.php?id=" . $bookId . "&error=1");
        exit();
    }

    try {
        // Use a prepared statement to prevent SQL injection
        $stmt = $pdo->prepare("INSERT INTO comments (book_id, user_id, comment, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->execute([$bookId, $userId, $commentText]);

        // Redirect back to the book page on success
        header("Location: book.php?id=" . $bookId . "&success=1");
        exit();
    } catch (PDOException $e) {
        // Redirect back with an error message
        header("Location: book.php?id=" . $bookId . "&error=1");
        exit();
    }
} else {
    // If not a POST request, redirect to the homepage
    header("Location: index.php");
    exit();
}
?>