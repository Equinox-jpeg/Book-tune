<?php
session_start();
require_once "db.php";

// Get user data if logged in
$user = null;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT username, profile_pic FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        $_SESSION['username'] = $user['username'];
    }
}

// Set the profile image path. Prioritize database value, fallback to default.
$defaultAvatar = "assets/default-profile.png";
$profileImage = ($user && !empty($user['profile_pic'])) ? $user['profile_pic'] : $defaultAvatar;

/**
 * Get the book cover URL.
 * It supports Open Library IDs, direct URLs, and local filenames.
 */
function bt_cover_src($cover_value) {
    if (empty($cover_value)) {
        return "assets/placeholder.png"; // Fallback to a placeholder
    }
    // Check if it's a full URL (e.g., starts with http)
    if (filter_var($cover_value, FILTER_VALIDATE_URL)) {
        return htmlspecialchars($cover_value);
    }
    // Check if it's an Open Library ID.
    // The Open Library covers API supports numeric IDs and OLIDs (e.g., 'OL12345678A').
    if (is_numeric($cover_value)) {
        return "https://covers.openlibrary.org/b/id/{$cover_value}-L.jpg";
    } elseif (preg_match('/^(OL|M|S)\w+$/', $cover_value)) {
        // Use regex for a more robust check of OLIDs starting with OL, M, or S.
        return "https://covers.openlibrary.org/b/olid/" . htmlspecialchars($cover_value) . "-L.jpg";
    }
    // Assume it's a local filename
    return "covers/" . htmlspecialchars($cover_value);
}

// Search functionality
$query = isset($_GET['q']) ? trim($_GET['q']) : '';
$books = [];

if ($query) {
    $stmt = $pdo->prepare("
        SELECT
            b.id,
            b.title,
            b.author,
            b.cover,
            b.is_premium,
            b.views
        FROM books b
        LEFT JOIN book_genres bg ON b.id = bg.book_id
        LEFT JOIN genres g ON bg.genre_id = g.id
        WHERE
            b.title LIKE ? OR b.author LIKE ? OR g.name LIKE ?
        GROUP BY b.id
        ORDER BY b.views DESC
    ");
    $stmt->execute(["%$query%", "%$query%", "%$query%"]);
    $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search - Book-Tune</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="<?= isset($_SESSION['user_id']) ? 'logged-in' : '' ?>">

<aside class="bt-sidebar" id="sidebar">
    <div class="bt-sidebar__brand">
        Book-Tune
        <button id="closeSidebar" class="bt-sidebar__toggle">
            <i class="fas fa-arrow-left"></i>
        </button>
    </div>

    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="profile.php" class="sidebar-profile">
            <img src="<?= htmlspecialchars($profileImage) ?>" alt="Profile" class="sidebar-avatar">
            <span class="sidebar-username"><?= htmlspecialchars($user['username']) ?></span>
        </a>
    <?php endif; ?>

    <nav class="bt-nav">
        <a href="index.php" class="bt-nav__item"><i class="fas fa-home"></i><span class="bt-nav__text">Home</span></a>
        <a href="genres.php" class="bt-nav__item"><i class="fas fa-th-large"></i><span class="bt-nav__text">Genres</span></a>
        <a href="index.php#popular" class="bt-nav__item scroll-link"><i class="fas fa-fire"></i><span class="bt-nav__text">Popular</span></a>
        <a href="index.php#new-releases" class="bt-nav__item scroll-link"><i class="fas fa-star"></i><span class="bt-nav__text">New Releases</span></a>
        <a href="premium.php" class="bt-nav__item"><i class="fas fa-crown"></i><span class="bt-nav__text">Premium</span></a>
        <a href="upload.php" class="bt-nav__item"><i class="fas fa-upload"></i><span class="bt-nav__text">Upload</span></a>
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="logout.php" class="bt-nav__item"><i class="fas fa-sign-out-alt"></i><span class="bt-nav__text">Logout</span></a>
        <?php endif; ?>
    </nav>
</aside>

<header class="bt-header" id="topbar">
    <div class="bt-header__left">
        <button id="toggleSidebar" class="bt-sidebar__toggle">
            <i class="fas fa-bars"></i>
        </button>
        <div class="bt-logo">BOOK-TUNE</div>
        <form class="bt-search" method="GET" action="search.php">
            <input type="text" name="q" placeholder="Search books..." value="<?= htmlspecialchars($query) ?>" required>
            <button type="submit"><i class="fas fa-search"></i></button>
        </form>
    </div>

    <div class="bt-header__right">
        <?php if (isset($_SESSION['user_id'])): ?>
            <div class="user-menu">
                <a href="profile.php" class="user-profile-link">
                    <img src="<?= htmlspecialchars($profileImage) ?>" alt="Profile" class="user-avatar">
                    <span class="username"><?= htmlspecialchars($user['username']) ?></span>
                </a>
                <a href="logout.php" class="bt-btn bt-btn--ghost">Logout</a>
            </div>
        <?php else: ?>
            <a class="bt-btn bt-btn--ghost" href="login.php">Login</a>
            <a class="bt-btn bt-btn--ghost" href="signup.php">Sign Up</a>
            <a class="bt-btn bt-btn--gold" href="premium.php">Go Premium</a>
        <?php endif; ?>
    </div>
</header>

<main class="bt-main" id="mainContent">
    <div class="bt-container">
        <section class="bt-section">
            <h2 class="bt-section__title">Search Results for "<?= htmlspecialchars($query) ?>"</h2>
            <?php if ($query && $books): ?>
                <div class="bt-grid">
                    <?php foreach ($books as $book): ?>
                        <article class="bt-card">
                            <a class="bt-card__cover" href="book.php?id=<?= $book['id'] ?>">
                                <img src="<?= bt_cover_src($book['cover']) ?>" alt="<?= htmlspecialchars($book['title']) ?>">
                                <?php if (!empty($book['is_premium'])): ?>
                                    <span class="premium-tag">Premium</span>
                                <?php endif; ?>
                            </a>
                            <h3 class="bt-card__title"><a href="book.php?id=<?= $book['id'] ?>"><?= htmlspecialchars($book['title']) ?></a></h3>
                            <p class="bt-card__author"><?= htmlspecialchars($book['author']) ?></p>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php elseif ($query): ?>
                <div class="no-results">No results found for "<?= htmlspecialchars($query) ?>"</div>
            <?php else: ?>
                <div class="bt-empty">Enter a keyword to search for books.</div>
            <?php endif; ?>
        </section>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.getElementById('sidebar');
    const toggleButton = document.getElementById('toggleSidebar');
    const closeButton = document.getElementById('closeSidebar');
    const mainContent = document.getElementById('mainContent');

    const toggleSidebar = () => {
        const isExpanded = sidebar.classList.toggle('is-expanded');
        if (isExpanded) {
            mainContent.classList.add('is-shifted');
        } else {
            mainContent.classList.remove('is-shifted');
        }
    };

    if (toggleButton) {
        toggleButton.addEventListener('click', toggleSidebar);
    }
    if (closeButton) {
        closeButton.addEventListener('click', toggleSidebar);
    }
});
</script>

</body>
</html>