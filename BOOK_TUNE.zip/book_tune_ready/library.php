<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Defaults & helpers
function bt_cover_src($val) {
    return (preg_match('/^https?:\\/\\//', $val) ? $val : 'covers/' . htmlspecialchars($val));
}
$defaultAvatar = "assets/default-profile.png";
$possibleAvatar = "uploads/profile_" . $_SESSION['user_id'] . ".png";
$profileImage = file_exists($possibleAvatar) ? $possibleAvatar : $defaultAvatar;

// Fetch saved books
$stmt = $pdo->prepare("
    SELECT b.*, l.added_at
    FROM library l
    JOIN books b ON b.id = l.book_id
    WHERE l.user_id = ?
    ORDER BY l.added_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Flash
$success = $_SESSION['success'] ?? null;
$error   = $_SESSION['error'] ?? null;
unset($_SESSION['success'], $_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Library - Book-Tune</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@500;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
/* Small helper styles (uses your theme vars) */
.flash {
  margin: 12px 0; padding: 10px 14px; border-radius: 10px; border:1px solid var(--border,#2a3440);
  background: var(--panel-2,#1c2530); color: var(--text,#e7edf6); font-size:.95rem;
}
.flash--success { border-color: #2e7d32; }
.flash--error { border-color: #c62828; }
.bt-card__actions { display:flex; gap:.5rem; margin-top:8px; }
.btn-remove {
  background: transparent; border:1px solid #ff5c5c; color:#ff5c5c; border-radius:10px;
  padding:.45rem .7rem; cursor:pointer;
}
.btn-remove:hover { filter:brightness(1.1); transform: translateY(-1px); transition:.15s; }
</style>
</head>
<body class="logged-in">

<!-- Sidebar (exactly like your main page) -->
<aside class="bt-sidebar" id="sidebar">
    <div class="bt-sidebar__brand">
        Menu
        <button id="closeSidebar" class="bt-sidebar__toggle">
            <i class="fas fa-chevron-left"></i>
        </button>
    </div>

    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="profile.php" class="sidebar-profile">
            <img src="<?= $profileImage ?>" alt="Profile" class="sidebar-avatar">
            <span class="sidebar-username"><?= htmlspecialchars($_SESSION['username']) ?></span>
        </a>
    <?php endif; ?>

    <button id="sidebarCloseInside" class="bt-sidebar__close-top">
        <i class="fas fa-arrow-left"></i>
    </button>

    <nav class="bt-nav">
        <a href="index.php" class="bt-nav__item"><i class="fas fa-home"></i><span class="bt-nav__text">Home</span></a>
        <a href="genres.php" class="bt-nav__item"><i class="fas fa-th-large"></i><span class="bt-nav__text">Genres</span></a>
        <a href="index.php#popular" class="bt-nav__item scroll-link"><i class="fas fa-fire"></i><span class="bt-nav__text">Popular</span></a>
        <a href="index.php#new-releases" class="bt-nav__item scroll-link"><i class="fas fa-star"></i><span class="bt-nav__text">New Releases</span></a>
        <a href="premium.php" class="bt-nav__item"><i class="fas fa-crown"></i><span class="bt-nav__text">Premium</span></a>
        <a href="upload.php" class="bt-nav__item"><i class="fas fa-upload"></i><span class="bt-nav__text">Upload</span></a>
        <a href="library.php" class="bt-nav__item"><i class="fas fa-bookmark"></i><span class="bt-nav__text">My Library</span></a>
    </nav>
</aside>

<!-- Header -->
<header class="bt-header" id="topbar">
    <div class="bt-header__left">
        <button id="toggleSidebar" class="bt-sidebar__toggle"><i class="fas fa-bars"></i></button>
        <div class="bt-logo">BOOK-TUNE</div>
        <form class="bt-search" method="GET" action="search.php">
            <input type="text" name="q" placeholder="Search books..." required>
            <button type="submit" class="bt-btn bt-btn--search"><i class="fas fa-search"></i></button>
        </form>
    </div>
    <nav class="bt-header__right">
        <div class="user-menu">
            <img src="<?= $profileImage ?>" alt="Profile" class="user-avatar">
            <span class="username"><?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="logout.php" class="bt-btn bt-btn--ghost">Logout</a>
        </div>
    </nav>
</header>

<!-- Main Content -->
<main class="bt-main" id="mainContent">
    <section class="bt-section">
        <h2 class="bt-section__title">📚 My Library</h2>

        <?php if ($success): ?>
            <div class="flash flash--success"><i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="flash flash--error"><i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if ($books): ?>
            <div class="bt-grid" id="libGrid">
                <?php foreach ($books as $book): ?>
                    <article class="bt-card" data-book-id="<?= (int)$book['id'] ?>">
                        <a class="bt-card__cover" href="book.php?id=<?= $book['id'] ?>">
                            <img src="<?= $book['cover'] ? bt_cover_src($book['cover']) : 'images/placeholder.png' ?>" 
                                 alt="<?= htmlspecialchars($book['title']) ?>">
                        </a>
                        <h3 class="bt-card__title">
                            <a href="book.php?id=<?= $book['id'] ?>"><?= htmlspecialchars($book['title']) ?></a>
                        </h3>
                        <p class="bt-card__author"><?= htmlspecialchars($book['author']) ?></p>
                        <?php if (!empty($book['is_premium'])): ?>
                            <span class="premium-tag">Premium</span>
                        <?php endif; ?>
                        <div class="bt-card__meta">
                            <span>⭐ <?= htmlspecialchars($book['rating']) ?></span>
                            <span>👁 <?= htmlspecialchars($book['views']) ?></span>
                        </div>
                        <p class="bt-card__date" style="opacity:.8;">Added on <?= date("M d, Y", strtotime($book['added_at'])) ?></p>
                        <div class="bt-card__actions">
                            <form method="POST" action="remove_from_library.php" class="remove-form">
                                <input type="hidden" name="book_id" value="<?= $book['id'] ?>">
                                <button type="submit" class="btn-remove">
                                    <i class="fas fa-trash"></i> Remove
                                </button>
                            </form>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p style="margin-top:1rem; color:var(--muted);">You haven’t added any books yet.</p>
        <?php endif; ?>
    </section>
</main>

<script>
// Sidebar open/close (same behavior as your other pages)
(function(){
  const sidebar = document.getElementById('sidebar');
  const main = document.getElementById('mainContent');
  const top = document.getElementById('topbar');
  const openBtn = document.getElementById('toggleSidebar');
  const closeBtn = document.getElementById('closeSidebar');
  const insideBtn = document.getElementById('sidebarCloseInside');

  function openSidebar(){ sidebar.classList.add('is-expanded'); main?.classList.add('is-shifted'); top?.classList.add('is-shifted'); }
  function closeSidebar(){ sidebar.classList.remove('is-expanded'); main?.classList.remove('is-shifted'); top?.classList.remove('is-shifted'); }
  function setInitial(){ (window.innerWidth > 800) ? openSidebar() : closeSidebar(); }
  setInitial(); window.addEventListener('resize', setInitial);
  openBtn?.addEventListener('click', openSidebar);
  closeBtn?.addEventListener('click', closeSidebar);
  insideBtn?.addEventListener('click', closeSidebar);
})();

// Progressive enhancement: remove without page reload (fallback to normal POST if fetch fails)
document.querySelectorAll('.remove-form').forEach(form => {
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    try {
      const res = await fetch('remove_from_library.php', {
        method: 'POST',
        headers: { 'X-Requested-With': 'fetch', 'Accept': 'application/json' },
        body: fd
      });
      if (!res.ok) throw new Error('Network error');
      const data = await res.json();
      if (data.ok) {
        // Remove the card from the DOM
        const card = form.closest('.bt-card');
        card?.parentNode?.removeChild(card);
      } else {
        alert(data.error || 'Could not remove this book.');
        // fallback redirect
        window.location.reload();
      }
    } catch (err) {
      // fallback full submit if fetch fails
      form.submit();
    }
  });
});
</script>
</body>
</html>
