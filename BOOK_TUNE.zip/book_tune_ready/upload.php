<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $author = trim($_POST['author']);
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);
    $views = rand(100, 5000);
    $rating = number_format(rand(30, 50) / 10, 1);

    if (isset($_FILES['cover']) && $_FILES['cover']['error'] === UPLOAD_ERR_OK) {
        $fileTmp = $_FILES['cover']['tmp_name'];
        $fileName = basename($_FILES['cover']['name']);
        $fileSize = $_FILES['cover']['size'];
        $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        if (($fileType === "jpg" || $fileType === "jpeg" || $fileType === "png") && $fileSize <= 2 * 1024 * 1024) {
            $newFileName = uniqid() . "." . $fileType;
            move_uploaded_file($fileTmp, "covers/" . $newFileName);

            $stmt = $pdo->prepare("INSERT INTO books (title, author, category, description, cover, views, rating, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$title, $author, $category, $description, $newFileName, $views, $rating]);

            $message = "✅ Book uploaded successfully!";
        } else {
            $message = "❌ Invalid file. Please upload a JPG or PNG under 2MB.";
        }
    } else {
        $message = "❌ Please select a cover image.";
    }
}

// Avatar
$defaultAvatar = "assets/default-profile.png";
if (isset($_SESSION['user_id'])) {
    // Corrected logic to use session data for the image path
    if (isset($_SESSION['profile_pic']) && !empty($_SESSION['profile_pic'])) {
        $profileImage = htmlspecialchars($_SESSION['profile_pic']);
    } else {
        $profileImage = $defaultAvatar;
    }
} else {
    $profileImage = $defaultAvatar;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Upload Book - Book-Tune</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@500;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
/* --- Added/Corrected CSS for header spacing --- */
.user-menu {
    display: flex;
    align-items: center;
    gap: 12px;
}
.user-profile-link {
    display: flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    color: var(--text);
    transition: opacity 0.2s;
}
.user-profile-link:hover {
    opacity: 0.8;
}
.user-avatar {
    width: 32px;
    height: 32px;
    border-radius: 999px;
    object-fit: cover;
}
/* Cleaner form styles */
.upload-form {
    max-width: 500px;
    margin: 30px auto;
    background: var(--panel-2);
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
}
.upload-form input,
.upload-form textarea,
.upload-form button {
    width: 100%;
    margin-bottom: 15px;
}
.upload-form input,
.upload-form textarea {
    background: var(--panel);
    color: var(--text);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 10px;
    font-size: 0.95rem;
}
.upload-form textarea {
    resize: vertical;
    min-height: 100px;
}
.upload-form input[type="file"] {
    padding: 6px;
    background: var(--panel);
}
.upload-form button {
    background: var(--brand);
    color: white;
    padding: 12px;
    border: none;
    border-radius: 8px;
    font-size: 1rem;
    cursor: pointer;
    transition: 0.3s;
}
.upload-form button:hover {
    background: var(--brand-2);
    transform: scale(1.03);
}
.message {
    padding: 10px;
    border-radius: 8px;
    margin-bottom: 15px;
    font-weight: bold;
    background: var(--panel); /* Added a background for consistency */
    color: gold;
}
</style>
</head>
<body class="<?= isset($_SESSION['user_id']) ? 'logged-in' : '' ?>">

<aside class="bt-sidebar" id="sidebar">
    <div class="bt-sidebar__brand">
        Menu
        <button id="closeSidebar" class="bt-sidebar__toggle">
            <i class="fas fa-chevron-left"></i>
        </button>
    </div>

    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="profile.php" class="sidebar-profile">
            <img src="<?= $profileImage ?>" alt="Profile" class="sidebar-avatar">
            <span class="sidebar-username"><?= htmlspecialchars($_SESSION['username']) ?></span>
        </a>
    <?php endif; ?>

    <button id="sidebarCloseInside" class="bt-sidebar__close-top">
        <i class="fas fa-arrow-left"></i>
    </button>

    <nav class="bt-nav">
        <a href="index.php" class="bt-nav__item"><i class="fas fa-home"></i><span class="bt-nav__text">Home</span></a>
        <a href="genres.php" class="bt-nav__item"><i class="fas fa-th-large"></i><span class="bt-nav__text">Genres</span></a>
        <a href="index.php#popular" class="bt-nav__item scroll-link"><i class="fas fa-fire"></i><span class="bt-nav__text">Popular</span></a>
        <a href="index.php#new-releases" class="bt-nav__item scroll-link"><i class="fas fa-star"></i><span class="bt-nav__text">New Releases</span></a>
        <a href="premium.php" class="bt-nav__item"><i class="fas fa-crown"></i><span class="bt-nav__text">Premium</span></a>
        <a href="upload.php" class="bt-nav__item active"><i class="fas fa-upload"></i><span class="bt-nav__text">Upload</span></a>
    </nav>
</aside>

<header class="bt-header" id="topbar">
    <div class="bt-header__left">
        <button id="toggleSidebar" class="bt-sidebar__toggle"><i class="fas fa-bars"></i></button>
        <div class="bt-logo">BOOK-TUNE</div>
    </div>
    <nav class="bt-header__right">
        <?php if (isset($_SESSION['user_id'])): ?>
            <div class="user-menu">
                <a href="profile.php" class="user-profile-link">
                    <img src="<?= $profileImage ?>" alt="Profile" class="user-avatar">
                    <span class="username"><?= htmlspecialchars($_SESSION['username']) ?></span>
                </a>
                <a href="logout.php" class="bt-btn bt-btn--ghost">Logout</a>
            </div>
        <?php else: ?>
            <a class="bt-btn bt-btn--ghost" href="login.php">Login</a>
            <a class="bt-btn bt-btn--ghost" href="signup.php">Sign Up</a>
            <a class="bt-btn bt-btn--gold" href="premium.php">Go Premium</a>
        <?php endif; ?>
    </nav>
</header>

<main class="bt-main" id="mainContent">
    <section class="bt-section">
        <h2 class="bt-section__title">Upload a Book</h2>
        <form method="POST" enctype="multipart/form-data" class="upload-form">
            <?php if ($message): ?>
                <div class="message"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>
            <input type="text" name="title" placeholder="Book Title" required>
            <input type="text" name="author" placeholder="Author Name" required>
            <input type="text" name="category" placeholder="Category" required>
            <textarea name="description" placeholder="Write a short description..." required></textarea>
            <input type="file" name="cover" accept=".jpg,.jpeg,.png" required>
            <button type="submit">📤 Upload Book</button>
        </form>
    </section>
</main>

<script>
document.getElementById('toggleSidebar').addEventListener('click', function() {
    document.getElementById('sidebar').classList.add('is-expanded');
    document.getElementById('mainContent').classList.add('is-shifted');
    document.getElementById('topbar').classList.add('is-shifted');
});
document.getElementById('closeSidebar').addEventListener('click', function() {
    document.getElementById('sidebar').classList.remove('is-expanded');
    document.getElementById('mainContent').classList.remove('is-shifted');
    document.getElementById('topbar').classList.remove('is-shifted');
});
document.getElementById('sidebarCloseInside').addEventListener('click', function() {
    document.getElementById('sidebar').classList.remove('is-expanded');
    document.getElementById('mainContent').classList.remove('is-shifted');
    document.getElementById('topbar').classList.remove('is-shifted');
});
</script>

</body>
</html>