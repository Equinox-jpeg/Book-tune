<?php
session_start();
require_once "db.php";

// Always show useful DB errors in dev
if (defined('PDO::ATTR_ERRMODE')) {
    try { $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); } catch (Throwable $e) {}
}

function wants_json(): bool {
    // Detect simple AJAX/fetch requests
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) return true;
    if (!empty($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) return true;
    return false;
}

if (!isset($_SESSION['user_id'])) {
    if (wants_json()) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'Not logged in']);
        exit;
    }
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (wants_json()) {
        http_response_code(405);
        echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
        exit;
    }
    header("Location: library.php");
    exit;
}

$book_id = filter_input(INPUT_POST, 'book_id', FILTER_VALIDATE_INT);
if (!$book_id) {
    if (wants_json()) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Invalid book id']);
        exit;
    }
    $_SESSION['error'] = "Invalid book id.";
    header("Location: library.php");
    exit;
}

try {
    $stmt = $pdo->prepare("DELETE FROM library WHERE user_id = ? AND book_id = ?");
    $stmt->execute([$_SESSION['user_id'], $book_id]);

    $removed = $stmt->rowCount() > 0;
    if (wants_json()) {
        echo json_encode(['ok' => true, 'removed' => $removed]);
        exit;
    }

    $_SESSION['success'] = $removed ? "Book removed from your library." : "This book was not in your library.";
    header("Location: library.php");
    exit;
} catch (PDOException $e) {
    if (wants_json()) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'DB error: '.$e->getMessage()]);
        exit;
    }
    $_SESSION['error'] = "DB error: " . $e->getMessage();
    header("Location: library.php");
    exit;
}
