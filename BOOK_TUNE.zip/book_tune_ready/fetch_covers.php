<?php
$map = [
  'midnight_library.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/81-+r7Zp2zL.jpg',
  'project_hail_mary.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/81tC+8Fxg+L.jpg',
  'silent_patient.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/71K9CbNZPsL.jpg',
  'educated.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/81WojUxbbFL.jpg',
  'dune.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/91A7tQH+9-L.jpg',
  'where_the_crawdads_sing.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/81WWiiLgI-L.jpg',
  'atomic_habits.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/91bYsX41DVL.jpg',
  'song_of_achilles.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/81r+LN5Vw-L.jpg',
  'circe.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/91b0C2YNSrL.jpg',
  'becoming.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/81h2gWPTYJL.jpg',
  'the_hobbit.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/91b0C2YNSrL.jpg',
  'great_gatsby.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/81af+MCATTL.jpg',
  'pride_and_prejudice.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/81j8p6z9k-L.jpg',
  '1984.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/71kxa1-0mfL.jpg',
  'brave_new_world.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/71m8YFQ9JrL.jpg',
  'catcher_in_the_rye.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/81OthjkJBuL.jpg',
  'to_kill_a_mockingbird.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/81OxWqj3FhL.jpg',
  'the_alchemist.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/71aFt4+OTOL.jpg',
  'sapiens.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/713jIoMO3UL.jpg',
  'acotar.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/81iVQx2G1-L.jpg',
  'it_ends_with_us.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/71EwoNQypZL.jpg',
  'verity.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/81Y5WuARqpL.jpg',
  'girl_on_the_train.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/81NwWcR7Q7L.jpg',
  'gone_girl.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/81af+MCATTL.jpg',
  'hunger_games.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/61JfGcL2ljL.jpg',
  'catching_fire.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/61-zD2Z8OQL.jpg',
  'mockingjay.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/61PjFv9yWbL.jpg',
  'foundation.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/81r2g5W5X6L.jpg',
  'neuromancer.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/81GqtNbs+PL.jpg',
  'snow_crash.jpg' => 'https://images-na.ssl-images-amazon.com/images/I/81gTWnZxQ-L.jpg'
];
$destDir = __DIR__ . '/covers';
if(!is_dir($destDir)) mkdir($destDir, 0777, true);
function fetch_to($url, $path){
  if(file_exists($path)) return "exists";
  $ctx = stream_context_create(['http'=>['timeout'=>20],'https'=>['timeout'=>20]]);
  $data = @file_get_contents($url, false, $ctx);
  if($data === false) return "fail";
  file_put_contents($path, $data);
  return "ok";
}
$report = [];
foreach($map as $file=>$url){
  $status = fetch_to($url, $destDir . '/' . $file);
  $report[] = $file . ':' . $status;
}
header('Content-Type: text/plain');
echo "Done.\n" . implode("\n", $report);
