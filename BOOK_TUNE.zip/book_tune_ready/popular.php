<?php
session_start();
require_once "db.php";

$popularBooks = $pdo->query("SELECT * FROM books ORDER BY views DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Popular Books - Book-Tune</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@500;700&display=swap" rel="stylesheet">
<style>
:root {
    --brand1: #7aa2ff;
    --brand2: #ff7ac6;
    --bg: #0b0f14;
    --panel: #10151d;
    --text: #ffffff;
    --muted: #9aa8bb;
    --radius: 14px;
    --shadow: 0 8px 20px rgba(0,0,0,0.4);
}
body {
    margin: 0;
    font-family: 'Inter', sans-serif;
    background: var(--bg);
    color: var(--text);
}
header {
    padding: 16px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
h2 {
    margin: 0 0 14px;
    font-size: 18px;
    border-left: 4px solid var(--brand1);
    padding-left: 10px;
    color: var(--muted);
}
.popular-carousel {
    display: flex;
    gap: 16px;
    overflow-x: auto;
    padding-bottom: 10px;
    scroll-snap-type: x mandatory;
}
.popular-carousel::-webkit-scrollbar {
    height: 8px;
}
.popular-carousel::-webkit-scrollbar-thumb {
    background: rgba(255,255,255,0.1);
    border-radius: 4px;
}
.popular-card {
    flex: 0 0 auto;
    width: 200px;
    border-radius: var(--radius);
    overflow: hidden;
    background: var(--panel);
    box-shadow: var(--shadow);
    scroll-snap-align: start;
    position: relative;
    transition: transform 0.25s ease;
}
.popular-card:hover {
    transform: scale(1.05);
}
.popular-card img {
    width: 100%;
    height: 300px;
    object-fit: cover;
    display: block;
}
.popular-overlay {
    position: absolute;
    bottom: 0;
    left: 0; right: 0;
    padding: 12px;
    background: linear-gradient(to top, rgba(0,0,0,0.85), transparent);
}
.popular-overlay h3 {
    font-size: 14px;
    margin: 0 0 4px;
}
.popular-overlay p {
    font-size: 12px;
    color: var(--muted);
    margin: 0 0 6px;
}
.popular-meta {
    font-size: 12px;
    color: var(--muted);
}
</style>
</head>
<body>
<header>
    <h2>Popular Books</h2>
</header>
<div class="popular-carousel">
    <?php foreach ($popularBooks as $book): ?>
    <div class="popular-card">
        <a href="book.php?id=<?= $book['id'] ?>">
            <img src="covers/<?= htmlspecialchars($book['cover']) ?>" alt="<?= htmlspecialchars($book['title']) ?>">
            <div class="popular-overlay">
                <h3><?= htmlspecialchars($book['title']) ?></h3>
                <p><?= htmlspecialchars($book['author']) ?></p>
                <div class="popular-meta">
                    ⭐ <?= $book['rating'] ?> • 👁 <?= $book['views'] ?>
                </div>
            </div>
        </a>
    </div>
    <?php endforeach; ?>
</div>
</body>
</html>
