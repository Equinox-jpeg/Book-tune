<?php
session_start();
require_once "db.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST["username"]);
    $password = $_POST["password"];

    $stmt = $pdo->prepare("SELECT id, username, password, is_premium FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Securely verify the password and check if a user was found
    if ($user && password_verify($password, $user["password"])) {
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["username"] = $user["username"];
        $_SESSION["is_premium"] = $user["is_premium"];
        header("Location: index.php");
        exit;
    }
    
    $message = "Invalid username or password.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Log In - Book-Tune</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@500;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
/* Design Variables */
:root {
    --bg: #0b0f14;
    --panel: #10151d;
    --panel-2: #0f141b;
    --border: #1a2430;
    --text: #e7edf6;
    --text-muted: #a0a8b4;
    --brand: #7aa2ff;
}

/* General Styles */
body {
    margin: 0;
    font-family: 'Inter', sans-serif;
    background: var(--bg);
    color: var(--text);
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
    background: url('assets/login-bg.jpg') no-repeat center center/cover;
}

.overlay {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.6);
}

.login-container {
    position: relative;
    z-index: 2;
    background: var(--panel);
    padding: 2.5rem;
    border-radius: 12px;
    width: 100%;
    max-width: 400px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.4);
    border: 1px solid var(--border);
    text-align: center;
}

.welcome-text {
    font-size: 1.8rem;
    font-weight: 800;
    color: var(--brand);
    margin-bottom: 0.5rem;
}

.subtitle {
    color: var(--text-muted);
    font-size: 1rem;
    margin-bottom: 2rem;
}

h2 {
    text-align: center;
    margin-bottom: 1rem;
}

form {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

input {
    width: 100%;
    padding: 0.8rem;
    border-radius: 8px;
    border: 1px solid var(--border);
    background: var(--panel-2);
    color: var(--text);
    transition: border-color 0.3s;
}

input:focus {
    outline: none;
    border-color: var(--brand);
}

button {
    width: 100%;
    padding: 0.8rem;
    border-radius: 8px;
    border: none;
    background: var(--brand);
    color: #fff;
    font-size: 1rem;
    cursor: pointer;
    font-weight: 700;
    transition: background-color 0.3s;
}

button:hover {
    background: #5e8cff;
}

.alert {
    background: rgba(255,0,0,0.2);
    padding: 0.8rem;
    border-radius: 6px;
    margin-bottom: 1rem;
    text-align: center;
}

.signup-link {
    text-align: center;
    font-size: 0.9rem;
    margin-top: 1.5rem;
}

.signup-link a {
    color: var(--brand);
    text-decoration: none;
    font-weight: 600;
}

.signup-link a:hover {
    text-decoration: underline;
}
</style>
</head>
<body>
<div class="overlay"></div>
<div class="login-container">
    <div class="welcome-text">Welcome to Book-Tune</div>
    <div class="subtitle">Log in to continue</div>
    <?php if ($message): ?>
        <div class="alert"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Log In</button>
    </form>
    <div class="signup-link">
        Don't have an account? <a href="signup.php">Sign Up</a>
    </div>
</div>
</body>
</html>