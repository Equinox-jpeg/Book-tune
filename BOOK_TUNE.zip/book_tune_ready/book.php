<?php
require_once "session.php"; // New line, place this first
require_once "db.php";

function bt_cover_src($val) {
    if (preg_match('/^https?:\/\//', $val)) {
        return htmlspecialchars($val);
    }
    $local_path = 'covers/' . $val;
    if (file_exists($local_path) && !is_dir($local_path)) {
        return htmlspecialchars($local_path);
    }
    return 'assets/placeholder-cover.jpg'; 
}

// **Corrected Profile Image Logic**
$defaultAvatar = "assets/default-profile.png";
$profileImage = $defaultAvatar;
if (isset($_SESSION['user_id'])) {
    // We already fetch the user's profile_pic in session.php
    // So we just need to access the session variable.
    if (!empty($_SESSION['profile_pic'])) {
        $profileImage = htmlspecialchars($_SESSION['profile_pic']);
    }
}

$isPremiumUser = isset($_SESSION['is_premium']) && $_SESSION['is_premium'];

if (!isset($_GET['id'])) die("Book not found.");
$bookId = (int)$_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM books WHERE id = ?");
$stmt->execute([$bookId]);
$book = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$book) die("Book not found.");

$chaptersStmt = $pdo->prepare("SELECT * FROM chapters WHERE book_id = ? ORDER BY id ASC");
$chaptersStmt->execute([$bookId]);
$chapters = $chaptersStmt->fetchAll(PDO::FETCH_ASSOC);

$ratingStmt = $pdo->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as total FROM ratings WHERE book_id = ?");
$ratingStmt->execute([$bookId]);
$ratingData = $ratingStmt->fetch(PDO::FETCH_ASSOC);
$avgRating = $ratingData['avg_rating'] ? number_format($ratingData['avg_rating'], 1) : "0.0";
$totalRatings = $ratingData['total'];

$commentsStmt = $pdo->prepare("
    SELECT c.*, COALESCE(u.username, 'Guest') as username,
             COALESCE(u.profile_pic, 'assets/default-profile.png') AS avatar
    FROM comments c
    LEFT JOIN users u ON c.user_id = u.id
    WHERE c.book_id = ?
    ORDER BY c.created_at DESC
");
$commentsStmt->execute([$bookId]);
$comments = $commentsStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($book['title']) ?> - Book-Tune</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
    /* Professional CSS Redesign */
    :root {
        --bg-primary: #0a0e14;
        --bg-secondary: #121820;
        --card-bg: #1d2532;
        --text-primary: #e8eef8;
        --text-secondary: #a0a8b4;
        --brand-color: #5d83ff;
        --brand-light: #7a9aff;
        --border-color: #2e3b50;
        --brand-premium: #f3c74c;
    }
    body {
        background-color: var(--bg-primary);
        color: var(--text-primary);
        font-family: 'Inter', sans-serif;
        line-height: 1.6;
        margin: 0;
        padding: 0;
    }
    .bt-main {
        max-width: 1100px;
        margin: 40px auto;
        padding: 20px;
    }
    .bt-container {
        display: flex;
        flex-direction: column;
        gap: 30px;
        background-color: var(--bg-secondary);
        padding: 40px;
        border-radius: 18px;
        border: 1px solid var(--border-color);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    }
    @media (min-width: 768px) {
        .bt-container {
            flex-direction: row;
        }
    }
    .bt-cover-container {
        flex-shrink: 0;
        width: 100%;
        max-width: 300px;
        height: auto;
    }
    .bt-cover-container img {
        width: 100%;
        height: auto;
        border-radius: 12px;
        object-fit: cover;
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.5);
        border: 1px solid rgba(255, 255, 255, 0.05);
    }
    .bt-book-details {
        flex-grow: 1;
        padding-left: 20px;
    }
    .bt-book-details h1 {
        font-size: 3rem;
        margin: 0 0 10px 0;
        font-weight: 800;
        line-height: 1.2;
    }
    .bt-book-meta {
        font-size: 1rem;
        color: var(--text-secondary);
        margin-bottom: 25px;
    }
    .bt-book-details p {
        color: var(--text-secondary);
        line-height: 1.7;
        font-size: 1rem;
    }
    .bt-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        margin: 25px 0;
    }
    .bt-btn {
        padding: 12px 24px;
        border-radius: 50px;
        border: 1px solid var(--border-color);
        background: var(--card-bg);
        color: var(--text-primary);
        font-size: 1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all .2s ease;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }
    .bt-btn:hover {
        background: var(--brand-color);
        color:#fff;
        border-color: var(--brand-color);
        transform: translateY(-2px);
    }
    .bt-btn--primary {
        background: var(--brand-color);
        color: #fff;
        border: none;
    }
    .bt-btn--primary:hover {
        background: var(--brand-light);
    }
    .bt-dropdown { position: relative; }
    .bt-dropdown-menu {
        display: none;
        position: absolute;
        top: 110%;
        left: 0;
        background: var(--bg-secondary);
        border: 1px solid var(--border-color);
        border-radius: 10px;
        min-width: 180px;
        overflow: hidden;
        box-shadow: 0 4px 20px rgba(0,0,0,0.4);
        z-index: 10;
        transform: translateY(10px);
        opacity: 0;
        transition: all 0.3s ease;
    }
    .bt-dropdown.open .bt-dropdown-menu {
        display: block;
        transform: translateY(0);
        opacity: 1;
    }
    .bt-dropdown-menu a {
        display: block;
        padding: 12px 16px;
        text-decoration: none;
        color: var(--text-primary);
        font-size: 0.95rem;
        transition: background .2s;
    }
    .bt-dropdown-menu a:hover {
        background: var(--card-bg);
        color: var(--brand-color);
    }
    .star-rating {
        display: flex;
        flex-direction: row-reverse;
        gap: 8px;
        font-size: 2.5rem;
        margin: 15px 0;
        justify-content: flex-start;
    }
    .star-rating input { display: none; }
    .star-rating label {
        color: #444;
        cursor: pointer;
        transition: color .2s;
    }
    .star-rating input:checked ~ label,
    .star-rating label:hover,
    .star-rating label:hover ~ label {
        color: var(--brand-premium);
    }
    .bt-rating-submit {
        margin-top: 10px;
        padding: 10px 20px;
        border: none;
        border-radius: 50px;
        background: var(--brand-color);
        color: #fff;
        font-weight: 600;
        cursor: pointer;
        transition: background .2s, transform .2s;
    }
    .bt-rating-submit:hover {
        background: var(--brand-light);
        transform: translateY(-2px);
    }
    .bt-sections-container {
        display: grid;
        gap: 30px;
        margin-top: 40px;
    }
    @media (min-width: 768px) {
        .bt-sections-container {
            grid-template-columns: 1fr 1fr;
        }
    }
    .bt-section {
        background: var(--bg-secondary);
        padding: 30px;
        border-radius: 18px;
        border: 1px solid var(--border-color);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    }
    .bt-section h2 {
        font-size: 2rem;
        margin-bottom: 25px;
        font-weight: 700;
        border-bottom: 1px solid var(--border-color);
        padding-bottom: 15px;
    }
    .bt-chapters ul {
        list-style: none;
        padding: 0;
        margin: 0;
        display: grid;
        gap: 12px;
    }
    .bt-chapter-item {
        padding: 15px 20px;
        background: var(--card-bg);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        text-decoration: none;
        color: var(--text-primary);
        font-weight: 500;
        transition: all .2s ease;
        display: block;
    }
    .bt-chapter-item:hover {
        background: var(--brand-color);
        color: #fff;
        border-color: var(--brand-color);
        transform: translateY(-2px);
    }
    /* Comment Section Styles */
    .bt-comments-list {
        display: flex;
        flex-direction: column;
        gap: 20px;
        margin-bottom: 25px;
    }
    .bt-comment {
        display: flex;
        gap: 15px;
        padding: 20px;
        background: var(--card-bg);
        border: 1px solid var(--border-color);
        border-radius: 15px;
    }
    .bt-comment img {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid var(--brand-color);
        flex-shrink: 0;
    }
    .bt-comment-body { flex: 1; }
    .bt-comment-meta {
        font-size: 0.85rem;
        color: var(--text-secondary);
        margin-bottom: 8px;
        font-weight: 500;
        line-height: 1.2;
    }
    .bt-comment-meta strong {
        color: var(--text-primary);
        font-size: 1rem;
        font-weight: 600;
    }
    .bt-comment-text {
        font-size: 0.95rem;
        line-height: 1.6;
        color: var(--text-primary);
    }
    .bt-empty-state {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        text-align: center;
        padding: 40px;
        border: 2px dashed var(--border-color);
        border-radius: 15px;
    }
    .bt-empty-state i {
        font-size: 3rem;
        color: var(--text-secondary);
        margin-bottom: 15px;
    }
    .bt-empty-state p {
        color: var(--text-secondary);
        margin: 0;
    }
    .bt-comments-divider {
        border: 0;
        height: 1px;
        background-color: var(--border-color);
        margin: 25px 0;
    }
    /* Form Styles */
    .bt-comment-form h3 {
        font-size: 1.5rem;
        margin-bottom: 15px;
    }
    .bt-comment-form textarea {
        width: 100%;
        padding: 15px;
        border-radius: 12px;
        border: 1px solid var(--border-color);
        background: var(--bg-secondary);
        color: var(--text-primary);
        resize: vertical;
        font-size: 1rem;
        margin-bottom: 10px;
    }
    .bt-comment-form button {
        padding: 12px 24px;
        border: none;
        border-radius: 50px;
        background: var(--brand-color);
        color: #fff;
        font-weight: 600;
        cursor: pointer;
        transition: background .2s, transform .2s;
    }
    .bt-comment-form button:hover {
        background: var(--brand-light);
        transform: translateY(-2px);
    }
    .bt-comment-login-message {
        color: var(--text-secondary);
        font-style: italic;
    }
    .premium-lock {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        text-align: center;
        padding: 50px;
        background-color: var(--card-bg);
        border-radius: 18px;
        border: 2px dashed var(--brand-premium);
        margin-top: 40px;
    }
    .premium-lock .fas {
        font-size: 3.5rem;
        color: var(--brand-premium);
        margin-bottom: 25px;
        animation: pulse 2s infinite;
    }
    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.1); }
        100% { transform: scale(1); }
    }
    .premium-lock h2 {
        color: var(--brand-premium);
        font-size: 2.2rem;
        margin-bottom: 15px;
        font-weight: 700;
    }
    .premium-lock p {
        color: var(--text-secondary);
        font-size: 1.1rem;
        margin-bottom: 30px;
    }
    .go-premium-btn {
        background-color: var(--brand-premium);
        color: var(--bg-primary);
        padding: 15px 40px;
        border-radius: 50px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 1px;
        transition: background-color 0.3s, transform 0.3s;
        text-decoration: none;
    }
    .go-premium-btn:hover {
        background-color: #ffd740;
        transform: translateY(-2px);
    }
    /* Modal */
    .cat-modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.85); z-index: 1000; justify-content: center; align-items: center; }
    .cat-modal-content { background: var(--bg-secondary); padding: 30px; border-radius: 15px; text-align: center; max-width: 90%; border: 1px solid var(--border-color); }
    .cat-modal img { max-width: 100%; max-height: 80vh; border-radius: 12px; }
    .cat-modal-close { margin-top: 20px; padding: 10px 25px; background: var(--brand-color); color: white; border: none; border-radius: 50px; cursor: pointer; transition: background .2s, transform .2s; }
    .cat-modal-close:hover { background: var(--brand-light); transform: translateY(-2px); }
</style>
</head>
<body>

<aside class="bt-sidebar" id="sidebar">
    <div class="bt-sidebar__brand">BOOK-TUNE</div>
    <button id="closeSidebar" class="bt-sidebar__toggle"><i class="fas fa-arrow-left"></i></button>

    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="profile.php" class="sidebar-profile">
            <img src="<?= $profileImage ?>" alt="Profile" class="avatar-img">
            <span class="sidebar-username"><?= htmlspecialchars($_SESSION['username']) ?></span>
        </a>
    <?php endif; ?>

    <nav class="bt-nav">
        <a href="index.php" class="bt-nav__item"><i class="fas fa-home"></i><span class="bt-nav__text">Home</span></a>
        <a href="genres.php" class="bt-nav__item"><i class="fas fa-th-large"></i><span class="bt-nav__text">Genres</span></a>
        <a href="index.php#popular" class="bt-nav__item scroll-link"><i class="fas fa-fire"></i><span class="bt-nav__text">Popular</span></a>
        <a href="index.php#new-releases" class="bt-nav__item scroll-link"><i class="fas fa-star"></i><span class="bt-nav__text">New Releases</span></a>
        <a href="premium.php" class="bt-nav__item"><i class="fas fa-crown"></i><span class="bt-nav__text">Premium</span></a>
        <a href="upload.php" class="bt-nav__item"><i class="fas fa-upload"></i><span class="bt-nav__text">Upload</span></a>
    </nav>
</aside>

<header class="bt-header" id="topbar">
    <div class="bt-header__left">
        <button id="toggleSidebar" class="bt-sidebar__toggle"><i class="fas fa-bars"></i></button>
        <div class="bt-logo">BOOK-TUNE</div>
    </div>
    <div class="bt-header__profile">
    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="profile.php">
            <img src="<?= $profileImage ?>" alt="User Avatar" class="avatar-img">
            <span class="bt-header-username"><?= htmlspecialchars($_SESSION['username']) ?></span>
        </a>
        <a href="logout.php" class="bt-header-logout">Logout</a>
    <?php else: ?>
        <a href="login.php" class="bt-btn bt-btn--login">Log In</a>
        <a href="register.php" class="bt-btn bt-btn--register">Sign Up</a>
    <?php endif; ?>
    </div>
</header>

<main class="bt-main">
    <div class="bt-container">
        <div class="bt-cover-container">
            <img id="bookCover" src="<?= bt_cover_src($book['cover']) ?>" data-title="<?= htmlspecialchars($book['title']) ?>" data-author="<?= htmlspecialchars($book['author']) ?>" alt="<?= htmlspecialchars($book['title']) ?>">
        </div>
        <div class="bt-book-details">
            <h1><?= htmlspecialchars($book['title']) ?></h1>
            <div class="bt-book-meta">
                By <?= htmlspecialchars($book['author']) ?> • ⭐ <?= $avgRating ?> (<?= $totalRatings ?> ratings) • <?= htmlspecialchars($book['category']) ?>
            </div>
            <p><?= htmlspecialchars($book['description']) ?></p>

            <?php
            if ($book['is_premium'] && !$isPremiumUser) { ?>
                <div class="bt-actions">
                    <a href="premium.php" class="bt-btn bt-btn--primary">
                        <i class="fas fa-lock"></i> Go Premium to Read
                    </a>
                </div>
            <?php } else { ?>
                <div class="bt-actions">
                    <button class="bt-btn bt-btn--primary" onclick="showRandomCat()"><i class="fas fa-book-open"></i> Read Now</button>
                    <?php if (isset($_SESSION['user_id'])): ?>
                    <form method="POST" action="add_to_library.php" style="display:inline">
                        <input type="hidden" name="book_id" value="<?= $book['id'] ?>">
                        <button type="submit" class="bt-btn"><i class="fas fa-bookmark"></i> Add to Library</button>
                    </form>
    
                    <div class="bt-dropdown">
                        <button class="bt-btn" id="statusDropdownBtn">Update Status ⌄</button>
                        <div class="bt-dropdown-menu">
                            <a href="update_status.php?book_id=<?= $book['id'] ?>&status=plan">Plan to Read</a>
                            <a href="update_status.php?book_id=<?= $book['id'] ?>&status=reading">Reading</a>
                            <a href="update_status.php?book_id=<?= $book['id'] ?>&status=completed">Completed</a>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <?php if (isset($_SESSION['user_id'])): ?>
                <form method="POST" action="rate.php">
                    <input type="hidden" name="book_id" value="<?= $book['id'] ?>">
                    <div class="star-rating">
                        <?php for ($i=5;$i>=1;$i--): ?>
                            <input type="radio" id="star<?= $i ?>" name="rating" value="<?= $i ?>">
                            <label for="star<?= $i ?>">★</label>
                        <?php endfor; ?>
                    </div>
                    <button type="submit" class="bt-rating-submit">Submit Rating</button>
                </form>
                <?php endif; ?>
            <?php } ?>
        </div>
    </div>

    <div class="bt-sections-container">
        <?php if ($book['is_premium'] && !$isPremiumUser) { ?>
            <div class="bt-section premium-lock" style="grid-column: 1 / -1;">
                <i class="fas fa-lock"></i>
                <h2>This content is for Premium members only</h2>
                <p>Become a Premium member to read all chapters.</p>
                <a href="premium.php" class="go-premium-btn">Go Premium</a>
            </div>
        <?php } else { ?>
            <div class="bt-section bt-chapters">
                <h2>Chapters</h2>
                <ul>
                    <?php $chapterNum=1; foreach ($chapters as $ch): ?>
                        <li><a class="bt-chapter-item" href="#" onclick="showRandomCat(); return false;">Chapter <?= $chapterNum++ ?>: <?= htmlspecialchars($ch['title']) ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php } ?>

        <div class="bt-section bt-comments">
            <h2>Comments</h2>
            <div class="bt-comments-list">
                <?php if (count($comments) > 0): ?>
                    <?php foreach ($comments as $c): ?>
                    <div class="bt-comment">
                        <img src="<?= htmlspecialchars($c['avatar']) ?>" alt="avatar" class="avatar-img">
                        <div class="bt-comment-body">
                            <div class="bt-comment-meta"><strong><?= htmlspecialchars($c['username']) ?></strong> • <?= $c['created_at'] ?></div>
                            <div class="bt-comment-text"><?= htmlspecialchars($c['comment']) ?></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="bt-empty-state">
                        <i class="fas fa-comment-dots"></i>
                        <p>No comments yet. Be the first to leave one!</p>
                    </div>
                <?php endif; ?>
            </div>

            <hr class="bt-comments-divider">
            
            <h3 class="bt-comment-form-heading">Leave a Comment</h3>
            <?php if (isset($_SESSION['user_id'])): ?>
                <form class="bt-comment-form" method="POST" action="add_comment.php">
                    <input type="hidden" name="book_id" value="<?= $bookId ?>">
                    <textarea name="comment" rows="4" placeholder="Write your comment here..." required></textarea>
                    <button type="submit">Submit Comment</button>
                </form>
            <?php else: ?>
                <p class="bt-comment-login-message">You must be logged in to leave a comment. <a href="login.php">Log in here</a>.</p>
            <?php endif; ?>
        </div>
    </div>
</main>

<div class="cat-modal" id="catModal">
    <div class="cat-modal-content">
        <img id="catImage" src="" alt="Random Cat">
        <p>Enjoy this random cat instead of chapter content!</p>
        <button class="cat-modal-close" onclick="document.getElementById('catModal').style.display='none'">Close</button>
    </div>
</div>

<script>
// Sidebar toggle
const sidebar = document.getElementById("sidebar");
const toggleBtn = document.getElementById("toggleSidebar");
const closeBtn = document.getElementById("closeSidebar");

toggleBtn.addEventListener("click", () => sidebar.classList.add("is-expanded"));
closeBtn.addEventListener("click", () => sidebar.classList.remove("is-expanded"));

document.addEventListener("click", function(e) {
    if (sidebar.classList.contains("is-expanded") && !sidebar.contains(e.target) && e.target !== toggleBtn) {
        sidebar.classList.remove("is-expanded");
    }
});

// Dropdown toggle
const statusBtn = document.getElementById("statusDropdownBtn");
if (statusBtn) {
    statusBtn.addEventListener("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        const dropdown = this.parentElement;
        dropdown.classList.toggle("open");
    });
}

document.addEventListener("click", function() {
    document.querySelectorAll('.bt-dropdown').forEach(d => d.classList.remove('open'));
});

// Fetch Open Library Cover if local one doesn't exist
async function fetchOpenLibraryCover() {
    const img = document.getElementById("bookCover");
    if (!img) return;
    if (img.src.includes('assets/placeholder-cover.jpg')) {
        try {
            const title = img.dataset.title;
            const author = img.dataset.author;
            const res = await fetch(`https://openlibrary.org/search.json?title=${encodeURIComponent(title)}&author=${encodeURIComponent(author)}&limit=1`);
            const data = await res.json();
            if (data.docs && data.docs.length > 0) {
                const doc = data.docs[0];
                if (doc.cover_i) {
                    const url = `https://covers.openlibrary.org/b/id/${doc.cover_i}-L.jpg`;
                    img.src = url;
                }
            }
        } catch(e) {
            console.warn("Open Library cover fetch failed", e);
        }
    }
}
window.onload = fetchOpenLibraryCover;

// Random cat images
function showRandomCat() {
    const catModal = document.getElementById('catModal');
    const catImage = document.getElementById('catImage');
    const catImages = [
        'https://placekitten.com/800/600', 'https://placekitten.com/800/601',
        'https://placekitten.com/801/600', 'https://placekitten.com/801/601',
        'https://cataas.com/cat', 'https://cataas.com/cat/cute',
        'https://cataas.com/cat/says/Hello!', 'https://cataas.com/cat/gif'
    ];
    const randomCat = catImages[Math.floor(Math.random() * catImages.length)];
    catImage.src = randomCat;
    catModal.style.display = 'flex';
}

document.getElementById('catModal').addEventListener('click', function(e) {
    if (e.target === this) {
        this.style.display = 'none';
    }
});
</script>
</body>
</html>