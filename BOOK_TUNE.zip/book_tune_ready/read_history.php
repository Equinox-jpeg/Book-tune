<?php
session_start();
require_once "db.php";

// Check for session and redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Fetch user data from the database
$stmt = $pdo->prepare("SELECT username, bio, profile_pic FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    // Should not happen, but a safeguard
    header("Location: logout.php");
    exit;
}

// Set the profile image path. Prioritize database value, fallback to default.
$defaultAvatar = "assets/default-profile.png";
$profileImage = !empty($user['profile_pic']) ? $user['profile_pic'] : $defaultAvatar;

// Cover helper for local/remote images
function bt_cover_src($val) {
    if (strpos($val, 'OL') === 0) {
        return "https://covers.openlibrary.org/b/olid/" . htmlspecialchars($val) . "-M.jpg";
    }
    if (is_numeric($val) && strlen($val) >= 10) {
        return "https://covers.openlibrary.org/b/isbn/" . htmlspecialchars($val) . "-M.jpg";
    }
    return (preg_match('/^https?:\\/\\//', $val) ? $val : 'covers/' . htmlspecialchars($val));
}

// --- Fetch only completed books with their completion date ---
$stmt = $pdo->prepare("SELECT b.*, l.completed_date FROM library l
                        JOIN books b ON l.book_id = b.id
                        WHERE l.user_id = ? AND l.status = 'completed'
                        ORDER BY l.completed_date DESC"); // Order by most recently completed
$stmt->execute([$_SESSION['user_id']]);
$completedBooks = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Read History - Book-Tune</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@500;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Re-using styles from profile.php for consistency */
        :root {
            --bg: #111827;
            --panel: #1f2937;
            --panel-2: #374151;
            --border: #4b5563;
            --text: #f9fafb;
            --muted: #9ca3af;
            --brand: #6366f1;
            --shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            --brand-2: #ff7ac6;
            --gold: #f5b041;
        }
        body { font-family: 'Inter', sans-serif; background: var(--bg); color: var(--text); margin: 0; padding: 0; overflow-x: hidden; }
        a { color: var(--brand); text-decoration: none; }
        a:hover { text-decoration: underline; }
        .bt-main { padding: 80px 20px 20px 20px; max-width: 1200px; margin: 0 auto; transition: margin-left 0.3s ease; }
        @media (min-width: 768px) { .bt-main { padding-left: 280px; } }
        .bt-sidebar { position: fixed; top: 0; left: 0; width: 250px; height: 100%; background: var(--panel); border-right: 1px solid var(--border); padding: 20px; transition: transform 0.3s ease; z-index: 100; transform: translateX(-100%); }
        .bt-sidebar.is-expanded { transform: translateX(0); }
        .bt-sidebar__brand { font-weight: 800; font-size: 1.5rem; margin-bottom: 20px; color: var(--brand); }
        .bt-sidebar__toggle { background: transparent; border: none; color: var(--text); font-size: 1.5rem; cursor: pointer; }
        .bt-sidebar .sidebar-profile { display: flex; align-items: center; gap: 10px; margin-bottom: 20px; }
        .bt-sidebar .sidebar-avatar { width: 50px; height: 50px; border-radius: 50%; object-fit: cover; border: 2px solid var(--brand); }
        .bt-sidebar .sidebar-username { font-weight: bold; }
        .bt-nav { display: flex; flex-direction: column; gap: 10px; }
        .bt-nav__item { display: flex; align-items: center; gap: 15px; padding: 10px 15px; border-radius: 10px; transition: background-color 0.2s; }
        .bt-nav__item:hover { background-color: var(--panel-2); }
        .bt-nav__item i { font-size: 1.2rem; }
        .bt-header { position: fixed; top: 0; left: 0; width: 100%; height: 60px; background: var(--panel); border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; padding: 0 20px; z-index: 50; }
        .bt-header__left { display: flex; align-items: center; gap: 20px; }
        .bt-logo { font-weight: 800; color: var(--brand); font-size: 1.2rem; }
        .bt-btn { padding: 8px 16px; border-radius: 999px; border: 1px solid var(--border); background: var(--panel-2); color: var(--text); font-size: 14px; font-weight: 600; cursor: pointer; transition: all .2s ease; }
        .bt-btn:hover { background: var(--brand); color:#fff; border-color:var(--brand); }
        .bt-btn--primary { background: var(--brand); color:#fff; border:none; }
        .bt-btn--primary:hover { background: #5f86ff; }
        .bt-btn--ghost { background: transparent; border: none; }
        .bt-btn--gold { background: var(--gold); color: #000; border: none; font-weight: 700; }
        .bt-search { position: relative; width: 300px; }
        .bt-search input { width: 100%; padding: 8px 40px 8px 15px; border-radius: 999px; border: 1px solid var(--border); background: var(--panel-2); color: var(--text); font-size: 14px; }
        .bt-search button { position: absolute; right: 8px; top: 50%; transform: translateY(-50%); background: none; border: none; color: var(--muted); cursor: pointer; }
        .user-menu { display: flex; align-items: center; gap: 10px; }
        .user-avatar { width: 35px; height: 35px; border-radius: 50%; object-fit: cover; }
        .username { font-weight: 600; }
        .page-header h1 { font-size: 2.5rem; font-weight: 800; border-bottom: 1px solid var(--border); padding-bottom: 10px; margin-bottom: 20px; }
        .book-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 20px; }
        .book-card { background: var(--panel); border-radius: 10px; overflow: hidden; box-shadow: var(--shadow); transition: transform 0.2s ease; }
        .book-card:hover { transform: translateY(-5px); }
        .book-card a { display: block; }
        .book-card img { width: 100%; height: 200px; object-fit: cover; display: block; }
        .book-card .book-title { padding: 10px; text-align: center; font-weight: 600; font-size: 1rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .book-card .book-completed-date { font-size: 0.8rem; color: var(--muted); text-align: center; padding: 0 10px 10px; }
        .no-books { color: var(--muted); font-style: italic; text-align: center; padding: 20px; }
        @media (max-width: 767px) { .bt-main { padding-top: 80px; } .bt-header { justify-content: flex-start; } .bt-header__left { gap: 10px; } }
    </style>
</head>
<body>

<aside class="bt-sidebar" id="sidebar">
    <div class="bt-sidebar__brand">
        Menu
        <button id="closeSidebar" class="bt-sidebar__toggle">
            <i class="fas fa-chevron-left"></i>
        </button>
    </div>

    <?php if (isset($_SESSION['user_id'])): ?>
    <a href="profile.php" class="sidebar-profile">
        <img src="<?= htmlspecialchars($profileImage) ?>" alt="Profile" class="sidebar-avatar">
        <span class="sidebar-username"><?= htmlspecialchars($user['username']) ?></span>
    </a>
    <?php endif; ?>

    <button id="sidebarCloseInside" class="bt-sidebar__close-top">
        <i class="fas fa-arrow-left"></i>
    </button>

    <nav class="bt-nav">
        <a href="index.php" class="bt-nav__item"><i class="fas fa-home"></i><span class="bt-nav__text">Home</span></a>
        <a href="genres.php" class="bt-nav__item"><i class="fas fa-th-large"></i><span class="bt-nav__text">Genres</span></a>
        <a href="profile.php" class="bt-nav__item"><i class="fas fa-user"></i><span class="bt-nav__text">Profile</span></a>
        <a href="read_history.php" class="bt-nav__item"><i class="fas fa-book-reader"></i><span class="bt-nav__text">Read History</span></a>
        <a href="premium.php" class="bt-nav__item"><i class="fas fa-crown"></i><span class="bt-nav__text">Premium</span></a>
        <a href="upload.php" class="bt-nav__item"><i class="fas fa-upload"></i><span class="bt-nav__text">Upload</span></a>
    </nav>
</aside>

<header class="bt-header" id="topbar">
    <div class="bt-header__left">
        <button id="toggleSidebar" class="bt-sidebar__toggle"><i class="fas fa-bars"></i></button>
        <div class="bt-logo">BOOK-TUNE</div>
        <form class="bt-search" method="GET" action="search.php">
            <input type="text" name="q" placeholder="Search books..." required>
            <button type="submit" class="bt-btn bt-btn--search"><i class="fas fa-search"></i></button>
        </form>
    </div>
    <nav class="bt-header__right">
        <?php if (isset($_SESSION['user_id'])): ?>
            <div class="user-menu">
                <img src="<?= htmlspecialchars($profileImage) ?>" alt="Profile" class="user-avatar">
                <span class="username"><?= htmlspecialchars($user['username']) ?></span>
                <a href="logout.php" class="bt-btn bt-btn--ghost">Logout</a>
            </div>
        <?php else: ?>
            <a class="bt-btn bt-btn--ghost" href="login.php">Login</a>
            <a class="bt-btn bt-btn--ghost" href="signup.php">Sign Up</a>
            <a class="bt-btn bt-btn--gold" href="premium.php">Go Premium</a>
        <?php endif; ?>
    </nav>
</header>

<main class="bt-main">
    <div class="page-header">
        <h1>Read History</h1>
    </div>

    <?php if ($completedBooks): ?>
        <div class="book-grid">
            <?php foreach ($completedBooks as $b): ?>
                <div class="book-card">
                    <a href="book.php?id=<?= $b['id'] ?>">
                        <img src="<?= bt_cover_src($b['cover']) ?>" alt="<?= htmlspecialchars($b['title']) ?>">
                        <div class="book-title"><?= htmlspecialchars($b['title']) ?></div>
                    </a>
                    <?php if (!empty($b['completed_date'])): ?>
                        <p class="book-completed-date">Finished: <?= htmlspecialchars(date('M j, Y', strtotime($b['completed_date']))) ?></p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p class="no-books">You have not completed any books yet.</p>
    <?php endif; ?>
</main>

<script>
    // Sidebar toggle logic (same as your existing script)
    const sidebar = document.getElementById("sidebar");
    const toggleBtn = document.getElementById("toggleSidebar");
    const closeBtn = document.getElementById("closeSidebar");
    const mainContent = document.getElementById("bt-main");
    const topbar = document.getElementById("topbar");

    if (sidebar && toggleBtn && closeBtn) {
        function closeSidebar() {
            sidebar.classList.remove("is-expanded");
            if (mainContent) mainContent.classList.remove("is-shifted");
            if (topbar) topbar.classList.remove("is-shifted");
        }

        toggleBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            sidebar.classList.add("is-expanded");
            if (mainContent) mainContent.classList.add("is-shifted");
            if (topbar) topbar.classList.add("is-shifted");
        });

        closeBtn.addEventListener("click", closeSidebar);
        
        document.addEventListener("click", function(e) {
            if (sidebar.classList.contains("is-expanded") && !sidebar.contains(e.target) && e.target !== toggleBtn) {
                closeSidebar();
            }
        });
    }
</script>
</body>
</html>