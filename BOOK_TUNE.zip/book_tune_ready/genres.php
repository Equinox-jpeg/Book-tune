<?php
session_start();
require_once "db.php";

/* ---------- Helpers ---------- */
function bt_cover_src($val) {
    $fallback = 'covers/placeholder.jpg';
    if (!is_string($val) || trim($val) === '') return $fallback;
    if (preg_match('~^https?://~i', $val)) return $val;
    $file = ltrim($val, '/');
    foreach (["covers/$file", $file] as $p) {
        if (is_file($p)) return $p;
    }
    return $fallback;
}

/* ---------- Genre icon map ---------- */
$genre_icons = [
    'Browse All'        => 'fa-layer-group',
    'Classic'           => 'fa-book',
    'Fantasy'           => 'fa-hat-wizard',
    'Science Fiction'   => 'fa-rocket',
    'Romance'           => 'fa-heart',
    'Mystery'           => 'fa-user-secret',
    'Horror'            => 'fa-ghost',
    'History'           => 'fa-landmark',
    'Biography'         => 'fa-user',
    'Children'          => 'fa-child',
    'Comics'            => 'fa-book-open',
    'Poetry'            => 'fa-feather-alt',
    'Memoir'            => 'fa-book-reader',
    'Nonfiction'        => 'fa-glasses',
    'Thriller'          => 'fa-bolt',
    'Young Adult'       => 'fa-user-graduate',
    // fallback handled below
];

/* ---------- Data (genres + counts) ---------- */
$genreRows = $pdo->query("
    SELECT category, COUNT(*) AS cnt
    FROM books
    WHERE category IS NOT NULL AND category <> ''
    GROUP BY category
    ORDER BY category ASC
")->fetchAll(PDO::FETCH_ASSOC);

$genres = [];
$sampleStmt = $pdo->prepare("SELECT cover FROM books WHERE category = :cat ORDER BY created_at DESC LIMIT 1");
foreach ($genreRows as $row) {
    $cat = $row['category'];
    // sample cover maybe useful later; not used as images now
    $sampleStmt->execute(['cat' => $cat]);
    $sampleCover = $sampleStmt->fetchColumn();
    $genres[] = [
        'name' => $cat,
        'count' => (int)$row['cnt'],
        'icon' => $genre_icons[$cat] ?? 'fa-book-open'
    ];
}

/* ---------- Selected tab: 'all' by default ---------- */
$raw = isset($_GET['genre']) ? trim($_GET['genre']) : 'all';
$isAll = (strtolower($raw) === 'all' || $raw === '');
$currentGenre = $isAll ? 'All' : $raw;

/* ---------- Sorting (new) ---------- */
/* Allowed sorts:
    - latest => created_at DESC
    - most_viewed => views DESC
    - rating => rating DESC
    Default: latest
*/
$allowedSorts = [
    'latest' => 'created_at DESC, id DESC',
    'most_viewed' => 'views DESC, id DESC',
    'rating' => 'rating DESC, id DESC'
];
$sortKey = isset($_GET['sort']) && array_key_exists($_GET['sort'], $allowedSorts) ? $_GET['sort'] : 'latest';
$orderBy = $allowedSorts[$sortKey];

/* ---------- Initial books load (first page) ---------- */
$limit = 12;
$offset = 0;
try {
    if ($isAll) {
        $sql = "SELECT id, title, author, cover, rating, views FROM books ORDER BY $orderBy LIMIT :limit OFFSET :offset";
        $stmt = $pdo->prepare($sql);
    } else {
        $sql = "SELECT id, title, author, cover, rating, views FROM books WHERE category = :cat ORDER BY $orderBy LIMIT :limit OFFSET :offset";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':cat', $currentGenre, PDO::PARAM_STR);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
} catch (Throwable $e) {
    // If something goes wrong, fallback to a safe query
    $stmt = $pdo->prepare("SELECT id, title, author, cover, rating, views FROM books ORDER BY created_at DESC LIMIT :limit OFFSET :offset");
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
}
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* ---------- Corrected Avatar Logic ---------- */
$defaultAvatar = "assets/default-profile.png";
$profileImage = $defaultAvatar;
if (isset($_SESSION['user_id'])) {
    if (!empty($_SESSION['profile_pic'])) {
        $profileImage = htmlspecialchars($_SESSION['profile_pic']);
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Genres - Book-Tune</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@500;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="style.css">
<style>
:root{
  --bg:#0c1117; --panel:#0f141b; --panel-2:#141b23; --border:#1a2430;
  --text:#e7edf6; --muted:#9aa8bb; --brand:#7aa2ff;
}
body{background:var(--bg);color:var(--text);font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;margin:0;}
/* header + sidebar parity */
.bt-header{display:flex;align-items:center;justify-content:space-between;padding:12px 18px;border-bottom:1px solid rgba(255,255,255,0.02)}
.bt-logo{font-weight:800}
.header-left{display:flex;align-items:center;gap:10px}
.header-home{display:inline-flex;align-items:center;justify-content:center;padding:6px 10px;border-radius:999px;border:1px solid var(--border);background:var(--panel-2);color:var(--text);text-decoration:none}
.header-title{margin:14px 18px 8px;font-size:clamp(1.15rem,1.05rem+0.7vw,1.6rem);font-weight:800}

/* layout: left genre panel + right content */
.page-wrap { display: grid; grid-template-columns: 260px 1fr; gap: 24px; align-items:start; padding: 18px; }
@media (max-width: 900px) { .page-wrap { grid-template-columns: 1fr; padding: 12px; } }

/* left genre panel (icons) */
.genre-panel {
  background: linear-gradient(180deg, rgba(255,255,255,0.01), transparent);
  border: 1px solid var(--border); border-radius:14px; padding: 12px; height: fit-content;
}
.genre-panel h3 { margin: 6px 8px 12px; font-size:1.05rem; font-weight:800; }
.genre-list-vertical { display:flex; flex-direction:column; gap:8px; max-height: calc(100vh - 220px); overflow:auto; padding-right:6px; }
.genre-item-vertical {
  display:flex; gap:12px; align-items:center; padding:10px; border-radius:10px; text-decoration:none; color:var(--text);
  background:transparent; border:1px solid transparent; transition: background .15s, transform .12s, border-color .15s;
}
.genre-item-vertical:hover { background: rgba(122,162,255,0.05); transform: translateY(-2px); border-color: rgba(122,162,255,0.08); }
.genre-item-vertical.active { background: var(--brand); color:#fff; border-color:var(--brand); box-shadow: 0 8px 20px rgba(0,0,0,0.35); }

/* icon box */
.genre-icon {
  width:46px; height:46px; display:inline-flex; align-items:center; justify-content:center;
  border-radius:10px; background:linear-gradient(180deg, rgba(255,255,255,0.02), transparent); border:1px solid rgba(255,255,255,0.02);
  color:var(--muted); font-size:1.1rem;
}
.genre-item-vertical.active .genre-icon { background: rgba(255,255,255,0.04); color:#fff; }

/* meta */
.genre-meta { display:flex; flex-direction:column; gap:2px; }
.genre-name { font-weight:700; font-size:.95rem; }
.genre-count { font-size:.82rem; color:var(--muted); }

/* right side (title + search) */
.right-top { display:flex; flex-direction:column; gap:12px; margin-bottom: 6px; }
.right-row { display:flex; align-items:center; gap:12px; justify-content:space-between; }
.page-title { font-size:clamp(1.15rem,1.05rem+0.7vw,1.45rem); font-weight:800; margin:0; }

/* sort dropdown */
.sort-select {
  appearance: none;
  -webkit-appearance: none;
  background: var(--panel);
  border: 1px solid var(--border);
  color: var(--text);
  padding: 8px 10px;
  border-radius: 10px;
  font-size: .95rem;
  margin-left: 12px;
}

/* search */
.gen-search{display:flex;gap:10px;align-items:center;margin:6px 0 0}
.gen-search__box{flex:1;display:flex;align-items:center;gap:10px;background:var(--panel);border:1px solid var(--border);border-radius:999px;padding:10px 14px}
.gen-search__box input{flex:1;border:0;background:transparent;color:var(--text);outline:none;font-size:.96rem}
.gen-search__btn{height:36px;min-width:36px;border-radius:999px;border:0;background:var(--brand);color:#fff;display:inline-flex;align-items:center;justify-content:center;padding:0 12px;cursor:pointer}

/* grid & cards */
.bt-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:18px}
.bt-card{background:var(--panel);border:1px solid var(--border);border-radius:14px;padding:12px;box-shadow:0 10px 30px rgba(0,0,0,.35);transition:transform .18s}
.bt-card:hover{transform:translateY(-6px)}
.bt-card__cover{border-radius:12px;overflow:hidden}
.bt-card__cover img{width:100%;height:230px;object-fit:cover;background:#0b0f15;display:block;transition:transform .4s}
.bt-card:hover .bt-card__cover img{transform:scale(1.03)}
.bt-card__title{margin:10px 0 4px;font-weight:800;font-size:.98rem}
.bt-card__author{font-size:.86rem;color:var(--muted)}
.bt-card__meta{margin-top:6px;font-size:.82rem;color:var(--muted);display:flex;gap:10px;justify-content:center}

/* load more */
.load-more{display:block;margin:20px auto;padding:10px 20px;border-radius:10px;border:0;background:var(--brand);color:#fff;cursor:pointer;font-weight:700}

/* small screens adjustments */
@media (max-width:900px){
  .genre-list-vertical{flex-direction:row;gap:12px;overflow-x:auto;padding:8px}
  .genre-item-vertical{min-width:120px;flex-direction:column;align-items:flex-start;padding:8px 10px}
  .genre-icon{width:100%;height:96px;border-radius:8px;font-size:1.5rem}
}

/* Corrected spacing in the header for the user menu */
.user-menu {
    display: flex;
    align-items: center;
    gap: 12px; /* Add spacing between the profile link and the logout button */
}
.user-profile-link {
    display: flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    color: var(--text);
    transition: opacity 0.2s;
}

.user-profile-link:hover {
    opacity: 0.8;
}
</style>
</head>
<body class="<?= isset($_SESSION['user_id']) ? 'logged-in' : '' ?>">

<aside class="bt-sidebar" id="sidebar">
    <div class="bt-sidebar__brand">
        Menu
        <button id="closeSidebar" class="bt-sidebar__toggle"><i class="fas fa-chevron-left"></i></button>
    </div>

    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="profile.php" class="sidebar-profile">
            <img src="<?= $profileImage ?>" alt="Profile" class="sidebar-avatar">
            <span class="sidebar-username"><?= htmlspecialchars($_SESSION['username']) ?></span>
        </a>
    <?php endif; ?>

    <button id="sidebarCloseInside" class="bt-sidebar__close-top"><i class="fas fa-arrow-left"></i></button>

    <nav class="bt-nav">
        <a href="index.php" class="bt-nav__item"><i class="fas fa-home"></i><span class="bt-nav__text">Home</span></a>
        <a href="genres.php" class="bt-nav__item active"><i class="fas fa-th-large"></i><span class="bt-nav__text">Genres</span></a>
        <a href="index.php#popular" class="bt-nav__item"><i class="fas fa-fire"></i><span class="bt-nav__text">Popular</span></a>
        <a href="index.php#new-releases" class="bt-nav__item"><i class="fas fa-star"></i><span class="bt-nav__text">New Releases</span></a>
        <a href="premium.php" class="bt-nav__item"><i class="fas fa-crown"></i><span class="bt-nav__text">Premium</span></a>
        <a href="upload.php" class="bt-nav__item"><i class="fas fa-upload"></i><span class="bt-nav__text">Upload</span></a>
    </nav>
</aside>

<header class="bt-header" id="topbar">
    <div class="bt-header__left">
        <button id="toggleSidebar" class="bt-sidebar__toggle"><i class="fas fa-bars"></i></button>
        <div class="bt-logo">BOOK-TUNE</div>
        <form class="bt-search" method="GET" action="search.php" style="margin-left:14px;">
            <input type="text" name="q" placeholder="Search books..." required style="padding:8px 10px;border-radius:8px;border:1px solid rgba(255,255,255,0.04);background:transparent;color:var(--text)">
            <button type="submit" class="bt-btn bt-btn--search" style="margin-left:8px;"><i class="fas fa-search"></i></button>
        </form>
    </div>

    <nav class="bt-header__right">
        <?php if (isset($_SESSION['user_id'])): ?>
            <div class="user-menu">
                <a href="profile.php" class="user-profile-link">
                    <img src="<?= $profileImage ?>" alt="Profile" class="user-avatar" style="width:32px;height:32px;border-radius:999px;object-fit:cover;">
                    <span class="username"><?= htmlspecialchars($_SESSION['username']) ?></span>
                </a>
                <a href="logout.php" class="bt-btn bt-btn--ghost">Logout</a>
            </div>
        <?php else: ?>
            <a class="bt-btn bt-btn--ghost" href="login.php">Login</a>
            <a class="bt-btn bt-btn--ghost" href="signup.php">Sign Up</a>
            <a class="bt-btn bt-btn--gold" href="premium.php">Go Premium</a>
        <?php endif; ?>
    </nav>
</header>

<h1 class="header-title" style="margin-left:22px">Browse: <?= htmlspecialchars($currentGenre) ?></h1>

<div class="page-wrap">

    <aside class="genre-panel" aria-label="Genres">
        <h3>Genres</h3>
        <nav class="genre-list-vertical" id="genreListVertical">
            <a class="genre-item-vertical <?= $isAll ? 'active' : '' ?>" href="genres.php?genre=all">
                <div class="genre-icon"><i class="fas <?= htmlspecialchars($genre_icons['Browse All'] ?? 'fa-layer-group') ?>"></i></div>
                <div class="genre-meta"><span class="genre-name">Browse All</span><span class="genre-count"><?= array_sum(array_column($genreRows, 'cnt')) ?> books</span></div>
            </a>

            <?php foreach ($genres as $g): ?>
                <a class="genre-item-vertical <?= (!$isAll && $g['name'] === $currentGenre) ? 'active' : '' ?>"
                   href="genres.php?genre=<?= urlencode($g['name']) ?>">
                    <div class="genre-icon"><i class="fas <?= htmlspecialchars($g['icon']) ?>"></i></div>
                    <div class="genre-meta">
                        <span class="genre-name"><?= htmlspecialchars($g['name']) ?></span>
                        <span class="genre-count"><?= $g['count'] ?> books</span>
                    </div>
                </a>
            <?php endforeach; ?>
        </nav>
    </aside>

    <section>
        <div class="right-top">
            <div class="right-row">
                <h2 class="page-title" style="margin:0;display:flex;align-items:center;gap:12px;">
                    <span>Browse: <?= htmlspecialchars($currentGenre) ?></span>

                    <form id="sortForm" method="GET" style="display:inline-flex;align-items:center;margin:0;">
                        <input type="hidden" name="genre" value="<?= htmlspecialchars($raw) ?>">
                        <select name="sort" class="sort-select" onchange="document.getElementById('sortForm').submit()">
                            <option value="latest" <?= $sortKey === 'latest' ? 'selected' : '' ?>>Latest</option>
                            <option value="most_viewed" <?= $sortKey === 'most_viewed' ? 'selected' : '' ?>>Most Viewed</option>
                            <option value="rating" <?= $sortKey === 'rating' ? 'selected' : '' ?>>Top Rated</option>
                        </select>
                    </form>
                </h2>
            </div>

            <div class="gen-search">
                <div class="gen-search__box">
                    <i class="fas fa-search" style="opacity:.7"></i>
                    <input id="genreSearchInput" type="text" placeholder="Search titles or authors in <?= htmlspecialchars($currentGenre) ?>…">
                </div>
                <button id="genreSearchBtn" class="gen-search__btn" type="button">Search</button>
            </div>
        </div>

        <?php if (!$books): ?>
            <p>No books found.</p>
        <?php else: ?>
            <div class="bt-grid" id="genreGrid">
                <?php foreach ($books as $b): ?>
                    <article class="bt-card">
                        <a class="bt-card__cover" href="book.php?id=<?= (int)$b['id'] ?>">
                            <img
                                src="<?= htmlspecialchars(bt_cover_src($b['cover']), ENT_QUOTES, 'UTF-8') ?>"
                                alt="<?= htmlspecialchars($b['title']) ?>"
                                data-title="<?= htmlspecialchars($b['title']) ?>"
                                data-author="<?= htmlspecialchars($b['author']) ?>"
                                data-local="<?= preg_match('~^https?://~i', (string)$b['cover']) ? '0' : '1' ?>"
                                onerror="this.onerror=null;this.src='covers/placeholder.jpg';"
                            >
                        </a>
                        <h3 class="bt-card__title"><a href="book.php?id=<?= (int)$b['id'] ?>"><?= htmlspecialchars($b['title']) ?></a></h3>
                        <p class="bt-card__author"><?= htmlspecialchars($b['author']) ?></p>
                        <div class="bt-card__meta">
                            <span>⭐ <?= (float)$b['rating'] ?></span>
                            <span>👁 <?= (int)$b['views'] ?></span>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>

            <?php if (count($books) >= $limit): ?>
                <button id="loadMoreBtn" class="load-more"
                        data-genre="<?= $isAll ? 'all' : htmlspecialchars($currentGenre, ENT_QUOTES) ?>"
                        data-sort="<?= htmlspecialchars($sortKey, ENT_QUOTES) ?>"
                        data-offset="<?= count($books) ?>" data-limit="<?= $limit ?>">
                    Load More
                </button>
            <?php endif; ?>
        <?php endif; ?>
    </section>

</div><script>
// Sidebar toggle (copied from index)
document.getElementById('toggleSidebar').addEventListener('click', function() {
    document.getElementById('sidebar').classList.add('is-expanded');
    document.getElementById('mainContent')?.classList.add('is-shifted');
    document.getElementById('topbar')?.classList.add('is-shifted');
});
document.getElementById('closeSidebar').addEventListener('click', function() {
    document.getElementById('sidebar').classList.remove('is-expanded');
    document.getElementById('mainContent')?.classList.remove('is-shifted');
    document.getElementById('topbar')?.classList.remove('is-shifted');
});
document.getElementById('sidebarCloseInside').addEventListener('click', function() {
    document.getElementById('sidebar').classList.remove('is-expanded');
    document.getElementById('mainContent')?.classList.remove('is-shifted');
    document.getElementById('topbar')?.classList.remove('is-shifted');
});

// Instant client-side search (title/author)
(function(){
    const input = document.getElementById('genreSearchInput');
    const btn = document.getElementById('genreSearchBtn');
    const grid = document.getElementById('genreGrid');
    if (!input || !grid) return;
    const filter = () => {
        const q = input.value.trim().toLowerCase();
        grid.querySelectorAll('.bt-card').forEach(card=>{
            const title = card.querySelector('.bt-card__title')?.textContent.toLowerCase()||'';
            const author = card.querySelector('.bt-card__author')?.textContent.toLowerCase()||'';
            card.style.display = (q === '' || title.includes(q) || author.includes(q)) ? '' : 'none';
        });
    };
    input.addEventListener('input', filter);
    btn.addEventListener('click', filter);
})();

// Load More - fetches from load_more_genre.php (now includes sort param)
document.getElementById('loadMoreBtn')?.addEventListener('click', async function(){
    const btn = this;
    const genre = btn.dataset.genre || 'all';
    const sort = btn.dataset.sort || 'latest';
    let offset = parseInt(btn.dataset.offset,10) || 0;
    const limit = parseInt(btn.dataset.limit,10) || 12;
    btn.disabled = true;
    btn.textContent = 'Loading...';

    try {
        const res = await fetch(`load_more_genre.php?genre=${encodeURIComponent(genre)}&sort=${encodeURIComponent(sort)}&offset=${offset}&limit=${limit}`);
        if (!res.ok) throw new Error('network error');
        const books = await res.json();
        if (!books.length) {
            btn.remove();
            return;
        }

        const grid = document.getElementById('genreGrid');
        books.forEach(b=>{
            const card = document.createElement('article');
            card.className = 'bt-card';
            card.innerHTML = `
                <a class="bt-card__cover" href="book.php?id=${b.id}">
                    <img src="${b.cover}" alt="${escapeHtml(b.title)}" data-title="${escapeHtml(b.title)}" data-author="${escapeHtml(b.author)}" data-local="${b.cover_local ? '1' : '0'}" onerror="this.onerror=null;this.src='covers/placeholder.jpg'">
                </a>
                <h3 class="bt-card__title"><a href="book.php?id=${b.id}">${escapeHtml(b.title)}</a></h3>
                <p class="bt-card__author">${escapeHtml(b.author)}</p>
                <div class="bt-card__meta"><span>⭐ ${b.rating}</span><span>👁 ${b.views}</span></div>
            `;
            grid.appendChild(card);
        });

        offset += books.length;
        btn.dataset.offset = offset;
        if (books.length < limit) btn.remove();

        // try to autofill covers for appended items
        resolveCoversForSelector('#genreGrid img[data-title][data-author]');
    } catch (err) {
        console.error(err);
        btn.textContent = 'Load More';
        btn.disabled = false;
    }
});

// Utility to escape text when inserting as innerHTML
function escapeHtml(s){ return String(s).replace(/[&<>"'`]/g, function(ch){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;',"`":'&#96;'}[ch]; }); }

/* ---------- OpenLibrary autofetch (shared function) ---------- */
async function getOpenLibraryCover(title, author) {
    const qs = new URLSearchParams({ title, author, limit: 1 });
    try {
        const res = await fetch('https://openlibrary.org/search.json?' + qs.toString());
        if (!res.ok) return null;
        const data = await res.json();
        if (!data?.docs?.length) return null;
        const d = data.docs[0];
        if (d.cover_edition_key) return `https://covers.openlibrary.org/b/olid/${d.cover_edition_key}-L.jpg`;
        if (Array.isArray(d.isbn) && d.isbn.length) return `https://covers.openlibrary.org/b/isbn/${d.isbn[0]}-L.jpg`;
        if (typeof d.cover_i === 'number') return `https://covers.openlibrary.org/b/id/${d.cover_i}-L.jpg`;
        return null;
    } catch {
        return null;
    }
}

async function resolveCoversForSelector(selector) {
    const imgs = document.querySelectorAll(selector);
    if (!imgs.length) return;
    const cache = new Map();
    for (const img of imgs) {
        const title = img.getAttribute('data-title') || '';
        const author = img.getAttribute('data-author') || '';
        const isLocal = img.getAttribute('data-local') === '1';
        const src = img.getAttribute('src') || '';
        const isPlaceholder = /covers\/placeholder\.jpg$/i.test(src);
        if (!title || !author) continue;
        if (isPlaceholder || isLocal) {
            const key = (title + '|' + author).toLowerCase().trim();
            if (cache.has(key)) {
                const url = cache.get(key);
                if (url) img.src = url;
                continue;
            }
            const url = await getOpenLibraryCover(title, author);
            cache.set(key, url);
            if (url) img.src = url;
        }
    }
}

// Run autofill on initial items
resolveCoversForSelector('#genreGrid img[data-title][data-author]');
</script>
</body>
</html>