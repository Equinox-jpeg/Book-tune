<?php
// Start the session at the very beginning
session_start();

// This script will update the user's session data on every page load.
// It should be included in every file that requires user information.

// Check if a user is logged in
if (isset($_SESSION['user_id'])) {
    require_once 'db.php'; // Make sure this path is correct

    // Fetch the user's latest information from the database
    $stmt = $pdo->prepare("SELECT username, is_premium FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Update the session variables with the fresh data
        $_SESSION['username'] = $user['username'];
        $_SESSION['is_premium'] = $user['is_premium'];
    } else {
        // If the user doesn't exist, destroy the session
        session_destroy();
        header("Location: login.php");
        exit;
    }
}
?>