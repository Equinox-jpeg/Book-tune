<?php
session_start();
require_once "db.php";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Validate book_id and status
if (!isset($_GET['book_id']) || !isset($_GET['status'])) {
    die("Invalid request.");
}

$bookId = (int)$_GET['book_id'];
$status = $_GET['status'];

// Map status to database values
$statusMap = [
    'plan' => 'plan_to_read',
    'reading' => 'reading',
    'completed' => 'completed'
];

if (!array_key_exists($status, $statusMap)) {
    die("Invalid status.");
}

// Update or insert into library
$stmt = $pdo->prepare("
    INSERT INTO library (user_id, book_id, status) 
    VALUES (?, ?, ?)
    ON DUPLICATE KEY UPDATE status = ?
");
$stmt->execute([
    $_SESSION['user_id'],
    $bookId,
    $statusMap[$status],
    $statusMap[$status]
]);

// Redirect back to the book page
header("Location: book.php?id=" . $bookId);
exit;
?>