<?php
session_start();
require_once "db.php";

// Must be logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$commentId = isset($_POST['comment_id']) ? (int)$_POST['comment_id'] : 0;
$bookId = isset($_POST['book_id']) ? (int)$_POST['book_id'] : 0;

if ($commentId <= 0 || $bookId <= 0) {
    header("Location: book.php?id=" . $bookId . "&error=invalid");
    exit;
}

// Fetch the comment to check ownership
$stmt = $pdo->prepare("SELECT * FROM comments WHERE id = ?");
$stmt->execute([$commentId]);
$comment = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$comment) {
    header("Location: book.php?id=" . $bookId . "&error=notfound");
    exit;
}

// Check if user is owner or admin
if ($comment['user_id'] != $_SESSION['user_id'] && ($_SESSION['is_admin'] ?? 0) != 1) {
    header("Location: book.php?id=" . $bookId . "&error=denied");
    exit;
}

// Delete comment
$stmt = $pdo->prepare("DELETE FROM comments WHERE id = ?");
$stmt->execute([$commentId]);

header("Location: book.php?id=" . $bookId . "&deleted=1");
exit;
