<?php
session_start();
require_once "db.php";
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM books WHERE id = ?");
$stmt->execute([$id]);
$book = $stmt->fetch(PDO::FETCH_ASSOC);
if(!$book){ header("HTTP/1.0 404 Not Found"); echo "Book not found"; exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?php echo htmlspecialchars($book['title']); ?> - Book‑Tune</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <header class="site-header">
    <h1 class="logo">📚 Book‑Tune</h1>
    <a class="back-btn" href="index.php">← Back</a>
  </header>
  <main class="book-detail-card fade-in">
    <img src="<?php echo 'covers/'.htmlspecialchars($book['cover']); ?>" alt="<?php echo htmlspecialchars($book['title']); ?> cover" onerror="this.src='covers/_placeholder.png'">
    <div>
      <h2><?php echo htmlspecialchars($book['title']); ?></h2>
      <p class="muted"><?php echo htmlspecialchars($book['author']); ?> · <em><?php echo htmlspecialchars($book['category']); ?></em></p>
      <p><?php echo nl2br(htmlspecialchars($book['description'])); ?></p>
    </div>
  </main>
  <footer class="site-footer"><p>© <?php echo date('Y'); ?> Book‑Tune</p></footer>
</body>
</html>
