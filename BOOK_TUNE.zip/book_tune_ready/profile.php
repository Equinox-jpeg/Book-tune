<?php
session_start();
require_once "db.php";

// Check for session and redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Fetch user data from the database
$stmt = $pdo->prepare("SELECT username, bio, profile_pic FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    // Should not happen, but a safeguard
    header("Location: logout.php");
    exit;
}

// Set the profile image path. Prioritize database value, fallback to default.
$defaultAvatar = "assets/default-profile.png";
$profileImage = !empty($user['profile_pic']) ? $user['profile_pic'] : $defaultAvatar;

// Cover helper for local/remote images - MODIFIED to use Open Library
function bt_cover_src($val) {
    // Check if the value is an Open Library ID (starts with "OL")
    if (strpos($val, 'OL') === 0) {
        return "https://covers.openlibrary.org/b/olid/" . htmlspecialchars($val) . "-M.jpg";
    }
    // Check if it's an ISBN
    if (is_numeric($val) && strlen($val) >= 10) {
        return "https://covers.openlibrary.org/b/isbn/" . htmlspecialchars($val) . "-M.jpg";
    }
    // Fallback for local files or other cases
    return (preg_match('/^https?:\\/\\//', $val) ? $val : 'covers/' . htmlspecialchars($val));
}

// Get user's library grouped by status
$statuses = ['reading', 'plan_to_read', 'completed'];
$library = [];
foreach ($statuses as $s) {
    $stmt = $pdo->prepare("SELECT b.* FROM library l
                            JOIN books b ON l.book_id = b.id
                            WHERE l.user_id = ? AND l.status = ?");
    $stmt->execute([$_SESSION['user_id'], $s]);
    $library[$s] = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($user['username']) ?>'s Profile - Book-Tune</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@500;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg: #111827;
            --panel: #1f2937;
            --panel-2: #374151;
            --border: #4b5563;
            --text: #f9fafb;
            --muted: #9ca3af;
            --brand: #6366f1;
            --shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            --brand-2: #ff7ac6;
            --gold: #f5b041;
        }

        body { 
            font-family: 'Inter', sans-serif; 
            background: var(--bg); 
            color: var(--text); 
            margin: 0; 
            padding: 0; 
            overflow-x: hidden;
        }
        a { color: var(--brand); text-decoration: none; }
        a:hover { text-decoration: underline; }
        .bt-main { padding: 80px 20px 20px 20px; max-width: 1200px; margin: 0 auto; transition: margin-left 0.3s ease; }
        @media (min-width: 768px) { 
            .bt-main { padding-left: 280px; } 
            .bt-main.is-shifted { margin-left: 250px; }
        }

        /* Sidebar & Header */
        .bt-sidebar { 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 250px; 
            height: 100%; 
            background: var(--panel); 
            border-right: 1px solid var(--border); 
            padding: 20px; 
            transition: transform 0.3s ease; 
            z-index: 100;
            transform: translateX(-100%);
        }
        .bt-sidebar.is-expanded { 
            transform: translateX(0);
        }
        .bt-sidebar__brand { font-weight: 800; font-size: 1.5rem; margin-bottom: 20px; color: var(--brand); }
        .bt-sidebar__toggle { background: transparent; border: none; color: var(--text); font-size: 1.5rem; cursor: pointer; }
        .bt-sidebar .sidebar-profile { display: flex; align-items: center; gap: 10px; margin-bottom: 20px; }
        .bt-sidebar .sidebar-avatar { width: 50px; height: 50px; border-radius: 50%; object-fit: cover; border: 2px solid var(--brand); }
        .bt-sidebar .sidebar-username { font-weight: bold; }
        .bt-nav { display: flex; flex-direction: column; gap: 10px; }
        .bt-nav__item { display: flex; align-items: center; gap: 15px; padding: 10px 15px; border-radius: 10px; transition: background-color 0.2s; }
        .bt-nav__item:hover { background-color: var(--panel-2); }
        .bt-nav__item i { font-size: 1.2rem; }
        
        .bt-header { 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 60px; 
            background: var(--panel); 
            border-bottom: 1px solid var(--border); 
            display: flex; 
            align-items: center; 
            justify-content: space-between; 
            padding: 0 20px; 
            z-index: 50; 
        }
        .bt-header__left { display: flex; align-items: center; gap: 20px; }
        .bt-logo { font-weight: 800; color: var(--brand); font-size: 1.2rem; }
        .bt-btn { padding: 8px 16px; border-radius: 999px; border: 1px solid var(--border); background: var(--panel-2); color: var(--text); font-size: 14px; font-weight: 600; cursor: pointer; transition: all .2s ease; }
        .bt-btn:hover { background: var(--brand); color:#fff; border-color:var(--brand); }
        .bt-btn--primary { background: var(--brand); color:#fff; border:none; }
        .bt-btn--primary:hover { background: #5f86ff; }
        .bt-btn--ghost { background: transparent; border: none; }
        .bt-btn--gold { background: var(--gold); color: #000; border: none; font-weight: 700; }
        .bt-search { position: relative; width: 300px; }
        .bt-search input { width: 100%; padding: 8px 40px 8px 15px; border-radius: 999px; border: 1px solid var(--border); background: var(--panel-2); color: var(--text); font-size: 14px; }
        .bt-search button { position: absolute; right: 8px; top: 50%; transform: translateY(-50%); background: none; border: none; color: var(--muted); cursor: pointer; }
        .user-menu { display: flex; align-items: center; gap: 10px; }
        .user-avatar { width: 35px; height: 35px; border-radius: 50%; object-fit: cover; }
        .username { font-weight: 600; }

        /* Profile-specific styles */
        .profile-header { display: flex; align-items: center; gap: 20px; background: var(--panel); border-radius: 12px; padding: 30px; margin-bottom: 30px; box-shadow: var(--shadow); }
        .profile-header .avatar { width: 120px; height: 120px; border-radius: 50%; object-fit: cover; border: 4px solid var(--brand); }
        .profile-details h1 { margin: 0 0 5px; font-size: 2.5rem; font-weight: 800; }
        .profile-details p { margin: 0 0 15px; font-size: 1rem; color: var(--muted); line-height: 1.6; }
        .profile-details .btn-group { display: flex; gap: 10px; }
        .library-section { margin-bottom: 40px; }
        .library-section h2 { font-size: 1.8rem; border-bottom: 1px solid var(--border); padding-bottom: 10px; margin-bottom: 20px; }
        .book-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 20px; }
        .book-card { background: var(--panel); border-radius: 10px; overflow: hidden; box-shadow: var(--shadow); transition: transform 0.2s ease; }
        .book-card:hover { transform: translateY(-5px); }
        .book-card a { display: block; }
        .book-card img { width: 100%; height: 200px; object-fit: cover; display: block; }
        .book-card .book-title { padding: 10px; text-align: center; font-weight: 600; font-size: 1rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .no-books { color: var(--muted); font-style: italic; text-align: center; padding: 20px; }

        @media (max-width: 767px) {
            .profile-header { flex-direction: column; text-align: center; }
            .profile-details { text-align: center; }
            .bt-main { padding-top: 80px; }
            .bt-header { justify-content: flex-start; }
            .bt-header__left { gap: 10px; }
        }
    </style>
</head>
<body>

<aside class="bt-sidebar" id="sidebar">
    <div class="bt-sidebar__brand">
        Menu
        <button id="closeSidebar" class="bt-sidebar__toggle">
            <i class="fas fa-chevron-left"></i>
        </button>
    </div>

    <?php if (isset($_SESSION['user_id'])): ?>
    <a href="profile.php" class="sidebar-profile">
        <img src="<?= htmlspecialchars($profileImage) ?>" alt="Profile" class="sidebar-avatar">
        <span class="sidebar-username"><?= htmlspecialchars($user['username']) ?></span>
    </a>
    <?php endif; ?>

    <button id="sidebarCloseInside" class="bt-sidebar__close-top">
        <i class="fas fa-arrow-left"></i>
    </button>

    <nav class="bt-nav">
        <a href="index.php" class="bt-nav__item"><i class="fas fa-home"></i><span class="bt-nav__text">Home</span></a>
        <a href="genres.php" class="bt-nav__item"><i class="fas fa-th-large"></i><span class="bt-nav__text">Genres</span></a>
        <a href="index.php#popular" class="bt-nav__item scroll-link"><i class="fas fa-fire"></i><span class="bt-nav__text">Popular</span></a>
        <a href="index.php#new-releases" class="bt-nav__item scroll-link"><i class="fas fa-star"></i><span class="bt-nav__text">New Releases</span></a>
        <a href="premium.php" class="bt-nav__item"><i class="fas fa-crown"></i><span class="bt-nav__text">Premium</span></a>
        <a href="upload.php" class="bt-nav__item"><i class="fas fa-upload"></i><span class="bt-nav__text">Upload</span></a>
    </nav>
</aside>

<header class="bt-header" id="topbar">
    <div class="bt-header__left">
        <button id="toggleSidebar" class="bt-sidebar__toggle"><i class="fas fa-bars"></i></button>
        <div class="bt-logo">BOOK-TUNE</div>
        <form class="bt-search" method="GET" action="search.php">
            <input type="text" name="q" placeholder="Search books..." required>
            <button type="submit" class="bt-btn bt-btn--search"><i class="fas fa-search"></i></button>
        </form>
    </div>

    <nav class="bt-header__right">
        <?php if (isset($_SESSION['user_id'])): ?>
            <div class="user-menu">
                <img src="<?= htmlspecialchars($profileImage) ?>" alt="Profile" class="user-avatar">
                <span class="username"><?= htmlspecialchars($user['username']) ?></span>
                <a href="logout.php" class="bt-btn bt-btn--ghost">Logout</a>
            </div>
        <?php else: ?>
            <a class="bt-btn bt-btn--ghost" href="login.php">Login</a>
            <a class="bt-btn bt-btn--ghost" href="signup.php">Sign Up</a>
            <a class="bt-btn bt-btn--gold" href="premium.php">Go Premium</a>
        <?php endif; ?>
    </nav>
</header>

<main class="bt-main">
    <div class="profile-header">
        <img src="<?= htmlspecialchars($profileImage) ?>" alt="Avatar" class="avatar">
        <div class="profile-details">
            <h1><?= htmlspecialchars($user['username']) ?></h1>
            <p><?= nl2br(htmlspecialchars($user['bio'])) ?: "No bio yet." ?></p>
            <div class="btn-group">
                <a href="edit_profile.php" class="bt-btn bt-btn--primary"><i class="fas fa-user-edit"></i> Edit Profile</a>
            </div>
        </div>
    </div>

    <?php foreach ($statuses as $s): ?>
    <section class="library-section">
        <h2><?= ucfirst(str_replace('_',' ', $s)) ?></h2>
        <?php if ($library[$s]): ?>
            <div class="book-grid">
                <?php foreach ($library[$s] as $b): ?>
                    <div class="book-card">
                        <a href="book.php?id=<?= $b['id'] ?>">
                            <img src="<?= bt_cover_src($b['cover']) ?>" alt="<?= htmlspecialchars($b['title']) ?>">
                            <div class="book-title"><?= htmlspecialchars($b['title']) ?></div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="no-books">No books here yet.</p>
        <?php endif; ?>
    </section>
    <?php endforeach; ?>
</main>

<script>
    // Sidebar toggle logic
    const sidebar = document.getElementById("sidebar");
    const toggleBtn = document.getElementById("toggleSidebar");
    const closeBtn = document.getElementById("closeSidebar");
    const mainContent = document.getElementById("bt-main");
    const topbar = document.getElementById("topbar");

    if (sidebar && toggleBtn && closeBtn) {
        function closeSidebar() {
            sidebar.classList.remove("is-expanded");
            if (mainContent) mainContent.classList.remove("is-shifted");
            if (topbar) topbar.classList.remove("is-shifted");
        }

        toggleBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            sidebar.classList.add("is-expanded");
            if (mainContent) mainContent.classList.add("is-shifted");
            if (topbar) topbar.classList.add("is-shifted");
        });

        closeBtn.addEventListener("click", closeSidebar);
        
        document.addEventListener("click", function(e) {
            if (sidebar.classList.contains("is-expanded") && !sidebar.contains(e.target) && e.target !== toggleBtn) {
                closeSidebar();
            }
        });
    }
</script>
</body>
</html>