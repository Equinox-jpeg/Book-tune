<?php
// ... (your existing db.php code) ...

/**
 * Gets the user's avatar path, checking multiple columns and falling back to default.
 *
 * @param PDO $pdo The PDO database connection object.
 * @param int $user_id The ID of the user.
 * @param string $defaultPath The path to the default avatar.
 * @return string The valid avatar path.
 */
function get_user_avatar_path($pdo, $user_id, $defaultPath = 'assets/default-profile.png') {
    $stmt = $pdo->prepare("SELECT profile_pic, profile_image FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $avatars = $stmt->fetch(PDO::FETCH_ASSOC);

    // Prioritize profile_pic
    if (!empty($avatars['profile_pic']) && file_exists($avatars['profile_pic'])) {
        return htmlspecialchars($avatars['profile_pic']);
    }
    
    // If profile_pic is not valid, try profile_image
    if (!empty($avatars['profile_image']) && file_exists($avatars['profile_image'])) {
        return htmlspecialchars($avatars['profile_image']);
    }

    // If neither is valid, return the default path
    return htmlspecialchars($defaultPath);
}

?>