<?php
session_start();
require_once "db.php";

$searchTerm = '';
$users = [];

if (isset($_GET['q']) && trim($_GET['q']) !== '') {
    $searchTerm = trim($_GET['q']);
    $stmt = $pdo->prepare("SELECT id, username, profile_pic FROM users WHERE username LIKE ? LIMIT 20");
    $stmt->execute(["%$searchTerm%"]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$defaultAvatar = "assets/default-profile.png";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Search Users - BookTunes</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root {
  --bg-primary: #0b0f19;
  --bg-secondary: #141a29;
  --card-bg: #1c2433;
  --text-primary: #e8eef8;
  --text-secondary: #a0a8b4;
  --brand-color: #5d83ff;
  --border-color: #2e3b50;
  --shadow: 0 10px 40px rgba(0,0,0,0.4);
}

body {
  font-family: 'Inter', sans-serif;
  background: var(--bg-primary);
  color: var(--text-primary);
  margin: 0;
  padding: 0;
  min-height: 100vh;
}

.container {
  max-width: 800px;
  margin: 60px auto;
  background: var(--card-bg);
  border: 1px solid var(--border-color);
  border-radius: 16px;
  box-shadow: var(--shadow);
  padding: 40px;
}

h1 {
  text-align: center;
  margin-bottom: 30px;
  font-size: 1.8rem;
}

.search-box {
  display: flex;
  justify-content: center;
  margin-bottom: 30px;
}

.search-box input[type="text"] {
  width: 70%;
  padding: 12px;
  border-radius: 8px 0 0 8px;
  border: 1px solid var(--border-color);
  background: var(--bg-secondary);
  color: var(--text-primary);
  font-size: 1rem;
  outline: none;
}

.search-box button {
  padding: 12px 20px;
  border: none;
  background: var(--brand-color);
  color: white;
  font-weight: 600;
  border-radius: 0 8px 8px 0;
  cursor: pointer;
  transition: background 0.2s;
}

.search-box button:hover {
  background: #7a9aff;
}

.user-list {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.user-card {
  display: flex;
  align-items: center;
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
  border-radius: 12px;
  padding: 12px 16px;
  transition: transform 0.2s;
}

.user-card:hover {
  transform: translateY(-3px);
}

.user-card img {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid var(--brand-color);
  margin-right: 15px;
}

.user-card .info {
  flex-grow: 1;
}

.user-card .username {
  font-size: 1.1rem;
  font-weight: 600;
}

.user-card .username a {
  color: var(--text-primary);
  text-decoration: none;
}

.user-card .username a:hover {
  color: var(--brand-color);
}

.follow-btn {
  background: var(--brand-color);
  color: white;
  border: none;
  padding: 8px 14px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 0.9rem;
  font-weight: 600;
  transition: background 0.2s;
}

.follow-btn:hover {
  background: #7a9aff;
}

.unfollow-btn {
  background: #2e3b50;
}

.empty-msg {
  text-align: center;
  color: var(--text-secondary);
  margin-top: 30px;
}

.back-btn {
  display: block;
  text-align: center;
  margin-top: 35px;
  color: var(--text-secondary);
  text-decoration: none;
}

.back-btn:hover {
  color: var(--brand-color);
}
</style>
</head>
<body>
<div class="container">
  <h1>🔍 Search Users</h1>
  <form method="GET" class="search-box">
    <input type="text" name="q" placeholder="Search by username..." value="<?= htmlspecialchars($searchTerm) ?>">
    <button type="submit"><i class="fas fa-search"></i></button>
  </form>

  <?php if ($searchTerm !== ''): ?>
    <?php if (count($users) > 0): ?>
      <div class="user-list">
        <?php foreach ($users as $user): 
          $avatar = ($user['profile_pic'] && file_exists($user['profile_pic'])) ? $user['profile_pic'] : $defaultAvatar;

          // Check if current user follows this one
          $isFollowing = false;
          if (isset($_SESSION['user_id'])) {
              $stmt = $pdo->prepare("SELECT * FROM followers WHERE follower_id = ? AND followed_id = ?");
              $stmt->execute([$_SESSION['user_id'], $user['id']]);
              $isFollowing = $stmt->fetch() ? true : false;
          }
        ?>
        <div class="user-card">
          <img src="<?= htmlspecialchars($avatar) ?>" alt="<?= htmlspecialchars($user['username']) ?>">
          <div class="info">
            <div class="username">
              <a href="user_profile.php?id=<?= $user['id'] ?>"><?= htmlspecialchars($user['username']) ?></a>
            </div>
          </div>

          <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] != $user['id']): ?>
            <form action="toggle_follow.php" method="POST">
              <input type="hidden" name="followed_id" value="<?= $user['id'] ?>">
              <button type="submit" class="follow-btn <?= $isFollowing ? 'unfollow-btn' : '' ?>">
                <?= $isFollowing ? 'Unfollow' : 'Follow' ?>
              </button>
            </form>
          <?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="empty-msg">No users found matching “<?= htmlspecialchars($searchTerm) ?>”.</div>
    <?php endif; ?>
  <?php else: ?>
    <div class="empty-msg">Enter a username to start searching.</div>
  <?php endif; ?>

  <a href="profile.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to My Profile</a>
</div>
</body>
</html>
