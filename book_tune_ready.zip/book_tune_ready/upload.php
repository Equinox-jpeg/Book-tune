<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$message = "";

// Fetch if the user is premium
$stmt = $pdo->prepare("SELECT is_premium FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
$isPremiumUser = $user && $user['is_premium'] == 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $author = trim($_POST['author']);
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);
    $is_premium = isset($_POST['is_premium']) && $isPremiumUser ? 1 : 0;
    $views = rand(100, 5000);
    $rating = number_format(rand(30, 50) / 10, 1);

    $coverPath = "";
    $bookPath = "";

    // === Ensure directories exist ===
    if (!is_dir("covers")) mkdir("covers", 0777, true);
    if (!is_dir("books")) mkdir("books", 0777, true);

    // === Cover upload ===
    if (isset($_FILES['cover']) && $_FILES['cover']['error'] === UPLOAD_ERR_OK) {
        $coverTmp = $_FILES['cover']['tmp_name'];
        $coverName = basename($_FILES['cover']['name']);
        $coverExt = strtolower(pathinfo($coverName, PATHINFO_EXTENSION));

        if (in_array($coverExt, ["jpg", "jpeg", "png"])) {
            $newCoverName = uniqid("cover_") . "." . $coverExt;
            $coverPath = "covers/" . $newCoverName;
            if (!move_uploaded_file($coverTmp, $coverPath)) {
                $message = "❌ Failed to move cover file. Please check folder permissions.";
            }
        } else {
            $message = "❌ Invalid cover file type. Please upload JPG or PNG.";
        }
    } else {
        $message = "❌ Please select a cover image.";
    }

    // === Book file upload ===
    if (isset($_FILES['book_file']) && $_FILES['book_file']['error'] === UPLOAD_ERR_OK) {
        $bookTmp = $_FILES['book_file']['tmp_name'];
        $bookName = basename($_FILES['book_file']['name']);
        $bookExt = strtolower(pathinfo($bookName, PATHINFO_EXTENSION));

        if (in_array($bookExt, ["pdf", "epub"])) {
            $newBookName = uniqid("book_") . "." . $bookExt;
            $bookPath = "books/" . $newBookName;
            if (!move_uploaded_file($bookTmp, $bookPath)) {
                $message = "❌ Failed to upload book file. Check folder permissions.";
            }
        } else {
            $message = "❌ Invalid book file type. Only PDF and EPUB allowed.";
        }
    } else {
        $message = "❌ Please select a book file.";
    }

    // === Database insert ===
    if (empty($message)) {
        if (!empty($coverPath) && !empty($bookPath)) {
            $stmt = $pdo->prepare("INSERT INTO books (title, author, category, description, cover, file_path, views, rating, is_premium, created_at) 
                                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$title, $author, $category, $description, $coverPath, $bookPath, $views, $rating, $is_premium]);
            $message = "✅ Book uploaded successfully!" . ($is_premium ? " (Marked as Premium)" : "");
        } else {
            $message = "❌ Please upload both cover and book file.";
        }
    }
}

// Avatar setup
$defaultAvatar = "assets/default-profile.png";
if (isset($_SESSION['user_id'])) {
    $profileImage = !empty($_SESSION['profile_pic']) ? htmlspecialchars($_SESSION['profile_pic']) : $defaultAvatar;
} else {
    $profileImage = $defaultAvatar;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Upload Book - Book-Tune</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@500;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
.user-menu {
    display: flex;
    align-items: center;
    gap: 12px;
}
.user-profile-link {
    display: flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    color: var(--text);
}
.user-avatar {
    width: 32px;
    height: 32px;
    border-radius: 999px;
    object-fit: cover;
}
.upload-form {
    max-width: 500px;
    margin: 30px auto;
    background: var(--panel-2);
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
}
.upload-form input,
.upload-form textarea,
.upload-form button {
    width: 100%;
    margin-bottom: 15px;
}
.upload-form input,
.upload-form textarea {
    background: var(--panel);
    color: var(--text);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 10px;
}
.upload-form input[type="file"] {
    padding: 6px;
}
.upload-form button {
    background: var(--brand);
    color: white;
    padding: 12px;
    border: none;
    border-radius: 8px;
    font-size: 1rem;
    cursor: pointer;
    transition: 0.3s;
}
.upload-form button:hover {
    background: var(--brand-2);
}
.message {
    padding: 10px;
    border-radius: 8px;
    margin-bottom: 15px;
    background: var(--panel);
    color: gold;
}
.premium-note {
    color: #f6d84a;
    font-size: 0.9rem;
    margin-bottom: 10px;
}

/* === Modern Premium Toggle === */
.premium-toggle {
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 15px 0;
}

.toggle-switch {
    position: relative;
    display: inline-block;
    width: 46px;
    height: 24px;
}

.toggle-switch input {
    display: none;
}

.slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #444;
    transition: 0.3s;
    border-radius: 24px;
}

.slider::before {
    position: absolute;
    content: "";
    height: 18px;
    width: 18px;
    left: 3px;
    bottom: 3px;
    background-color: white;
    transition: 0.3s;
    border-radius: 50%;
}

/* Checked */
input[type="checkbox"]:checked + .slider {
    background-color: #f6d84a;
}

input[type="checkbox"]:checked + .slider::before {
    transform: translateX(22px);
}

.toggle-label {
    font-size: 0.95rem;
    color: var(--text);
}
</style>
</head>
<body class="<?= isset($_SESSION['user_id']) ? 'logged-in' : '' ?>">

<aside class="bt-sidebar" id="sidebar">
    <div class="bt-sidebar__brand">
        Menu
        <button id="closeSidebar" class="bt-sidebar__toggle">
            <i class="fas fa-chevron-left"></i>
        </button>
    </div>

    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="profile.php" class="sidebar-profile">
            <img src="<?= $profileImage ?>" alt="Profile" class="sidebar-avatar">
            <span class="sidebar-username"><?= htmlspecialchars($_SESSION['username']) ?></span>
        </a>
    <?php endif; ?>

    <nav class="bt-nav">
        <a href="index.php" class="bt-nav__item"><i class="fas fa-home"></i> Home</a>
        <a href="genres.php" class="bt-nav__item"><i class="fas fa-th-large"></i> Genres</a>
        <a href="premium.php" class="bt-nav__item"><i class="fas fa-crown"></i> Premium</a>
        <a href="upload.php" class="bt-nav__item active"><i class="fas fa-upload"></i> Upload</a>
    </nav>
</aside>

<header class="bt-header" id="topbar">
    <div class="bt-header__left">
        <button id="toggleSidebar" class="bt-sidebar__toggle"><i class="fas fa-bars"></i></button>
        <div class="bt-logo">BOOK-TUNE</div>
    </div>
    <nav class="bt-header__right">
        <?php if (isset($_SESSION['user_id'])): ?>
            <div class="user-menu">
                <a href="profile.php" class="user-profile-link">
                    <img src="<?= $profileImage ?>" alt="Profile" class="user-avatar">
                    <span class="username"><?= htmlspecialchars($_SESSION['username']) ?></span>
                </a>
                <a href="logout.php" class="bt-btn bt-btn--ghost">Logout</a>
            </div>
        <?php endif; ?>
    </nav>
</header>

<main class="bt-main" id="mainContent">
    <section class="bt-section">
        <h2 class="bt-section__title">Upload a Book</h2>
        <form method="POST" enctype="multipart/form-data" class="upload-form">
            <?php if ($message): ?>
                <div class="message"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>

            <input type="text" name="title" placeholder="Book Title" required>
            <input type="text" name="author" placeholder="Author Name" required>
            <input type="text" name="category" placeholder="Category" required>
            <textarea name="description" placeholder="Write a short description..." required></textarea>
            <label>📕 Upload Cover Image:</label>
            <input type="file" name="cover" accept=".jpg,.jpeg,.png" required>
            <label>📘 Upload Book File (PDF or EPUB):</label>
            <input type="file" name="book_file" accept=".pdf,.epub" required>

            <?php if ($isPremiumUser): ?>
            <div class="premium-toggle">
                <label class="toggle-switch">
                    <input type="checkbox" name="is_premium" value="1">
                    <span class="slider"></span>
                </label>
                <span class="toggle-label">Mark as Premium Book</span>
            </div>
            <?php else: ?>
                <div class="premium-note">
                    🔒 Only premium users can upload premium books. 
                    <a href="premium.php" style="color:#f6d84a;">Upgrade now</a>.
                </div>
            <?php endif; ?>

            <button type="submit">📤 Upload Book</button>
        </form>
    </section>
</main>

</body>
</html>
