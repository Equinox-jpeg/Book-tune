<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $author = trim($_POST['author']);
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);
    $views = rand(100, 5000);
    $rating = number_format(rand(30, 50) / 10, 1); // 3.0 to 5.0

    // Handle file upload
    if (isset($_FILES['cover']) && $_FILES['cover']['error'] === UPLOAD_ERR_OK) {
        $fileTmp = $_FILES['cover']['tmp_name'];
        $fileName = basename($_FILES['cover']['name']);
        $fileSize = $_FILES['cover']['size'];
        $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        // Validate file
        if (($fileType === "jpg" || $fileType === "jpeg" || $fileType === "png") && $fileSize <= 2 * 1024 * 1024) {
            $newFileName = uniqid() . "." . $fileType;
            move_uploaded_file($fileTmp, "covers/" . $newFileName);

            $stmt = $pdo->prepare("INSERT INTO books (title, author, category, description, cover, views, rating, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$title, $author, $category, $description, $newFileName, $views, $rating]);

            $message = "Book uploaded successfully!";
        } else {
            $message = "Invalid file. Please upload a JPG or PNG under 2MB.";
        }
    } else {
        $message = "Please select a cover image.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Upload Book - Book-Tune</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
:root {
    --brand1: #b03060;
    --brand2: #cc4c78;
    --bg: #121212;
    --card: #1e1e1e;
    --text: #ffffff;
}
body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background: var(--bg);
    color: var(--text);
    display: flex;
}
.sidebar {
    width: 200px;
    background: #1a1a1a;
    padding: 20px;
    flex-shrink: 0;
}
.sidebar h1 {
    font-size: 1.3rem;
    margin-bottom: 20px;
    color: var(--brand2);
}
.sidebar a {
    display: block;
    color: var(--text);
    text-decoration: none;
    padding: 10px 8px;
    border-radius: 4px;
    margin-bottom: 6px;
}
.sidebar a:hover {
    background: var(--brand1);
}
.main-content {
    flex: 1;
    padding: 20px;
}
h2.section-title {
    margin: 25px 0 10px;
    border-left: 5px solid var(--brand1);
    padding-left: 10px;
}
form {
    background: var(--card);
    padding: 20px;
    border-radius: 8px;
    max-width: 400px;
}
input, textarea {
    width: 100%;
    padding: 8px;
    margin: 6px 0;
    border: none;
    border-radius: 4px;
}
textarea {
    resize: vertical;
    height: 80px;
}
button {
    background: var(--brand1);
    color: white;
    padding: 10px 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
.message {
    margin-bottom: 10px;
    color: gold;
}
</style>
</head>
<body>
<div class="sidebar">
    <h1>Book-Tune</h1>
    <a href="index.php">Home</a>
    <a href="genres.php">Genres</a>
    <a href="#">Popular</a>
    <a href="#">New Releases</a>
    <a href="premium.php">Go Premium</a>
    <a href="upload.php">Upload Book</a>
</div>
<div class="main-content">
    <h2 class="section-title">Upload a Book</h2>
    <?php if ($message): ?>
        <div class="message"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="title" placeholder="Title" required>
        <input type="text" name="author" placeholder="Author" required>
        <input type="text" name="category" placeholder="Category" required>
        <textarea name="description" placeholder="Description" required></textarea>
        <input type="file" name="cover" accept=".jpg,.jpeg,.png" required>
        <button type="submit">Upload</button>
    </form>
</div>
</body>
</html>
