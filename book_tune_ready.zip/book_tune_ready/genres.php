<?php
require_once "db.php";
$genres = $pdo->query("SELECT DISTINCT category FROM books ORDER BY category ASC")->fetchAll(PDO::FETCH_COLUMN);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selected = $_POST['genres'] ?? [];
    if (!empty($selected)) {
        $placeholders = implode(',', array_fill(0, count($selected), '?'));
        $stmt = $pdo->prepare("SELECT * FROM books WHERE category IN ($placeholders)");
        $stmt->execute($selected);
        $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Find by Genre - Book-Tune</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
:root {
    --brand1: #b03060;
    --brand2: #cc4c78;
    --bg: #121212;
    --card: #1e1e1e;
    --text: #ffffff;
    --muted: #aaaaaa;
}
body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background: var(--bg);
    color: var(--text);
    display: flex;
}
.sidebar {
    width: 200px;
    background: #1a1a1a;
    padding: 20px;
    flex-shrink: 0;
}
.sidebar h1 {
    font-size: 1.3rem;
    margin-bottom: 20px;
    color: var(--brand2);
}
.sidebar a {
    display: block;
    color: var(--text);
    text-decoration: none;
    padding: 10px 8px;
    border-radius: 4px;
    margin-bottom: 6px;
}
.sidebar a:hover {
    background: var(--brand1);
}
.main-content {
    flex: 1;
    padding: 20px;
}
header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}
.search-bar {
    display: flex;
    background: rgba(255,255,255,0.1);
    border-radius: 50px;
    overflow: hidden;
}
.search-bar input {
    padding: 8px 12px;
    border: none;
    outline: none;
    background: transparent;
    color: white;
}
.search-bar button {
    background: var(--brand2);
    border: none;
    color: white;
    padding: 8px 14px;
    cursor: pointer;
}
.header-buttons a {
    text-decoration: none;
    color: white;
    padding: 6px 14px;
    background: rgba(255,255,255,0.1);
    border-radius: 50px;
    margin-left: 6px;
}
.header-buttons .go-premium {
    background: gold;
    color: black;
    font-weight: bold;
}
h2.section-title {
    margin: 25px 0 10px;
    border-left: 5px solid var(--brand1);
    padding-left: 10px;
}

/* New clean genre styles */
.genre-list {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    padding: 10px;
    background: var(--card);
    border-radius: 8px;
    max-height: 250px;
    overflow-y: auto;
    scrollbar-width: thin;
    scrollbar-color: var(--brand1) transparent;
}
.genre-list::-webkit-scrollbar {
    width: 6px;
}
.genre-list::-webkit-scrollbar-thumb {
    background: var(--brand1);
    border-radius: 4px;
}
label {
    cursor: pointer;
}
.genre-pill {
    display: inline-block;
    padding: 8px 14px;
    border-radius: 50px;
    background: rgba(255,255,255,0.05);
    color: var(--text);
    font-size: 0.85rem;
    transition: all 0.2s ease;
}
.genre-pill:hover {
    background: rgba(255,255,255,0.15);
}
input[type="checkbox"] {
    display: none;
}
input[type="checkbox"]:checked + .genre-pill {
    background: var(--brand1);
}
.find-btn {
    margin-top: 15px;
    display: block;
    padding: 10px 20px;
    background: var(--brand1);
    color: white;
    border: none;
    border-radius: 50px;
    font-size: 0.9rem;
    cursor: pointer;
    transition: background 0.2s;
}
.find-btn:hover {
    background: var(--brand2);
}

.book-result {
    margin-top: 30px;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    gap: 15px;
}
.book-result img {
    width: 100%;
    height: 250px;
    object-fit: cover;
    border-radius: 6px;
}
.back-btn {
    display: inline-block;
    margin-bottom: 15px;
    padding: 6px 14px;
    background: rgba(255,255,255,0.1);
    border-radius: 50px;
    text-decoration: none;
    color: white;
}
.back-btn:hover {
    background: rgba(255,255,255,0.3);
}
</style>
</head>
<body>
<div class="sidebar">
    <h1>Book-Tune</h1>
    <a href="index.php">Home</a>
    <a href="genres.php">Genres</a>
    <a href="#">Popular</a>
    <a href="#">New Releases</a>
    <a href="premium.php">Go Premium</a>
    <a href="upload.php">Upload Book</a>
</div>
<div class="main-content">
    <header>
        <form class="search-bar" method="GET" action="search.php">
            <input type="text" name="q" placeholder="Search books..." required>
            <button type="submit">Search</button>
        </form>
        <div class="header-buttons">
            <a href="login.php">Login</a>
            <a href="signup.php">Sign Up</a>
            <a href="premium.php" class="go-premium">Go Premium</a>
        </div>
    </header>

    <a href="index.php" class="back-btn">← Back</a>

    <h2 class="section-title">Find Books by Genre</h2>
    <form method="POST">
        <div class="genre-list">
            <?php foreach ($genres as $g): ?>
                <label>
                    <input type="checkbox" name="genres[]" value="<?= htmlspecialchars($g) ?>">
                    <span class="genre-pill"><?= htmlspecialchars($g) ?></span>
                </label>
            <?php endforeach; ?>
        </div>
        <button type="submit" class="find-btn">Find Books</button>
    </form>

    <?php if (!empty($books)): ?>
        <div class="book-result">
            <?php foreach ($books as $book): ?>
                <a href="book.php?id=<?= $book['id'] ?>">
                    <img src="covers/<?= htmlspecialchars($book['cover']) ?>">
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
