<?php
session_start();
require_once "db.php";

$newBooks = $pdo->query("SELECT * FROM books ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>New Releases - Book-Tune</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
/* Same CSS as in popular.php */
</style>
</head>
<body>
<div class="sidebar">
    <h1>Book-Tune</h1>
    <a href="index.php">Home</a>
    <a href="genres.php">Genres</a>
    <a href="popular.php">Popular</a>
    <a href="new_releases.php">New Releases</a>
    <a href="premium.php">Go Premium</a>
    <a href="upload.php">Upload Book</a>
</div>
<div class="main-content">
    <header>
        <form class="search-bar" method="GET" action="search.php">
            <input type="text" name="q" placeholder="Search books..." required>
            <button type="submit">Search</button>
        </form>
        <div class="header-buttons">
            <a href="login.php">Login</a>
            <a href="signup.php">Sign Up</a>
            <a href="premium.php" class="go-premium">Go Premium</a>
        </div>
    </header>

    <h2 class="section-title">New Releases</h2>
    <div class="book-grid">
        <?php foreach ($newBooks as $book): ?>
        <div class="book-card">
            <a href="book.php?id=<?= $book['id'] ?>">
                <img src="covers/<?= htmlspecialchars($book['cover']) ?>">
            </a>
            <h3><?= htmlspecialchars($book['title']) ?></h3>
            <p class="author"><?= htmlspecialchars($book['author']) ?></p>
            <div class="book-meta">
                <span>⭐ <?= $book['rating'] ?></span>
                <span>👁 <?= $book['views'] ?></span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
</body>
</html>
