<?php
require_once "session.php"; // New line, place this first
require_once "db.php";

function bt_cover_src($val) {
    if (empty($val)) return "assets/placeholder.png"; // fallback image
    if (preg_match('/^https?:\\/\\//', $val)) return htmlspecialchars($val); // remote URL
    if (strpos($val, 'covers/') === 0) return htmlspecialchars($val); // already has "covers/"
    return 'covers/' . htmlspecialchars($val); // missing "covers/", add it
    // Fallback to books folder (in case of older uploads)
    $bookPath = 'books/' . htmlspecialchars($val);
    if (file_exists($bookPath)) {
        return $bookPath;
    }

    // Final fallback image
    return 'assets/placeholder.png';
}

// ---- Random text generator (server-side) ----
// Returns X paragraphs of randomly composed text (for initial reader content fallback)
function generate_random_paragraphs($count = 3)
{
    $words = [
        "rgwdjwda", "awdadjnt", "jniuhbawd", "aikjhnihjn", "ihawdjbkb", "shadow", "wanderer", "moment",
        "beyond", "silent", "horizon", "echo", "pulse", "fragment", "story", "dust",
        "river", "crystal", "storm", "path", "embers", "light", "lost", "dawn", "solitude",
        "depth", "feather", "timeless", "woven", "breeze", "realm", "spark", "nightfall",
        "gaze", "murmur", "stone", "candle", "archive", "atlas", "voyage", "atlas"
    ];

    $paragraphs = "";

    for ($i = 0; $i < $count; $i++) {
        $sentenceCount = rand(4, 7);
        $paragraph = "";

        for ($s = 0; $s < $sentenceCount; $s++) {
            $sentenceLength = rand(8, 16);
            $sentenceWords = [];

            for ($w = 0; $w < $sentenceLength; $w++) {
                $sentenceWords[] = $words[array_rand($words)];
            }

            // Capitalize first letter + add period
            $sentence = ucfirst(implode(" ", $sentenceWords)) . ". ";
            $paragraph .= $sentence;
        }

        $paragraphs .= "<p>$paragraph</p>";
    }

    return $paragraphs;
}

// **Corrected Profile Image Logic**
$defaultAvatar = "assets/default-profile.png";
$profileImage = $defaultAvatar;
if (isset($_SESSION['user_id'])) {
    // We already fetch the user's profile_pic in session.php
    // So we just need to access the session variable.
    if (!empty($_SESSION['profile_pic'])) {
        $profileImage = htmlspecialchars($_SESSION['profile_pic']);
    }
}

$isPremiumUser = isset($_SESSION['is_premium']) && $_SESSION['is_premium'];

if (!isset($_GET['id'])) die("Book not found.");
$bookId = (int)$_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM books WHERE id = ?");
$stmt->execute([$bookId]);
$book = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$book) die("Book not found.");

// --- NEW CODE: ADDED TO LOG READING HISTORY ---
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    $lastReadAt = date('Y-m-d H:i:s'); // Current timestamp

    $stmt = $pdo->prepare("INSERT INTO read_history (user_id, book_id, last_read_at)
                           VALUES (?, ?, ?)
                           ON DUPLICATE KEY UPDATE last_read_at = VALUES(last_read_at)");
    $stmt->execute([$userId, $bookId, $lastReadAt]);
}
// --- END NEW CODE ---

// NOTES: Chapters were intentionally removed per request - no fetch, no display.

$ratingStmt = $pdo->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as total FROM ratings WHERE book_id = ?");
$ratingStmt->execute([$bookId]);
$ratingData = $ratingStmt->fetch(PDO::FETCH_ASSOC);
$avgRating = $ratingData['avg_rating'] ? number_format($ratingData['avg_rating'], 1) : "0.0";
$totalRatings = $ratingData['total'];

$commentsStmt = $pdo->prepare("
    SELECT c.*, COALESCE(u.username, 'Guest') as username,
             COALESCE(u.profile_pic, 'assets/default-profile.png') AS avatar
    FROM comments c
    LEFT JOIN users u ON c.user_id = u.id
    WHERE c.book_id = ?
    ORDER BY c.created_at DESC
");
$commentsStmt->execute([$bookId]);
$comments = $commentsStmt->fetchAll(PDO::FETCH_ASSOC);

// Prepare initial reader content server-side (if needed)
$initialReaderHtml = "";
$fileExists = false;
if (!empty($book['file_path']) && file_exists($book['file_path'])) {
    // Embed the PDF in the reader
    $fileExists = true;
    $fileUrl = htmlspecialchars($book['file_path']);
    $initialReaderHtml = '<div class="reader-embed-wrap" style="height:75vh;"><iframe src="'.$fileUrl.'" style="width:100%;height:100%;border:none;border-radius:8px;"></iframe></div>';
} else if (!empty($book['description'])) {
    $initialReaderHtml = '<div class="reader-desc">'.nl2br(htmlspecialchars($book['description'])).'</div>';
} else {
    // Generate server-side random paragraphs as fallback initial view
    $initialReaderHtml = generate_random_paragraphs(4);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($book['title']) ?> - Book-Tune</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
    /* -------------------------
       Theme tokens (dark-only)
       ------------------------- */
    :root{
        --bg-primary: #0a0e14;
        --bg-secondary: #121820;
        --card-bg: #1d2532;
        --text-primary: #e8eef8;
        --text-secondary: #a0a8b4;
        --brand-color: #5d83ff;
        --brand-light: #7a9aff;
        --border-color: #2e3b50;
        --brand-premium: #f3c74c;
        --shadow: 0 10px 30px rgba(0,0,0,0.35);
    }

    /* Base */
    html,body{height:100%}
    body {
        font-family: 'Inter', sans-serif;
        background-color: var(--bg-primary);
        color: var(--text-primary);
        margin: 0;
        -webkit-font-smoothing:antialiased;
        -moz-osx-font-smoothing:grayscale;
        line-height:1.6;
    }
    a { color: inherit; text-decoration: none; }

    /* Layout container */
    .bt-main {
        max-width: 1100px;
        margin: 40px auto;
        padding: 20px;
    }

    /* Sidebar (kept from your original layout) */
    .bt-sidebar {
        position: fixed;
        top: 0;
        left: 0;
        bottom: 0;
        width: 250px;
        background-color: var(--bg-secondary);
        border-right: 1px solid var(--border-color);
        padding: 25px 20px;
        display: flex;
        flex-direction: column;
        transform: translateX(-100%);
        transition: transform 0.28s cubic-bezier(.2,.9,.2,1);
        z-index: 120;
    }
    .bt-sidebar.is-expanded { transform: translateX(0); }
    .bt-sidebar__brand { font-weight:800; font-size:1.5rem; color:var(--brand-color); margin-bottom:28px; }
    .bt-sidebar__toggle { background:none; border:none; color:var(--text-secondary); font-size:1.25rem; cursor:pointer; }

    .bt-nav { display:flex; flex-direction:column; gap:10px; margin-top:14px; }
    .bt-nav__item { display:flex; align-items:center; gap:12px; padding:12px; border-radius:10px; color:var(--text-secondary); transition:all .14s; }
    .bt-nav__item:hover { background: rgba(93,131,255,0.12); color:#fff; }

    /* -------------------------
       Modern glass top bar (replaces old topbar)
       ------------------------- */
    .bt-header-modern {
        position: sticky;
        top: 0;
        left: 0;
        right: 0;
        z-index: 110;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 14px 20px;
        backdrop-filter: blur(10px);
        background: linear-gradient(180deg, rgba(15,18,24,0.88), rgba(10,12,18,0.86));
        border-bottom: 1px solid rgba(255,255,255,0.03);
        box-shadow: 0 6px 18px rgba(0,0,0,0.45);
    }
    .bt-header-modern .left {
        display:flex;
        align-items:center;
        gap:14px;
    }
    .bt-logo-modern { font-weight:800; color:var(--brand-color); font-size:1.2rem; letter-spacing:0.6px; }
    .header-icon-btn { background:none; border:none; color:var(--text-primary); font-size:1.2rem; cursor:pointer; padding:8px; border-radius:8px; }
    .header-icon-btn:focus { outline:2px solid rgba(93,131,255,0.16); }

    .bt-header-modern .right { display:flex; align-items:center; gap:12px; }
    .header-profile { display:flex; align-items:center; gap:10px; color:var(--text-primary); text-decoration:none; }
    .header-avatar { width:36px; height:36px; border-radius:50%; object-fit:cover; border:2px solid rgba(255,255,255,0.04); }
    .header-username { font-weight:600; font-size:0.95rem; color:var(--text-primary); }

    .header-btn {
        padding:8px 16px;
        border-radius:20px;
        border:1px solid var(--border-color);
        background: var(--card-bg);
        color:var(--text-primary);
        font-weight:600;
        font-size:0.95rem;
        transition:transform .14s ease, background .14s ease;
    }
    .header-btn.primary { background:var(--brand-color); border:none; color:#fff; }
    .header-btn:hover { transform:translateY(-2px); background:var(--brand-color); color:#fff; }

    /* Main book container */
    .bt-container {
        display: flex;
        flex-direction: column;
        gap: 28px;
        background-color: var(--bg-secondary);
        padding: 32px;
        border-radius: 14px;
        border: 1px solid var(--border-color);
        box-shadow: var(--shadow);
    }
    @media(min-width:768px){
        .bt-container { flex-direction:row; padding:36px; }
    }

    .bt-cover-container { width:100%; max-width:300px; flex-shrink:0; }
    .bt-cover-container img { width:100%; height:auto; border-radius:12px; object-fit:cover; border:1px solid rgba(255,255,255,0.04); box-shadow:0 10px 30px rgba(0,0,0,0.45); }

    .bt-book-details { flex:1; padding-left:0; }
    @media(min-width:768px){ .bt-book-details { padding-left:20px; } }

    .bt-book-details h1 { font-size:2.4rem; margin:0 0 6px 0; font-weight:800; line-height:1.12; }
    .bt-book-meta { color:var(--text-secondary); font-size:0.98rem; margin-bottom:14px; }
    .bt-book-details p { color:var(--text-secondary); margin:0 0 12px 0; max-width:70ch; }

    .bt-actions { display:flex; flex-wrap:wrap; gap:12px; margin-top:18px; align-items:center; }

    .bt-btn { padding:10px 20px; border-radius:999px; border:1px solid var(--border-color); background:var(--card-bg); color:var(--text-primary); font-weight:700; cursor:pointer; transition:all .16s ease; display:inline-flex; gap:8px; align-items:center; }
    .bt-btn:hover { transform:translateY(-3px); background:var(--brand-color); color:#fff; border-color:var(--brand-color); }
    .bt-btn--primary { background:var(--brand-color); color:#fff; border:none; }

    /* Dropdown */
    .bt-dropdown { position: relative; }
    .bt-dropdown-menu { position:absolute; left:0; top:110%; background:var(--bg-secondary); border:1px solid var(--border-color); border-radius:10px; min-width:200px; overflow:hidden; box-shadow:0 8px 32px rgba(0,0,0,0.6); opacity:0; transform:translateY(8px); transition:opacity .18s, transform .18s; pointer-events:none; }
    .bt-dropdown.open .bt-dropdown-menu { opacity:1; transform:translateY(0); pointer-events:auto; }
    .bt-dropdown-menu a { display:block; padding:10px 14px; color:var(--text-primary); font-size:0.95rem; }
    .bt-dropdown-menu a:hover { background:var(--card-bg); color:var(--brand-light); }

    /* Sections grid */
    .bt-sections-container { display:grid; gap:28px; margin-top:28px; }
    @media(min-width:768px){ .bt-sections-container { grid-template-columns:1fr 1fr; } }

    .bt-section { background:transparent; padding:20px; border-radius:12px; border:1px solid var(--border-color); }

    .bt-section h2 { font-size:1.4rem; margin:0 0 16px 0; color:var(--text-primary); font-weight:700; border-bottom:1px solid rgba(255,255,255,0.03); padding-bottom:12px; }

    /* ============================
       COMMENTS — CENTERED (NEW)
       ============================ */
    .comments-wrapper {
        max-width: 850px;
        margin: 28px auto 12px;
        padding: 28px;
        background: linear-gradient(180deg, rgba(255,255,255,0.01), transparent);
        border-radius: 14px;
        border: 1px solid var(--border-color);
        box-shadow: 0 8px 26px rgba(0,0,0,0.45);
    }

    .comments-title { font-size:1.6rem; margin:0 0 18px; font-weight:800; color:var(--text-primary); }

    .comments-list { display:flex; flex-direction:column; gap:16px; }

    .comment-item {
        display:flex;
        gap:14px;
        align-items:flex-start;
        padding:14px;
        background:var(--card-bg);
        border-radius:12px;
        border:1px solid rgba(255,255,255,0.03);
    }
    .comment-avatar { width:52px; height:52px; border-radius:50%; object-fit:cover; border:2px solid rgba(93,131,255,0.12); flex-shrink:0; }
    .comment-body { flex:1; }
    .comment-meta { font-size:0.92rem; color:var(--text-secondary); margin-bottom:6px; }
    .comment-meta strong { color:var(--text-primary); font-weight:700; }
    .comment-text { color:var(--text-primary); line-height:1.65; margin:0; font-size:0.98rem; }

    .comment-empty { text-align:center; padding:28px; border:2px dashed rgba(255,255,255,0.03); border-radius:12px; color:var(--text-secondary); }

    .comments-subtitle { font-size:1.1rem; margin-top:18px; margin-bottom:10px; color:var(--text-primary); }

    .comment-form textarea {
        width:100%;
        min-height:96px;
        padding:12px 14px;
        border-radius:12px;
        border:1px solid var(--border-color);
        background:var(--bg-primary);
        color:var(--text-primary);
        font-size:1rem;
        resize:vertical;
        box-shadow:inset 0 2px 6px rgba(0,0,0,0.25);
    }

    .comment-submit { margin-top:10px; padding:10px 20px; border-radius:999px; border:none; background:var(--brand-color); color:#fff; font-weight:700; cursor:pointer; }
    .comment-submit:hover { background:var(--brand-light); transform:translateY(-2px); }

    .comment-login-msg { color:var(--text-secondary); font-style:italic; }

    /* Reader Section */
    #readerSection {
        background: linear-gradient(180deg, rgba(255,255,255,0.02), transparent);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        padding: 20px;
        margin-top: 20px;
        display: none;
    }
    #readerHeader { display:flex; justify-content:space-between; align-items:center; gap:12px; margin-bottom:14px; }
    .reader-close-btn { background:transparent; border:1px solid var(--border-color); color:var(--text-primary); padding:8px 12px; border-radius:8px; cursor:pointer; }
    .reader-embed-wrap { background:#fff; border-radius:8px; overflow:hidden; }

    /* Small screens adjustments */
    @media(max-width:767px){
        .bt-container { padding:18px; }
        .comments-wrapper { margin: 20px 16px; padding:18px; }
        .bt-header-modern { padding:10px 12px; }
    }
</style>
</head>
<body>

<!-- SIDEBAR (unchanged, but kept for layout integrity) -->
<aside class="bt-sidebar" id="sidebar" aria-hidden="true">
    <div class="bt-sidebar__brand">BOOK-TUNE</div>
    <button id="closeSidebar" class="bt-sidebar__toggle" aria-label="Close sidebar"><i class="fas fa-arrow-left"></i></button>

    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="profile.php" class="sidebar-profile" style="display:flex;align-items:center;gap:12px;padding:10px 12px;background:var(--card-bg);border-radius:10px;">
            <img src="<?= $profileImage ?>" alt="Profile" class="avatar-img" style="width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid var(--brand-color);">
            <span class="sidebar-username" style="font-weight:700;color:var(--text-primary);"><?= htmlspecialchars($_SESSION['username']) ?></span>
        </a>
    <?php endif; ?>

    <nav class="bt-nav" aria-label="Primary">
        <a href="index.php" class="bt-nav__item"><i class="fas fa-home"></i><span class="bt-nav__text">Home</span></a>
        <a href="genres.php" class="bt-nav__item"><i class="fas fa-th-large"></i><span class="bt-nav__text">Genres</span></a>
        <a href="index.php#popular" class="bt-nav__item scroll-link"><i class="fas fa-fire"></i><span class="bt-nav__text">Popular</span></a>
        <a href="index.php#new-releases" class="bt-nav__item scroll-link"><i class="fas fa-star"></i><span class="bt-nav__text">New Releases</span></a>
        <a href="premium.php" class="bt-nav__item"><i class="fas fa-crown"></i><span class="bt-nav__text">Premium</span></a>
        <a href="upload.php" class="bt-nav__item"><i class="fas fa-upload"></i><span class="bt-nav__text">Upload</span></a>
    </nav>
</aside>

<!-- MODERN TOP BAR (replaces older header) -->
<header class="bt-header-modern" role="banner" aria-label="Topbar">
    <div class="left">
        <button id="toggleSidebar" class="header-icon-btn" aria-label="Open sidebar"><i class="fas fa-bars"></i></button>
        <div class="bt-logo-modern">BOOK-TUNE</div>
    </div>

    <div class="right">
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="profile.php" class="header-profile" title="View profile">
                <img src="<?= $profileImage ?>" alt="avatar" class="header-avatar">
                <span class="header-username"><?= htmlspecialchars($_SESSION['username']) ?></span>
            </a>
            <a href="logout.php" class="header-btn">Logout</a>
        <?php else: ?>
            <a href="login.php" class="header-btn">Log In</a>
            <a href="register.php" class="header-btn primary">Sign Up</a>
        <?php endif; ?>
    </div>
</header>

<main class="bt-main" id="main">
    <div class="bt-container" role="region" aria-label="Book details">
        <div class="bt-cover-container" aria-hidden="false">
            <img id="bookCover" src="<?= bt_cover_src($book['cover']) ?>" data-title="<?= htmlspecialchars($book['title']) ?>" data-author="<?= htmlspecialchars($book['author']) ?>" alt="<?= htmlspecialchars($book['title']) ?>">
        </div>

        <div class="bt-book-details">
            <h1><?= htmlspecialchars($book['title']) ?></h1>
            <div class="bt-book-meta">
                By <?= htmlspecialchars($book['author']) ?> • ⭐ <?= $avgRating ?> (<?= $totalRatings ?> ratings) • <?= htmlspecialchars($book['category']) ?>
            </div>

            <p><?= nl2br(htmlspecialchars($book['description'])) ?></p>

            <?php if ($book['is_premium'] && !$isPremiumUser) { ?>
                <div class="bt-actions">
                    <a href="premium.php" class="bt-btn bt-btn--primary" aria-hidden="false"><i class="fas fa-lock"></i> Go Premium to Read</a>
                </div>
            <?php } else { ?>
                <div class="bt-actions" role="group" aria-label="Actions">
                    <button class="bt-btn bt-btn--primary" id="readNowBtn"><i class="fas fa-book-open" aria-hidden="true"></i> Start Reading</button>

                    <?php if (isset($_SESSION['user_id'])): ?>
                        <form method="POST" action="add_to_library.php" style="display:inline" aria-hidden="false">
                            <input type="hidden" name="book_id" value="<?= $book['id'] ?>">
                            <button type="submit" class="bt-btn" title="Add to library"><i class="fas fa-bookmark" aria-hidden="true"></i> Add to Library</button>
                        </form>

                        <div class="bt-dropdown" aria-haspopup="true">
                            <button class="bt-btn" id="statusDropdownBtn" aria-expanded="false">Update Status ⌄</button>
                            <div class="bt-dropdown-menu" role="menu" aria-labelledby="statusDropdownBtn">
                                <a role="menuitem" href="update_status.php?book_id=<?= $book['id'] ?>&status=plan">Plan to Read</a>
                                <a role="menuitem" href="update_status.php?book_id=<?= $book['id'] ?>&status=reading">Reading</a>
                                <a role="menuitem" href="update_status.php?book_id=<?= $book['id'] ?>&status=completed">Completed</a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if (isset($_SESSION['user_id'])): ?>
                <form method="POST" action="rate.php" style="margin-top:12px;">
                    <input type="hidden" name="book_id" value="<?= $book['id'] ?>">
                    <div class="star-rating" aria-label="Rating">
                        <?php for ($i=5;$i>=1;$i--): ?>
                            <input type="radio" id="star<?= $i ?>" name="rating" value="<?= $i ?>">
                            <label for="star<?= $i ?>">★</label>
                        <?php endfor; ?>
                    </div>
                    <button type="submit" class="bt-rating-submit">Submit Rating</button>
                </form>
                <?php endif; ?>
            <?php } ?>
        </div>
    </div>

    <!-- Comments: replaced with centered professional section -->
    <div class="comments-wrapper" role="region" aria-label="Comments">
        <h2 class="comments-title">Comments</h2>

        <div class="comments-list">
            <?php if (count($comments) > 0): ?>
                <?php foreach ($comments as $c): ?>
                <div class="comment-item" id="comment-<?= (int)$c['id'] ?>">
                    <img src="<?= htmlspecialchars($c['avatar']) ?>" alt="avatar" class="comment-avatar">
                    <div class="comment-body">
                        <div class="comment-meta"><strong><?= htmlspecialchars($c['username']) ?></strong> <span> • <?= htmlspecialchars($c['created_at']) ?></span></div>
                        <p class="comment-text"><?= nl2br(htmlspecialchars($c['comment'])) ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="comment-empty">
                    <i class="fas fa-comment-dots" aria-hidden="true"></i>
                    <div style="margin-top:8px;">No comments yet.</div>
                </div>
            <?php endif; ?>
        </div>

        <h3 class="comments-subtitle">Leave a Comment</h3>

        <?php if (isset($_SESSION['user_id'])): ?>
            <form class="comment-form" method="POST" action="add_comment.php" aria-label="Leave a comment">
                <input type="hidden" name="book_id" value="<?= $bookId ?>">
                <textarea name="comment" rows="4" placeholder="Write a comment..." required aria-required="true"></textarea>
                <button type="submit" class="comment-submit">Submit</button>
            </form>
        <?php else: ?>
            <p class="comment-login-msg">You must be logged in to comment. <a href="login.php">Log in</a></p>
        <?php endif; ?>
    </div>

    <!-- Inline reader -->
    <div id="readerSection" aria-hidden="true">
        <div id="readerHeader">
            <h3 id="readerTitle">Reading: <?= htmlspecialchars($book['title']) ?></h3>
            <div>
                <button class="reader-close-btn" id="closeReaderBtn" aria-controls="readerSection"><i class="fas fa-times" aria-hidden="true"></i> Close</button>
            </div>
        </div>

        <div class="reader-content" id="readerContent" tabindex="0">
            <?= $initialReaderHtml ?>
        </div>
    </div>

</main>

<script>
/* -------------------------
   Sidebar toggle
   ------------------------- */
const sidebar = document.getElementById("sidebar");
const toggleBtn = document.getElementById("toggleSidebar");
const closeBtn = document.getElementById("closeSidebar");

if (toggleBtn && sidebar) {
    toggleBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        sidebar.classList.add("is-expanded");
        sidebar.setAttribute("aria-hidden", "false");
    });
}
if (closeBtn && sidebar) {
    closeBtn.addEventListener("click", () => {
        sidebar.classList.remove("is-expanded");
        sidebar.setAttribute("aria-hidden", "true");
    });
}
document.addEventListener("click", function(e) {
    if (sidebar && sidebar.classList.contains("is-expanded") && !sidebar.contains(e.target) && e.target !== toggleBtn) {
        sidebar.classList.remove("is-expanded");
        sidebar.setAttribute("aria-hidden", "true");
    }
});

/* -------------------------
   Dropdown toggle
   ------------------------- */
const statusBtn = document.getElementById("statusDropdownBtn");
if (statusBtn) {
    statusBtn.addEventListener("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        const dropdown = this.parentElement;
        dropdown.classList.toggle("open");
        const expanded = dropdown.classList.contains("open");
        this.setAttribute("aria-expanded", expanded ? "true" : "false");
    });
}
document.addEventListener("click", function() {
    document.querySelectorAll('.bt-dropdown').forEach(d => d.classList.remove('open'));
});

/* -------------------------
   Fetch Open Library Cover if local one doesn't exist
   ------------------------- */
async function fetchOpenLibraryCover() {
    const img = document.getElementById("bookCover");
    if (!img) return;
    // if the current cover is placeholder or local missing, try fetch
    if (img.src.includes('assets/placeholder.png') || img.src.includes('assets/placeholder-cover.jpg') ) {
        try {
            const title = img.dataset.title;
            const author = img.dataset.author;
            const res = await fetch(`https://openlibrary.org/search.json?title=${encodeURIComponent(title)}&author=${encodeURIComponent(author)}&limit=1`);
            const data = await res.json();
            if (data.docs && data.docs.length > 0) {
                const doc = data.docs[0];
                if (doc.cover_i) {
                    const url = `https://covers.openlibrary.org/b/id/${doc.cover_i}-L.jpg`;
                    img.src = url;
                }
            }
        } catch(e) {
            console.warn("Open Library cover fetch failed", e);
        }
    }
}
window.addEventListener('load', fetchOpenLibraryCover);

/* -------------------------
   Inline Reader Logic
   ------------------------- */
const readerSection = document.getElementById('readerSection');
const readNowBtn = document.getElementById('readNowBtn');
const closeReaderBtn = document.getElementById('closeReaderBtn');
const readerTitle = document.getElementById('readerTitle');

function openReader() {
    if (!readerSection) return;
    readerSection.style.display = 'block';
    readerSection.setAttribute('aria-hidden', 'false');
    readerSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function closeReader() {
    if (!readerSection) return;
    readerSection.style.display = 'none';
    readerSection.setAttribute('aria-hidden', 'true');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

if (readNowBtn) {
    readNowBtn.addEventListener('click', function(e){
        e.preventDefault();
        readerTitle.textContent = "Reading: <?= htmlspecialchars(addslashes($book['title'])) ?>";
        openReader();
    });
}

if (closeReaderBtn) {
    closeReaderBtn.addEventListener('click', function(){
        closeReader();
    });
}

/* -------------------------
   Small helpers
   ------------------------- */
// Close reader on history navigation
window.addEventListener('popstate', function(){
    closeReader();
});
</script>
</body>
</html>
