<?php
session_start();
require_once "db.php";

// Check if user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION["user_id"];
$isPremiumUser = isset($_SESSION["is_premium"]) && $_SESSION["is_premium"] == 1;

// Check if book ID is provided
if (!isset($_GET["id"]) || !is_numeric($_GET["id"])) {
    header("Location: index.php");
    exit();
}

$bookId = (int)$_GET["id"];

// Fetch book data
$stmt = $pdo->prepare("SELECT * FROM books WHERE id = ?");
$stmt->execute([$bookId]);
$book = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$book) {
    echo "<p>Book not found.</p>";
    exit();
}

// If book is premium and user is not premium
if ($book["is_premium"] == 1 && !$isPremiumUser) {
    echo "<h2>🔒 Premium Content</h2>";
    echo "<p>This book is available to premium members only.</p>";
    echo '<a href="premium.php">Go Premium</a>';
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($book["title"]); ?></title>
    <link rel="stylesheet" href="style.css">
    <style>
        .book-details {
            max-width: 800px;
            margin: 30px auto;
            padding: 20px;
            background: var(--card);
            border-radius: 10px;
        }
        .book-details img {
            max-width: 200px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <header class="site-header">
        <h1><?php echo htmlspecialchars($book["title"]); ?></h1>
    </header>

    <main class="book-details">
        <img src="covers/<?php echo htmlspecialchars($book["cover"]); ?>" alt="Book cover">
        <h2><?php echo htmlspecialchars($book["title"]); ?></h2>
        <p><strong>Author:</strong> <?php echo htmlspecialchars($book["author"]); ?></p>
        <p><strong>Category:</strong> <?php echo htmlspecialchars($book["category"]); ?></p>
        <p><?php echo nl2br(htmlspecialchars($book["description"])); ?></p>
    </main>
</body>
</html>
