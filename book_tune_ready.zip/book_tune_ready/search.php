<?php
session_start();
require_once "db.php";

// Get logged-in user data
$user = null;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT username, profile_pic FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        $_SESSION['username'] = $user['username'];
    }
}

$defaultAvatar = "assets/default-profile.png";
$profileImage = ($user && !empty($user['profile_pic'])) ? $user['profile_pic'] : $defaultAvatar;

// Book cover helper
function bt_cover_src($cover_value) {
    if (empty($cover_value)) {
        return "assets/placeholder.png";
    }
    if (filter_var($cover_value, FILTER_VALIDATE_URL)) {
        return htmlspecialchars($cover_value);
    }
    if (is_numeric($cover_value)) {
        return "https://covers.openlibrary.org/b/id/{$cover_value}-L.jpg";
    } elseif (preg_match('/^(OL|M|S)\w+$/', $cover_value)) {
        return "https://covers.openlibrary.org/b/olid/" . htmlspecialchars($cover_value) . "-L.jpg";
    }
    return "covers/" . htmlspecialchars($cover_value);
}

// Search logic
$query = isset($_GET['q']) ? trim($_GET['q']) : '';
$books = [];
$users_found = [];

if ($query) {
    // Search Books
    $stmt = $pdo->prepare("
        SELECT b.id, b.title, b.author, b.cover, b.is_premium, b.views
        FROM books b
        LEFT JOIN book_genres bg ON b.id = bg.book_id
        LEFT JOIN genres g ON bg.genre_id = g.id
        WHERE b.title LIKE ? OR b.author LIKE ? OR g.name LIKE ?
        GROUP BY b.id
        ORDER BY b.views DESC
    ");
    $stmt->execute(["%$query%", "%$query%", "%$query%"]);
    $books = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Search Users
    $stmt = $pdo->prepare("SELECT id, username, profile_pic FROM users WHERE username LIKE ?");
    $stmt->execute(["%$query%"]);
    $users_found = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search - Book-Tune</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .user-result {
            display: flex;
            align-items: center;
            background: var(--card-bg, #1e1e1e);
            padding: 12px;
            border-radius: 10px;
            margin-bottom: 10px;
            transition: background 0.2s;
        }
        .user-result:hover {
            background: var(--hover-bg, #292929);
        }
        .user-result img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 15px;
            object-fit: cover;
        }
        .user-result a {
            color: var(--text-primary, #fff);
            font-weight: 600;
            text-decoration: none;
        }
        .user-result a:hover {
            color: var(--brand-color, #ffcc00);
        }
    </style>
</head>
<body class="<?= isset($_SESSION['user_id']) ? 'logged-in' : '' ?>">

<aside class="bt-sidebar" id="sidebar">
    <div class="bt-sidebar__brand">
        Book-Tune
        <button id="closeSidebar" class="bt-sidebar__toggle">
            <i class="fas fa-arrow-left"></i>
        </button>
    </div>

    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="profile.php" class="sidebar-profile">
            <img src="<?= htmlspecialchars($profileImage) ?>" alt="Profile" class="sidebar-avatar">
            <span class="sidebar-username"><?= htmlspecialchars($user['username']) ?></span>
        </a>
    <?php endif; ?>

    <nav class="bt-nav">
        <a href="index.php" class="bt-nav__item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="genres.php" class="bt-nav__item"><i class="fas fa-th-large"></i><span>Genres</span></a>
        <a href="index.php#popular" class="bt-nav__item"><i class="fas fa-fire"></i><span>Popular</span></a>
        <a href="index.php#new-releases" class="bt-nav__item"><i class="fas fa-star"></i><span>New Releases</span></a>
        <a href="premium.php" class="bt-nav__item"><i class="fas fa-crown"></i><span>Premium</span></a>
        <a href="upload.php" class="bt-nav__item"><i class="fas fa-upload"></i><span>Upload</span></a>
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="logout.php" class="bt-nav__item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
        <?php endif; ?>
    </nav>
</aside>

<header class="bt-header" id="topbar">
    <div class="bt-header__left">
        <button id="toggleSidebar" class="bt-sidebar__toggle"><i class="fas fa-bars"></i></button>
        <div class="bt-logo">BOOK-TUNE</div>
        <form class="bt-search" method="GET" action="search.php">
            <input type="text" name="q" placeholder="Search books or users..." value="<?= htmlspecialchars($query) ?>" required>
            <button type="submit"><i class="fas fa-search"></i></button>
        </form>
    </div>

    <div class="bt-header__right">
        <?php if ($user): ?>
            <div class="user-menu">
                <a href="profile.php" class="user-profile-link">
                    <img src="<?= htmlspecialchars($profileImage) ?>" alt="Profile" class="user-avatar">
                    <span class="username"><?= htmlspecialchars($user['username']) ?></span>
                </a>
                <a href="logout.php" class="bt-btn bt-btn--ghost">Logout</a>
            </div>
        <?php else: ?>
            <a class="bt-btn bt-btn--ghost" href="login.php">Login</a>
            <a class="bt-btn bt-btn--ghost" href="signup.php">Sign Up</a>
            <a class="bt-btn bt-btn--gold" href="premium.php">Go Premium</a>
        <?php endif; ?>
    </div>
</header>

<main class="bt-main" id="mainContent">
    <div class="bt-container">
        <?php if ($query): ?>
            <section class="bt-section">
                <h2 class="bt-section__title">Users Matching "<?= htmlspecialchars($query) ?>"</h2>
                <?php if ($users_found): ?>
                    <?php foreach ($users_found as $u): ?>
                        <?php $userPic = !empty($u['profile_pic']) ? $u['profile_pic'] : 'assets/default-profile.png'; ?>
                        <div class="user-result">
                            <img src="<?= htmlspecialchars($userPic) ?>" alt="<?= htmlspecialchars($u['username']) ?>">
                            <a href="profile.php?id=<?= $u['id'] ?>"><?= htmlspecialchars($u['username']) ?></a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="no-results">No users found for "<?= htmlspecialchars($query) ?>"</div>
                <?php endif; ?>
            </section>

            <section class="bt-section">
                <h2 class="bt-section__title">Books Matching "<?= htmlspecialchars($query) ?>"</h2>
                <?php if ($books): ?>
                    <div class="bt-grid">
                        <?php foreach ($books as $book): ?>
                            <article class="bt-card">
                                <a class="bt-card__cover" href="book.php?id=<?= $book['id'] ?>">
                                    <img src="<?= bt_cover_src($book['cover']) ?>" alt="<?= htmlspecialchars($book['title']) ?>">
                                    <?php if (!empty($book['is_premium'])): ?>
                                        <span class="premium-tag">Premium</span>
                                    <?php endif; ?>
                                </a>
                                <h3 class="bt-card__title"><a href="book.php?id=<?= $book['id'] ?>"><?= htmlspecialchars($book['title']) ?></a></h3>
                                <p class="bt-card__author"><?= htmlspecialchars($book['author']) ?></p>
                            </article>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="no-results">No books found for "<?= htmlspecialchars($query) ?>"</div>
                <?php endif; ?>
            </section>
        <?php else: ?>
            <div class="bt-empty">Enter a keyword to search for books or users.</div>
        <?php endif; ?>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.getElementById('sidebar');
    const toggleButton = document.getElementById('toggleSidebar');
    const closeButton = document.getElementById('closeSidebar');
    const mainContent = document.getElementById('mainContent');
    const toggleSidebar = () => {
        const isExpanded = sidebar.classList.toggle('is-expanded');
        mainContent.classList.toggle('is-shifted', isExpanded);
    };
    toggleButton?.addEventListener('click', toggleSidebar);
    closeButton?.addEventListener('click', toggleSidebar);
});
</script>
</body>
</html>
