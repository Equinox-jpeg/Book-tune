<?php
session_start();
require_once "db.php";
$message = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST["username"]);
    $password = $_POST["password"];
    $stmt = $pdo->prepare("SELECT id, password, is_premium FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user["password"])) {
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["username"] = $username;
        $_SESSION["is_premium"] = $user["is_premium"];
        header("Location: index.php"); exit;
    } else { $message = "Invalid username or password."; }
}
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Log In - Book‑Tune</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css" /></head><body>
<header class="site-header"><h1 class="logo">📚 Book‑Tune</h1><nav class="auth">
<a class="btn ghost" href="index.php">Home</a><a class="btn" href="signup.php">Sign Up</a></nav></header>
<?php if($message): ?><div class="alert"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
<form method="POST" class="form"><h2>Log In</h2>
<div class="row"><label>Username</label><input type="text" name="username" required></div>
<div class="row"><label>Password</label><input type="password" name="password" required></div>
<button type="submit" class="submit">Log In</button>
<p class="hint">Don’t have an account? <a href="signup.php">Sign up here</a>.</p></form>
<footer class="site-footer"><p>© <?php echo date('Y'); ?> Book‑Tune</p></footer></body></html>
