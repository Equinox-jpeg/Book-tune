<?php
session_start();
require_once "db.php";

$defaultAvatar = "assets/default-profile.png";

// Determine which profile to show
$profileId = isset($_GET['id']) ? intval($_GET['id']) : (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0);

// Fetch the target user's data
$stmt = $pdo->prepare("SELECT id, username, bio, profile_pic FROM users WHERE id = ?");
$stmt->execute([$profileId]);
$profileUser = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$profileUser) {
    echo "<div style='text-align:center; padding:40px;'>User not found.</div>";
    exit;
}

// Determine if viewing own profile
$isOwnProfile = isset($_SESSION['user_id']) && $_SESSION['user_id'] === $profileUser['id'];

// Load logged-in user for sidebar/avatar (if any)
$loggedUser = null;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT id, username, profile_pic FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $loggedUser = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Check if current user already follows this profile (for initial button state)
$isFollowing = false;
if (isset($_SESSION['user_id']) && !$isOwnProfile) {
    $stmt = $pdo->prepare("SELECT 1 FROM followers WHERE follower_id = ? AND followed_id = ? LIMIT 1");
    $stmt->execute([$_SESSION['user_id'], $profileUser['id']]);
    $isFollowing = (bool) $stmt->fetchColumn();
}

// follower / following counts (for displayed profile user)
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM followers WHERE followed_id = ?");
    $stmt->execute([$profileUser['id']]);
    $followers = (int) $stmt->fetchColumn();
} catch (Exception $e) {
    $followers = 0;
}

try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM followers WHERE follower_id = ?");
    $stmt->execute([$profileUser['id']]);
    $following = (int) $stmt->fetchColumn();
} catch (Exception $e) {
    $following = 0;
}

// ✅ Safer version of bt_cover_src – handles local, OpenLibrary, ISBN, and empty values
function bt_cover_src($val) {
    if (empty($val)) return "assets/placeholder.png"; // fallback image
    if (preg_match('/^https?:\\/\\//', $val)) return htmlspecialchars($val); // remote URL
    if (strpos($val, 'covers/') === 0 || file_exists($val)) return htmlspecialchars($val); // local file path
    if (strpos($val, 'OL') === 0) {
        return "https://covers.openlibrary.org/b/olid/" . htmlspecialchars($val) . "-M.jpg";
    }
    if (is_numeric($val) && strlen($val) >= 10) {
        return "https://covers.openlibrary.org/b/isbn/" . htmlspecialchars($val) . "-M.jpg";
    }
    return 'covers/' . htmlspecialchars($val); // fallback for any other value
}

// Get user's library grouped by status (for viewed profile)
$statuses = ['reading', 'plan_to_read', 'completed'];
$library = [];
foreach ($statuses as $s) {
    $stmt = $pdo->prepare("SELECT b.* FROM library l
                             JOIN books b ON l.book_id = b.id
                             WHERE l.user_id = ? AND l.status = ?");
    $stmt->execute([$profileUser['id'], $s]);
    $library[$s] = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get user's reading history (for viewed profile)
$stmt = $pdo->prepare("SELECT b.*, rh.last_read_at FROM read_history rh
                         JOIN books b ON rh.book_id = b.id
                         WHERE rh.user_id = ?
                         ORDER BY rh.last_read_at DESC
                         LIMIT 10");
$stmt->execute([$profileUser['id']]);
$readingHistory = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($profileUser['username']) ?>'s Profile - Book-Tune</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg-primary: #080d15;
            --bg-secondary: #101620;
            --card-bg: #1c2433;
            --text-primary: #e8eef8;
            --text-secondary: #a0a8b4;
            --brand-color: #5d83ff;
            --brand-hover: #7a9aff;
            --border-color: #2e3b50;
            --brand-premium: #f3c74c;
            --shadow: 0 10px 40px rgba(0, 0, 0, 0.4);
        }
        body { font-family: 'Inter', sans-serif; background-color: var(--bg-primary); color: var(--text-primary); margin:0; padding:0; overflow-x:hidden; }
        a { text-decoration:none; color:inherit; }
        .bt-sidebar { position: fixed; top:0; left:0; bottom:0; width:250px; background-color: var(--bg-secondary); border-right:1px solid var(--border-color); padding:25px 20px; display:flex; flex-direction:column; transform:translateX(-100%); transition: transform 0.3s ease; z-index:100; }
        .bt-sidebar.is-expanded { transform:translateX(0); }
        .bt-sidebar__brand { font-weight:800; font-size:1.5rem; margin-bottom:30px; color:var(--brand-color); position:relative; }
        .bt-sidebar__toggle { background:none; border:none; color:var(--text-secondary); font-size:1.5rem; cursor:pointer; transition: color 0.2s; }
        .bt-sidebar #closeSidebar { position:absolute; top:0; right:0; }
        .bt-sidebar .sidebar-profile { display:flex; align-items:center; gap:15px; padding:10px 15px; margin-bottom:25px; background: var(--card-bg); border-radius:12px; }
        .bt-sidebar .sidebar-avatar { width:50px; height:50px; border-radius:50%; object-fit:cover; border:2px solid var(--brand-color); }
        .bt-sidebar .sidebar-username { font-weight:600; }
        .bt-nav { display:flex; flex-direction:column; gap:10px; }
        .bt-nav__item { display:flex; align-items:center; gap:15px; padding:15px; color:var(--text-secondary); font-weight:500; border-radius:12px; transition:all 0.2s; }
        .bt-nav__item:hover { background-color:var(--brand-color); color:#fff; }
        .bt-header { position:sticky; top:0; left:0; right:0; background-color:var(--bg-primary); border-bottom:1px solid var(--border-color); padding:15px 20px; display:flex; justify-content:space-between; align-items:center; z-index:50; box-shadow:0 4px 10px var(--shadow); }
        .bt-header__left { display:flex; align-items:center; gap:15px; }
        .bt-logo { color:var(--brand-color); font-size:1.2rem; font-weight:700; display:none; }
        .bt-search { position:relative; width:100%; max-width:350px; margin-left:20px; }
        .bt-search input { width:100%; padding:10px 45px 10px 20px; border-radius:50px; border:1px solid var(--border-color); background: var(--bg-secondary); color: var(--text-primary); font-size:1rem; transition:border-color 0.2s; }
        .bt-search input:focus { outline:none; border-color:var(--brand-color); }
        .bt-search button { position:absolute; right:10px; top:50%; transform:translateY(-50%); background:none; border:none; color:var(--text-secondary); font-size:1rem; cursor:pointer; }

        /* === Updated: move topbar right section fully right === */
        .bt-header__right { display:flex; align-items:center; gap:15px; margin-left:auto; }

        .user-menu { display:flex; align-items:center; gap:15px; }
        .user-avatar { width:35px; height:35px; border-radius:50%; object-fit:cover; }
        .username { font-weight:600; color:var(--text-primary); }
        .bt-btn { padding:12px 24px; border-radius:50px; border:1px solid var(--border-color); background: var(--card-bg); color:var(--text-primary); font-size:1rem; font-weight:600; cursor:pointer; transition:all .2s ease; }
        .bt-btn:hover { background:var(--brand-color); color:#fff; border-color:var(--brand-color); transform:translateY(-2px); }
        .bt-btn--primary { background: var(--brand-color); color:#fff; border:none; }
        .bt-btn--primary:hover { background:var(--brand-hover); }
        .bt-btn--gold { background: var(--brand-premium); color:var(--bg-primary); border:none; }
        .bt-btn--gold:hover { background:#ffd740; transform:translateY(-2px); }

        .bt-main { padding:40px 20px; max-width:1200px; margin:0 auto; transition:margin-left 0.3s ease; }
        .profile-header { display:flex; align-items:center; gap:30px; background:var(--card-bg); border-radius:16px; padding:40px; margin-bottom:30px; box-shadow:var(--shadow); border:1px solid var(--border-color); }
        .profile-header .avatar { width:120px; height:120px; border-radius:50%; object-fit:cover; border:4px solid var(--brand-color); box-shadow:0 5px 20px rgba(0,0,0,0.3); }
        .profile-details h1 { margin:0 0 5px; font-size:2.5rem; font-weight:800; color:var(--text-primary); }
        .profile-details p { margin:0 0 15px; font-size:1rem; color:var(--text-secondary); line-height:1.6; }
        .profile-details .btn-group { display:flex; gap:10px; flex-wrap:wrap; }
        .bt-btn--secondary { background:#666; color:#fff; border:none; }
        .library-section { margin-bottom:40px; }
        .library-section h2 { font-size:1.8rem; border-bottom:1px solid var(--border-color); padding-bottom:10px; margin-bottom:20px; font-weight:700; }
        .book-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(150px,1fr)); gap:20px; }
        .book-card { background:var(--card-bg); border-radius:12px; overflow:hidden; box-shadow:var(--shadow); transition:transform 0.2s ease,box-shadow 0.2s ease; border:1px solid var(--border-color); position:relative; }
        .book-card:hover { transform:translateY(-5px); box-shadow:0 15px 30px rgba(0,0,0,0.4); }
        .book-card a { display:block; }
        .book-card img { width:100%; height:200px; object-fit:cover; display:block; }
        .book-card .book-title { padding:15px; text-align:center; font-weight:600; font-size:1rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; color:var(--text-primary); }
        .no-books { color:var(--text-secondary); font-style:italic; text-align:center; padding:20px; }
        .read-date { font-size:0.8rem; color:var(--text-secondary); text-align:center; padding:0 15px 15px; }

        @media (min-width:768px) {
            .bt-main { margin:40px auto 40px 280px; padding:0 20px; }
            .bt-sidebar { transform:translateX(0); }
            .bt-sidebar__toggle { display:none; }
            .bt-header__left { display:none; }
            .bt-header { left:250px; width:calc(100% - 250px); }
            .bt-logo { display:block; }
        }
        @media (max-width:767px) {
            .profile-header { flex-direction:column; text-align:center; }
            .profile-details { text-align:center; }
            .bt-main { padding-top:80px; }
            .bt-header { justify-content:space-between; }
        }
    </style>
</head>
<body>

<aside class="bt-sidebar" id="sidebar">
    <div class="bt-sidebar__brand">Menu</div>
    <button id="closeSidebar" class="bt-sidebar__toggle"><i class="fas fa-arrow-left"></i></button>

    <?php if ($loggedUser): ?>
    <a href="profile.php" class="sidebar-profile">
        <img src="<?= bt_cover_src($loggedUser['profile_pic'] ?: $defaultAvatar) ?>" alt="Profile" class="sidebar-avatar">
        <span class="sidebar-username"><?= htmlspecialchars($loggedUser['username']) ?></span>
    </a>
    <?php endif; ?>

    <nav class="bt-nav">
        <a href="index.php" class="bt-nav__item"><i class="fas fa-home"></i><span class="bt-nav__text">Home</span></a>
        <a href="genres.php" class="bt-nav__item"><i class="fas fa-th-large"></i><span class="bt-nav__text">Genres</span></a>
        <a href="index.php#popular" class="bt-nav__item scroll-link"><i class="fas fa-fire"></i><span class="bt-nav__text">Popular</span></a>
        <a href="index.php#new-releases" class="bt-nav__item scroll-link"><i class="fas fa-star"></i><span class="bt-nav__text">New Releases</span></a>
        <a href="premium.php" class="bt-nav__item"><i class="fas fa-crown"></i><span class="bt-nav__text">Premium</span></a>
        <a href="upload.php" class="bt-nav__item"><i class="fas fa-upload"></i><span class="bt-nav__text">Upload</span></a>
    </nav>
</aside>

<header class="bt-header" id="topbar">
    <div class="bt-header__left">
        <button id="toggleSidebar" class="bt-sidebar__toggle"><i class="fas fa-bars"></i></button>
        <div class="bt-logo">BOOK-TUNE</div>
        <form class="bt-search" method="GET" action="search.php">
            <input type="text" name="q" placeholder="Search books or users..." required>
            <button type="submit" class="bt-btn bt-btn--search"><i class="fas fa-search"></i></button>
        </form>
    </div>

    <nav class="bt-header__right">
        <?php if ($loggedUser): ?>
            <div class="user-menu">
                <img src="<?= bt_cover_src($loggedUser['profile_pic'] ?: $defaultAvatar) ?>" alt="Profile" class="user-avatar">
                <span class="username"><?= htmlspecialchars($loggedUser['username']) ?></span>
                <a href="logout.php" class="bt-btn bt-btn--ghost">Logout</a>
            </div>
        <?php else: ?>
            <a class="bt-btn bt-btn--ghost" href="login.php">Login</a>
            <a class="bt-btn bt-btn--ghost" href="signup.php">Sign Up</a>
        <?php endif; ?>
    </nav>
</header>

<main class="bt-main">
    <div class="profile-header">
        <img src="<?= bt_cover_src($profileUser['profile_pic'] ?: $defaultAvatar) ?>" alt="Avatar" class="avatar">
        <div class="profile-details">
            <h1><?= htmlspecialchars($profileUser['username']) ?></h1>
            <p><?= nl2br(htmlspecialchars($profileUser['bio'])) ?: "No bio yet." ?></p>
            <div class="btn-group">
                <?php if ($isOwnProfile): ?>
                    <a href="edit_profile.php" class="bt-btn bt-btn--primary"><i class="fas fa-user-edit"></i> Edit Profile</a>
                <?php elseif (isset($_SESSION['user_id'])): ?>
                    <form id="followForm" method="post" style="display:inline;">
                        <input type="hidden" name="followed_id" value="<?= htmlspecialchars($profileUser['id']) ?>">
                        <input type="hidden" name="action" id="followActionInput" value="<?= $isFollowing ? 'unfollow' : 'follow' ?>">
                        <button id="followBtn" type="submit" class="bt-btn <?= $isFollowing ? '' : 'bt-btn--primary' ?>">
                            <?= $isFollowing ? '<i class="fas fa-user-minus"></i> Unfollow' : '<i class="fas fa-user-plus"></i> Follow' ?>
                        </button>
                    </form>
                <?php endif; ?>
            </div>

            <div style="margin-top:12px;">
                <a id="followersLink" href="followers_list.php?type=followers&user=<?= htmlspecialchars($profileUser['id']) ?>" style="color:var(--brand-color);margin-right:12px;">
                    <strong id="followersCount"><?= isset($followers) ? $followers : 0 ?></strong> Followers
                </a>
                <a href="following_list.php?type=following&user=<?= htmlspecialchars($profileUser['id']) ?>" style="color:var(--brand-color);">
                    <strong><?= isset($following) ? $following : 0 ?></strong> Following
                </a>
            </div>
        </div>
    </div>

    <?php foreach ($statuses as $s): ?>
    <section class="library-section">
        <h2><?= ucfirst(str_replace('_',' ', $s)) ?></h2>
        <?php if (!empty($library[$s])): ?>
            <div class="book-grid">
                <?php foreach ($library[$s] as $b): ?>
                    <div class="book-card">
                        <a href="book.php?id=<?= $b['id'] ?>">
                            <img src="<?= bt_cover_src($b['cover']) ?>" alt="<?= htmlspecialchars($b['title']) ?>">
                            <div class="book-title"><?= htmlspecialchars($b['title']) ?></div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="no-books">No books here yet.</p>
        <?php endif; ?>
    </section>
    <?php endforeach; ?>
    
    <section class="library-section">
        <h2>Reading History</h2>
        <?php if ($readingHistory): ?>
            <div class="book-grid">
                <?php foreach ($readingHistory as $b): ?>
                    <div class="book-card">
                        <a href="book.php?id=<?= $b['id'] ?>">
                            <img src="<?= bt_cover_src($b['cover']) ?>" alt="<?= htmlspecialchars($b['title']) ?>">
                            <div class="book-title"><?= htmlspecialchars($b['title']) ?></div>
                            <div class="read-date">Last read: <?= date("F j, Y", strtotime($b['last_read_at'])) ?></div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="no-books">No books in history yet.</p>
        <?php endif; ?>
    </section>
</main>

<script>
const sidebar = document.getElementById("sidebar");
const toggleBtn = document.getElementById("toggleSidebar");
const closeBtn = document.getElementById("closeSidebar");
if (sidebar && toggleBtn && closeBtn) {
    const closeSidebar = () => sidebar.classList.remove("is-expanded");
    toggleBtn.addEventListener("click", e => { e.stopPropagation(); sidebar.classList.add("is-expanded"); });
    closeBtn.addEventListener("click", closeSidebar);
    document.addEventListener("click", e => {
        if (sidebar.classList.contains("is-expanded") && !sidebar.contains(e.target) && e.target !== toggleBtn) {
            closeSidebar();
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    const followForm = document.getElementById('followForm');
    const followBtn = document.getElementById('followBtn');
    const actionInput = document.getElementById('followActionInput');
    const followersCountEl = document.getElementById('followersCount');

    if (!followForm || !followBtn || !actionInput) return;

    followForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const currentAction = actionInput.value;
        const followedId = <?= json_encode($profileUser['id']) ?>;

        fetch('follow_action.php', {
            method:'POST',
            headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'followed_id='+encodeURIComponent(followedId)
        })
        .then(r=>r.json())
        .then(data=>{
            if(!data||!data.status)return;
            if(data.status==='followed'){
                actionInput.value='unfollow';
                followBtn.innerHTML='<i class="fas fa-user-minus"></i> Unfollow';
                followBtn.classList.remove('bt-btn--primary');
                followBtn.classList.add('bt-btn--secondary');
                if(followersCountEl) followersCountEl.textContent=(parseInt(followersCountEl.textContent)||0)+1;
            } else if(data.status==='unfollowed'){
                actionInput.value='follow';
                followBtn.innerHTML='<i class="fas fa-user-plus"></i> Follow';
                followBtn.classList.remove('bt-btn--secondary');
                followBtn.classList.add('bt-btn--primary');
                if(followersCountEl) followersCountEl.textContent=Math.max(0,(parseInt(followersCountEl.textContent)||0)-1);
            } else if(data.status==='error'){
                alert(data.message||'An error occurred');
            }
        })
        .catch(err=>{
            console.error(err);
            followForm.submit();
        });
    });
});
</script>
</body>
</html>
