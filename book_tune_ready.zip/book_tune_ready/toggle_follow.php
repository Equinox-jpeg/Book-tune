<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$follower_id = $_SESSION['user_id'];
$followed_id = (int)$_POST['followed_id'];

// Prevent following yourself
if ($follower_id === $followed_id) {
    header("Location: user_profile.php?id=$followed_id");
    exit;
}

// Check if already following
$stmt = $pdo->prepare("SELECT * FROM followers WHERE follower_id = ? AND followed_id = ?");
$stmt->execute([$follower_id, $followed_id]);
$exists = $stmt->fetch();

if ($exists) {
    // Unfollow
    $stmt = $pdo->prepare("DELETE FROM followers WHERE follower_id = ? AND followed_id = ?");
    $stmt->execute([$follower_id, $followed_id]);
} else {
    // Follow
    $stmt = $pdo->prepare("INSERT INTO followers (follower_id, followed_id, created_at) VALUES (?, ?, NOW())");
    $stmt->execute([$follower_id, $followed_id]);
}

// Redirect back
header("Location: user_profile.php?id=$followed_id");
exit;
?>
