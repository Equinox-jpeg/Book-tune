
CREATE DATABASE IF NOT EXISTS book_tune CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE book_tune;
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  is_premium TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS books (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  author VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  category VARCHAR(100) NOT NULL,
  cover VARCHAR(255) NOT NULL,
  is_premium TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO books (title, author, description, category, cover, is_premium) VALUES
('The Midnight Library','Matt Haig','Between life and death lies a library where each book lets Nora Seed try a life she might have lived, forcing her to face regret, hope, and what makes a life meaningful.','Fiction','midnight_library.jpg',0),
('Project Hail Mary','Andy Weir','Ryland Grace wakes alone on a spaceship with amnesia—and a mission that could save Earth from an extinction-level event—if he can survive long enough to remember why he is there.','Science Fiction','project_hail_mary.jpg',1),
('The Silent Patient','Alex Michaelides','After shooting her husband, artist Alicia Berenson never speaks again. A psychotherapist becomes obsessed with unlocking her secret in this twisty psychological thriller.','Thriller','silent_patient.jpg',0),
('Educated','Tara Westover','Raised by survivalists in rural Idaho and denied formal schooling, Tara teaches herself enough to step into the wider world, where education transforms her life.','Memoir','educated.jpg',0),
('Dune','Frank Herbert','On the desert planet Arrakis, noble houses battle for control of the spice while a young heir, Paul Atreides, confronts destiny, prophecy, and power.','Science Fiction','dune.jpg',1),
('Where the Crawdads Sing','Delia Owens','Abandoned in the marsh, Kya Clark grows up alone, finding solace in nature—until a death in town makes her the prime suspect.','Fiction','where_the_crawdads_sing.jpg',0),
('Atomic Habits','James Clear','A practical system for building good habits and breaking bad ones through tiny, incremental changes that compound.','Self-Help','atomic_habits.jpg',0),
('The Song of Achilles','Madeline Miller','A lyrical retelling of the bond between Achilles and Patroclus, from their boyhood to the siege of Troy.','Historical Fiction','song_of_achilles.jpg',1),
('Circe','Madeline Miller','Born to the sun god Helios but shunned by gods and mortals, Circe discovers witchcraft and her own power on a lonely island.','Fantasy','circe.jpg',1),
('Becoming','Michelle Obama','The former First Lady tells her story with candor—from childhood on the South Side to life in the White House.','Memoir','becoming.jpg',0),
('The Hobbit','J.R.R. Tolkien','A reluctant Bilbo Baggins is swept into a quest to reclaim a dwarven treasure guarded by the dragon Smaug.','Fantasy','the_hobbit.jpg',0),
('The Great Gatsby','F. Scott Fitzgerald','In Jazz Age New York, mysterious millionaire Jay Gatsby pursues an impossible dream: to reclaim the golden past.','Classic','great_gatsby.jpg',0),
('Pride and Prejudice','Jane Austen','Elizabeth Bennet spars with the proud Mr. Darcy as love, class, and wit collide in Regency England.','Classic','pride_and_prejudice.jpg',0),
('1984','George Orwell','In a totalitarian state of unending surveillance, Winston Smith dares to seek truth and love.','Dystopian','1984.jpg',1),
('Brave New World','Aldous Huxley','A genetically engineered, pleasure-driven society hides a profound cost, exposed by a man born outside it.','Dystopian','brave_new_world.jpg',1),
('The Catcher in the Rye','J.D. Salinger','Holden Caulfield wanders New York City wrestling with grief, hypocrisy, and the pain of growing up.','Classic','catcher_in_the_rye.jpg',0),
('To Kill a Mockingbird','Harper Lee','Young Scout watches her father defend a Black man falsely accused, confronting racism in the American South.','Classic','to_kill_a_mockingbird.jpg',0),
('The Alchemist','Paulo Coelho','A shepherd follows a recurring dream to Egypt in search of treasure, discovering a deeper purpose.','Fiction','the_alchemist.jpg',0),
('Sapiens: A Brief History of Humankind','Yuval Noah Harari','A sweeping narrative of human history—from foraging bands to global empires and biotech frontiers.','Nonfiction','sapiens.jpg',1),
('A Court of Thorns and Roses','Sarah J. Maas','After killing a wolf, Feyre is taken to the faerie lands and entangled in ancient magic and dangerous love.','Fantasy','acotar.jpg',1),
('It Ends With Us','Colleen Hoover','Lily must make an impossible choice when love and loyalty collide.','Romance','it_ends_with_us.jpg',0),
('Verity','Colleen Hoover','A struggling writer uncovers a chilling unfinished manuscript while finishing another author’s series.','Thriller','verity.jpg',0),
('The Girl on the Train','Paula Hawkins','An unreliable witness inserts herself into a missing-person case with devastating consequences.','Thriller','girl_on_the_train.jpg',1),
('Gone Girl','Gillian Flynn','A marriage unravels into deceit and media frenzy after a sudden disappearance.','Thriller','gone_girl.jpg',1),
('The Hunger Games','Suzanne Collins','Katniss Everdeen volunteers to take her sister’s place in a televised fight to the death.','Dystopian','hunger_games.jpg',0),
('Catching Fire','Suzanne Collins','Katniss becomes the spark of rebellion as the Capitol tightens its grip.','Dystopian','catching_fire.jpg',0),
('Mockingjay','Suzanne Collins','War erupts as the districts rise against the Capitol and Katniss faces the cost of revolution.','Dystopian','mockingjay.jpg',1),
('Foundation','Isaac Asimov','Hari Seldon predicts the fall of the Galactic Empire and a plan to shorten the coming dark age.','Science Fiction','foundation.jpg',0),
('Neuromancer','William Gibson','A washed-up hacker is hired for one last impossible heist in cyberspace.','Science Fiction','neuromancer.jpg',1),
('Snow Crash','Neal Stephenson','A sword-wielding hacker battles a mind-altering virus in the Metaverse.','Science Fiction','snow_crash.jpg',1);
