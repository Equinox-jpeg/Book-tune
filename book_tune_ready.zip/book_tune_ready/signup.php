<?php
session_start();
require_once "db.php";
$message = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST["username"]);
    $password = $_POST["password"];
    $confirm = $_POST["confirm"];
    if ($password !== $confirm) { $message = "Passwords do not match."; }
    else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        try { $stmt->execute([$username, $hash]); header("Location: login.php"); exit; }
        catch (PDOException $e) { $message = "Username already taken."; }
    }
}
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Sign Up - Book‑Tune</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css" /></head><body>
<header class="site-header"><h1 class="logo">📚 Book‑Tune</h1><nav class="auth">
<a class="btn ghost" href="index.php">Home</a><a class="btn" href="login.php">Log In</a></nav></header>
<?php if($message): ?><div class="alert"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
<form method="POST" class="form"><h2>Create Account</h2>
<div class="row"><label>Username</label><input type="text" name="username" required></div>
<div class="row"><label>Password</label><input type="password" name="password" required></div>
<div class="row"><label>Confirm Password</label><input type="password" name="confirm" required></div>
<button type="submit" class="submit">Sign Up</button>
<p class="hint">Already have an account? <a href="login.php">Log in here</a>.</p></form>
<footer class="site-footer"><p>© <?php echo date('Y'); ?> Book‑Tune</p></footer></body></html>
