<?php
session_start();
require_once "db.php";
header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || !isset($_POST['followed_id'])) {
    echo json_encode(['status'=>'error','message'=>'Unauthorized or missing data']);
    exit;
}

$follower = (int) $_SESSION['user_id'];
$followed = (int) $_POST['followed_id'];

if ($follower === $followed) {
    echo json_encode(['status'=>'error','message'=>'Cannot follow yourself']);
    exit;
}

// Check existing
$stmt = $pdo->prepare("SELECT 1 FROM followers WHERE follower_id = ? AND followed_id = ? LIMIT 1");
$stmt->execute([$follower, $followed]);
$exists = (bool) $stmt->fetchColumn();

try {
    if ($exists) {
        $stmt = $pdo->prepare("DELETE FROM followers WHERE follower_id = ? AND followed_id = ?");
        $stmt->execute([$follower, $followed]);
        echo json_encode(['status'=>'unfollowed']);
    } else {
        $stmt = $pdo->prepare("INSERT INTO followers (follower_id, followed_id, created_at) VALUES (?, ?, NOW())");
        $stmt->execute([$follower, $followed]);
        echo json_encode(['status'=>'followed']);
    }
} catch (Exception $e) {
    echo json_encode(['status'=>'error','message'=>'Database error']);
}
