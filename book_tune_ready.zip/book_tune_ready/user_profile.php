<?php
session_start();
require_once "db.php";

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$profile_id = (int)$_GET['id'];

// Fetch user info
$stmt = $pdo->prepare("SELECT id, username, bio, profile_pic FROM users WHERE id = ?");
$stmt->execute([$profile_id]);
$profile = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$profile) {
    echo "<script>alert('User not found.'); window.location.href='index.php';</script>";
    exit;
}

$defaultAvatar = "assets/default-profile.png";
$profileImage = (!empty($profile['profile_pic']) && file_exists($profile['profile_pic'])) ? $profile['profile_pic'] : $defaultAvatar;

// Load logged-in user (for sidebar/avatar)
$loggedUser = null;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT id, username, profile_pic FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $loggedUser = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Followers & Following count (for displayed profile)
$stmt = $pdo->prepare("SELECT COUNT(*) FROM followers WHERE followed_id = ?");
$stmt->execute([$profile_id]);
$followerCount = (int)$stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM followers WHERE follower_id = ?");
$stmt->execute([$profile_id]);
$followingCount = (int)$stmt->fetchColumn();

// Follow status (is current logged-in user following this profile?)
$isFollowing = false;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT 1 FROM followers WHERE follower_id = ? AND followed_id = ?");
    $stmt->execute([$_SESSION['user_id'], $profile_id]);
    $isFollowing = (bool)$stmt->fetchColumn();
}

/**
 * Helper: cover source (handles Open Library IDs, ISBN numeric ids, full URLs, or local file)
 * (Kept exactly from your original.)
 */
function bt_cover_src($val) {
    if (empty($val)) return "assets/placeholder.png";
    if (strpos($val, 'OL') === 0) {
        return "https://covers.openlibrary.org/b/olid/" . htmlspecialchars($val) . "-M.jpg";
    }
    if (is_numeric($val) && strlen($val) >= 10) {
        return "https://covers.openlibrary.org/b/id/" . htmlspecialchars($val) . "-M.jpg";
    }
    return (preg_match('/^https?:\\/\\//', $val) ? $val : 'covers/' . htmlspecialchars($val));
}

/**
 * Fetch books for a user by `library` table status.
 * NOTE: this project uses `library` table (see SQL dump), not `user_books`).
 */
function getBooksByStatus($pdo, $user_id, $status, $limit = 8) {
    $safe_limit = max(0, (int)$limit);
    $sql = "
        SELECT b.id, b.title, b.cover
        FROM library l
        JOIN books b ON l.book_id = b.id
        WHERE l.user_id = ? AND l.status = ? 
        ORDER BY l.added_at DESC
        LIMIT " . $safe_limit;

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id, $status]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get books for the viewed profile (kept from original)
$readingBooks   = getBooksByStatus($pdo, $profile_id, 'reading');
$planBooks      = getBooksByStatus($pdo, $profile_id, 'plan_to_read');
$completedBooks = getBooksByStatus($pdo, $profile_id, 'completed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($profile['username']) ?>'s Profile - Book-Tune</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* === Redesigned Dark Theme CSS (from your other page) === */
        :root {
            --bg-primary: #080d15;
            --bg-secondary: #101620;
            --card-bg: #1c2433;
            --text-primary: #e8eef8;
            --text-secondary: #a0a8b4;
            --brand-color: #5d83ff;
            --brand-hover: #7a9aff;
            --border-color: #2e3b50;
            --brand-premium: #f3c74c;
            --shadow: 0 10px 40px rgba(0, 0, 0, 0.4);
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-primary);
            color: var(--text-primary);
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        
        a { text-decoration: none; color: inherit; }
        
        /* === Sidebar & Topbar Styles === */
        .bt-sidebar {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            width: 250px;
            background-color: var(--bg-secondary);
            border-right: 1px solid var(--border-color);
            padding: 25px 20px;
            display: flex;
            flex-direction: column;
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 100;
        }
        .bt-sidebar.is-expanded { transform: translateX(0); }
        .bt-sidebar__brand {
            font-weight: 800;
            font-size: 1.5rem;
            margin-bottom: 30px;
            color: var(--brand-color);
            position: relative;
        }
        .bt-sidebar__toggle {
            background: none;
            border: none;
            color: var(--text-secondary);
            font-size: 1.5rem;
            cursor: pointer;
            transition: color 0.2s;
        }
        .bt-sidebar #closeSidebar {
            position: absolute;
            top: 0;
            right: 0;
        }
        .bt-sidebar .sidebar-profile {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 10px 15px;
            margin-bottom: 25px;
            background: var(--card-bg);
            border-radius: 12px;
        }
        .bt-sidebar .sidebar-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--brand-color);
        }
        .bt-sidebar .sidebar-username { font-weight: 600; }
        .bt-nav { display: flex; flex-direction: column; gap: 10px; }
        .bt-nav__item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            color: var(--text-secondary);
            font-weight: 500;
            border-radius: 12px;
            transition: all 0.2s;
        }
        .bt-nav__item:hover {
            background-color: var(--brand-color);
            color: #fff;
        }
        .bt-header {
            position: sticky;
            top: 0;
            left: 0;
            right: 0;
            background-color: var(--bg-primary);
            border-bottom: 1px solid var(--border-color);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 50;
            box-shadow: 0 4px 10px var(--shadow);
        }
        .bt-header__left {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .bt-logo {
            color: var(--brand-color);
            font-size: 1.2rem;
            font-weight: 700;
            display: none;
        }
        .bt-search {
            position: relative;
            width: 100%;
            max-width: 350px;
            margin-left: 20px;
        }
        .bt-search input {
            width: 100%;
            padding: 10px 45px 10px 20px;
            border-radius: 50px;
            border: 1px solid var(--border-color);
            background: var(--bg-secondary);
            color: var(--text-primary);
            font-size: 1rem;
            transition: border-color 0.2s;
        }
        .bt-search input:focus { outline: none; border-color: var(--brand-color); }
        .bt-search button {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--text-secondary);
            font-size: 1rem;
            cursor: pointer;
        }
        .bt-header__right {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-left: auto; /* <<-- ADDED: push the right section fully to the right */
        }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .user-avatar { width: 35px; height: 35px; border-radius: 50%; object-fit: cover; }
        .username { font-weight: 600; color: var(--text-primary); }
        .bt-btn {
            padding: 12px 24px;
            border-radius: 50px;
            border: 1px solid var(--border-color);
            background: var(--card-bg);
            color: var(--text-primary);
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all .2s ease;
        }
        .bt-btn:hover { background: var(--brand-color); color:#fff; border-color: var(--brand-color); transform: translateY(-2px); }
        .bt-btn--primary { background: var(--brand-color); color: #fff; border: none; }
        .bt-btn--primary:hover { background: var(--brand-hover); }
        .bt-btn--gold { background: var(--brand-premium); color: var(--bg-primary); border: none; }
        .bt-btn--gold:hover { background: #ffd740; transform: translateY(-2px); }

        /* === Profile-specific styles === */
        .bt-main {
            padding: 40px 20px;
            max-width: 1200px;
            margin: 0 auto;
            transition: margin-left 0.3s ease;
        }
        
        .profile-header {
            display: flex;
            align-items: center;
            gap: 30px;
            background: var(--card-bg);
            border-radius: 16px;
            padding: 40px;
            margin-bottom: 30px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border-color);
        }
        .profile-header .avatar { 
            width: 120px; 
            height: 120px; 
            border-radius: 50%; 
            object-fit: cover; 
            border: 4px solid var(--brand-color);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
        }
        .profile-details h1 { 
            margin: 0 0 5px; 
            font-size: 2.5rem; 
            font-weight: 800;
            color: var(--text-primary);
        }
        .profile-details p { 
            margin: 0 0 15px; 
            font-size: 1rem; 
            color: var(--text-secondary); 
            line-height: 1.6;
        }
        .profile-details .btn-group { 
            display: flex; 
            gap: 10px;
            flex-wrap: wrap;
        }
        .follow-section { margin-top: 12px; }
        .bt-btn--secondary { background: #666; color: #fff; border: none; }
        .library-section { 
            margin-bottom: 40px; 
        }
        .library-section h2 { 
            font-size: 1.8rem; 
            border-bottom: 1px solid var(--border-color); 
            padding-bottom: 10px; 
            margin-bottom: 20px;
            font-weight: 700;
        }
        .book-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); 
            gap: 20px; 
        }
        .book-card { 
            background: var(--card-bg); 
            border-radius: 12px; 
            overflow: hidden; 
            box-shadow: var(--shadow); 
            transition: transform 0.2s ease, box-shadow 0.2s ease; 
            border: 1px solid var(--border-color);
            position: relative;
        }
        .book-card:hover { 
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.4);
        }
        .book-card a { 
            display: block; 
        }
        .book-card img { 
            width: 100%; 
            height: 200px; 
            object-fit: cover; 
            display: block; 
        }
        .book-card .book-title { 
            padding: 15px; 
            text-align: center; 
            font-weight: 600; 
            font-size: 1rem; 
            white-space: nowrap; 
            overflow: hidden; 
            text-overflow: ellipsis;
            color: var(--text-primary);
        }
        .no-books { 
            color: var(--text-secondary); 
            font-style: italic; 
            text-align: center; 
            padding: 20px; 
        }
        .read-date {
            font-size: 0.8rem;
            color: var(--text-secondary);
            text-align: center;
            padding: 0 15px 15px;
        }

        @media (min-width: 768px) {
            .bt-main {
                margin: 40px auto 40px 280px;
                padding: 0 20px;
            }
            .bt-sidebar { transform: translateX(0); }
            .bt-sidebar__toggle { display: none; }
            .bt-header__left { display: none; }
            .bt-header { left: 250px; width: calc(100% - 250px); }
            .bt-logo { display: block; }
        }
        @media (max-width: 767px) {
            .profile-header { flex-direction: column; text-align: center; }
            .profile-details { text-align: center; }
            .bt-main { padding-top: 80px; }
            .bt-header { justify-content: space-between; }
        }
    </style>
</head>
<body>

<aside class="bt-sidebar" id="sidebar">
    <div class="bt-sidebar__brand">Menu</div>
    <button id="closeSidebar" class="bt-sidebar__toggle"><i class="fas fa-arrow-left"></i></button>

    <?php if ($loggedUser): ?>
    <a href="profile.php" class="sidebar-profile">
        <img src="<?= htmlspecialchars(!empty($loggedUser['profile_pic']) && file_exists($loggedUser['profile_pic']) ? $loggedUser['profile_pic'] : $defaultAvatar) ?>" alt="Profile" class="sidebar-avatar">
        <span class="sidebar-username"><?= htmlspecialchars($loggedUser['username']) ?></span>
    </a>
    <?php endif; ?>

    <nav class="bt-nav">
        <a href="index.php" class="bt-nav__item"><i class="fas fa-home"></i><span class="bt-nav__text">Home</span></a>
        <a href="genres.php" class="bt-nav__item"><i class="fas fa-th-large"></i><span class="bt-nav__text">Genres</span></a>
        <a href="index.php#popular" class="bt-nav__item scroll-link"><i class="fas fa-fire"></i><span class="bt-nav__text">Popular</span></a>
        <a href="index.php#new-releases" class="bt-nav__item scroll-link"><i class="fas fa-star"></i><span class="bt-nav__text">New Releases</span></a>
        <a href="premium.php" class="bt-nav__item"><i class="fas fa-crown"></i><span class="bt-nav__text">Premium</span></a>
        <a href="upload.php" class="bt-nav__item"><i class="fas fa-upload"></i><span class="bt-nav__text">Upload</span></a>
    </nav>
</aside>

<header class="bt-header" id="topbar">
    <div class="bt-header__left">
        <button id="toggleSidebar" class="bt-sidebar__toggle"><i class="fas fa-bars"></i></button>
        <div class="bt-logo">BOOK-TUNE</div>
        <form class="bt-search" method="GET" action="search.php">
            <input type="text" name="q" placeholder="Search books or users..." required>
            <button type="submit" class="bt-btn bt-btn--search"><i class="fas fa-search"></i></button>
        </form>
    </div>

    <nav class="bt-header__right">
        <?php if ($loggedUser): ?>
            <div class="user-menu">
                <img src="<?= htmlspecialchars(!empty($loggedUser['profile_pic']) && file_exists($loggedUser['profile_pic']) ? $loggedUser['profile_pic'] : $defaultAvatar) ?>" alt="Profile" class="user-avatar">
                <span class="username"><?= htmlspecialchars($loggedUser['username']) ?></span>
                <a href="logout.php" class="bt-btn bt-btn--ghost">Logout</a>
            </div>
        <?php else: ?>
            <a class="bt-btn bt-btn--ghost" href="login.php">Login</a>
            <a class="bt-btn bt-btn--ghost" href="signup.php">Sign Up</a>
        <?php endif; ?>
    </nav>
</header>

<main class="bt-main">
    <div class="profile-header">
        <img src="<?= htmlspecialchars($profileImage) ?>" alt="<?= htmlspecialchars($profile['username']) ?>" class="avatar">
        <div class="profile-details">
            <h1><?= htmlspecialchars($profile['username']) ?></h1>
            <p><?= nl2br(htmlspecialchars($profile['bio'])) ?: "No bio yet." ?></p>
            <div class="btn-group">
                <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] === $profile['id']): ?>
                    <a href="edit_profile.php" class="bt-btn bt-btn--primary"><i class="fas fa-user-edit"></i> Edit Profile</a>
                <?php elseif (isset($_SESSION['user_id']) && $_SESSION['user_id'] !== $profile['id']): ?>
                    <form action="toggle_follow.php" method="POST" style="display:inline;">
                        <input type="hidden" name="followed_id" value="<?= $profile['id'] ?>">
                        <button type="submit" class="bt-btn <?= $isFollowing ? 'bt-btn--secondary' : 'bt-btn--primary' ?>">
                            <?= $isFollowing ? '<i class="fas fa-user-minus"></i> Unfollow' : '<i class="fas fa-user-plus"></i> Follow' ?>
                        </button>
                    </form>
                <?php endif; ?>
            </div>

            <div style="margin-top:12px;">
                <a id="followersLink" href="followers_list.php?id=<?= $profile['id'] ?>" style="color:var(--brand-color);margin-right:12px;">
                    <strong id="followersCount"><?= $followerCount ?></strong> Followers
                </a>
                <a href="following_list.php?id=<?= $profile['id'] ?>" style="color:var(--brand-color);">
                    <strong><?= $followingCount ?></strong> Following
                </a>
            </div>
        </div>
    </div>

    <section class="library-section">
        <h2>Currently Reading</h2>
        <div class="book-grid">
          <?php if (!empty($readingBooks)): ?>
            <?php foreach ($readingBooks as $book): ?>
              <div class="book-card">
                <a href="book_details.php?id=<?= $book['id'] ?>">
                  <img src="<?= bt_cover_src($book['cover']) ?>" alt="<?= htmlspecialchars($book['title']) ?>">
                  <div class="book-title"><?= htmlspecialchars($book['title']) ?></div>
                </a>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <p class="no-books">Not reading any books currently.</p>
          <?php endif; ?>
        </div>
    </section>

    <section class="library-section">
        <h2>Plan to Read</h2>
        <div class="book-grid">
          <?php if (!empty($planBooks)): ?>
            <?php foreach ($planBooks as $book): ?>
              <div class="book-card">
                <a href="book_details.php?id=<?= $book['id'] ?>">
                  <img src="<?= bt_cover_src($book['cover']) ?>" alt="<?= htmlspecialchars($book['title']) ?>">
                  <div class="book-title"><?= htmlspecialchars($book['title']) ?></div>
                </a>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <p class="no-books">No books planned yet.</p>
          <?php endif; ?>
        </div>
    </section>

    <section class="library-section">
        <h2>Completed</h2>
        <div class="book-grid">
          <?php if (!empty($completedBooks)): ?>
            <?php foreach ($completedBooks as $book): ?>
              <div class="book-card">
                <a href="book_details.php?id=<?= $book['id'] ?>">
                  <img src="<?= bt_cover_src($book['cover']) ?>" alt="<?= htmlspecialchars($book['title']) ?>">
                  <div class="book-title"><?= htmlspecialchars($book['title']) ?></div>
                </a>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <p class="no-books">No completed books yet.</p>
          <?php endif; ?>
        </div>
    </section>

</main>

<script>
// Sidebar toggle logic (from the redesigned page)
const sidebar = document.getElementById("sidebar");
const toggleBtn = document.getElementById("toggleSidebar");
const closeBtn = document.getElementById("closeSidebar");
if (sidebar && toggleBtn && closeBtn) {
    const closeSidebar = () => sidebar.classList.remove("is-expanded");
    toggleBtn.addEventListener("click", e => { e.stopPropagation(); sidebar.classList.add("is-expanded"); });
    closeBtn.addEventListener("click", closeSidebar);
    document.addEventListener("click", e => {
        if (sidebar.classList.contains("is-expanded") && !sidebar.contains(e.target) && e.target !== toggleBtn) {
            closeSidebar();
        }
    });
}
</script>
</body>
</html>
