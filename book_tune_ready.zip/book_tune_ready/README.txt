Book‑Tune — Ready Starter (Dark + Pink)

Quick start:
1) Import DB:  mysql -u root -p < books.sql
2) Edit db.php with your credentials.
3) Fetch covers: open http://localhost/book_tune_ready/fetch_covers.php  (or: php fetch_covers.php)
4) Visit: http://localhost/book_tune_ready/

Notes:
- Covers are fetched on-demand into /covers. Re-run safely; existing files are skipped.
- Add more rows by INSERTing into books and adding filename=>URL in fetch_covers.php.
Created: 2025-08-14T03:40:02.885037Z
