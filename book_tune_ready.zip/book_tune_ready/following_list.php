<?php
session_start();
require_once "db.php";

// Use logged-in user if no ?id= provided
$profile_id = isset($_GET['id']) ? (int)$_GET['id'] : ($_SESSION['user_id'] ?? 0);
if (!$profile_id) {
    echo "<script>alert('Please log in first.'); window.location.href='login.php';</script>";
    exit;
}

// Fetch user info
$stmt = $pdo->prepare("SELECT id, username, profile_pic FROM users WHERE id = ?");
$stmt->execute([$profile_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "<script>alert('User not found.'); window.location.href='profile.php';</script>";
    exit;
}

$defaultAvatar = "assets/default-profile.png";

// Fetch users this person is following
$stmt = $pdo->prepare("
    SELECT u.id, u.username, u.profile_pic, f.created_at
    FROM followers f
    JOIN users u ON f.followed_id = u.id
    WHERE f.follower_id = ?
    ORDER BY f.created_at DESC
");
$stmt->execute([$profile_id]);
$following = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($user['username']) ?>’s Following - Book-Tune</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root {
  --bg-primary: #0b0f19;
  --bg-secondary: #141a29;
  --card-bg: #1c2433;
  --text-primary: #e8eef8;
  --text-secondary: #a0a8b4;
  --brand-color: #5d83ff;
  --border-color: #2e3b50;
}

body {
  font-family: 'Inter', sans-serif;
  background: var(--bg-primary);
  color: var(--text-primary);
  margin: 0;
  padding: 0;
  min-height: 100vh;
}

.header {
  background: var(--bg-secondary);
  border-bottom: 1px solid var(--border-color);
  padding: 15px 25px;
  text-align: center;
}

.header h1 {
  font-size: 1.5rem;
  color: var(--brand-color);
  margin: 0;
}

.container {
  max-width: 1000px;
  margin: 30px auto;
  padding: 20px;
}

.follow-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
  gap: 25px;
  justify-items: center;
}

.follow-card {
  background: var(--card-bg);
  border-radius: 12px;
  border: 1px solid var(--border-color);
  text-align: center;
  padding: 15px 10px;
  width: 130px;
  transition: all 0.25s ease;
  cursor: pointer;
}

.follow-card:hover {
  transform: translateY(-5px);
  border-color: var(--brand-color);
  box-shadow: 0 4px 10px rgba(93,131,255,0.2);
}

.follow-card img {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid var(--brand-color);
}

.username {
  margin-top: 10px;
  font-weight: 600;
  color: var(--text-primary);
  font-size: 0.95rem;
  word-break: break-word;
}

.follow-date {
  margin-top: 4px;
  color: var(--text-secondary);
  font-size: 0.8rem;
}

.no-following {
  text-align: center;
  color: var(--text-secondary);
  font-size: 1rem;
  margin-top: 50px;
}

.back-btn {
  display: block;
  text-align: center;
  margin-top: 40px;
  color: var(--text-secondary);
  transition: color 0.2s;
}
.back-btn:hover {
  color: var(--brand-color);
}
</style>
</head>
<body>

<div class="header">
  <h1><?= htmlspecialchars($user['username']) ?>’s Following</h1>
</div>

<div class="container">
  <?php if (count($following) > 0): ?>
    <div class="follow-grid">
      <?php foreach ($following as $f): 
        $pic = ($f['profile_pic'] && file_exists($f['profile_pic'])) ? $f['profile_pic'] : $defaultAvatar;
      ?>
      <a href="user_profile.php?id=<?= $f['id'] ?>" class="follow-card">
        <img src="<?= htmlspecialchars($pic) ?>" alt="<?= htmlspecialchars($f['username']) ?>">
        <div class="username"><?= htmlspecialchars($f['username']) ?></div>
        <div class="follow-date">Followed <?= date("M j, Y", strtotime($f['created_at'])) ?></div>
      </a>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <p class="no-following">This user isn’t following anyone yet.</p>
  <?php endif; ?>

  <a href="profile.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Profile</a>
</div>

</body>
</html>
