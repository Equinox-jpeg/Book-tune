<?php
session_start();
require_once "db.php"; // database connection

// Check if user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION["user_id"];

// Handle fake payment and upgrade
if (isset($_POST["confirm_payment"])) {
    // Upgrade user
    $stmt = $pdo->prepare("UPDATE users SET is_premium = 1 WHERE id = ?");
    $stmt->execute([$userId]);

    $_SESSION["is_premium"] = 1; // update session
    header("Location: index.php");
    exit();
}

// Check if already premium
$stmt = $pdo->prepare("SELECT is_premium FROM users WHERE id = ?");
$stmt->execute([$userId]);
$isPremium = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Go Premium</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .premium-card {
            max-width: 400px;
            margin: 40px auto;
            padding: 20px;
            background: var(--card);
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.4);
        }
        .premium-card h2 {
            margin-bottom: 15px;
        }
        .premium-card p {
            margin-bottom: 20px;
        }
        .btn {
            padding: 10px 20px;
            background: var(--brand1);
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
        }
        .btn:hover {
            background: var(--brand2);
        }
    </style>
</head>
<body>
    <header class="site-header">
        <h1>🌟 Go Premium</h1>
    </header>

    <main>
        <?php if ($isPremium): ?>
            <div class="premium-card">
                <h2>You're already Premium! 🎉</h2>
                <p>Enjoy all your extra features.</p>
                <a href="index.php" class="btn">← Back to Home</a>
            </div>
        <?php else: ?>
            <div class="premium-card">
                <h2>Upgrade to Premium</h2>
                <p>Unlock unlimited book uploads, exclusive covers, and more!</p>
                <p><strong>Price:</strong> RM30 (per/year)</p>
                <form method="post">
                    <input type="hidden" name="confirm_payment" value="1">
                    <button type="submit" class="btn">Pay & Upgrade</button>
                </form>
            </div>
        <?php endif; ?>
    </main>
</body>
</html>
