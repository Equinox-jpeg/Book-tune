<?php
session_start();
require_once "db.php";

// Fetch user data if logged in
$user = null;
$profileImage = "assets/default-profile.png"; // Default image
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT id, username, bio, profile_pic, is_premium FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // If user data is found, update session and set the profile image
    if ($user) {
        $_SESSION['username'] = $user['username'];
        $_SESSION['is_premium'] = $user['is_premium'];
        
        // Use the profile_pic from the database if it exists, otherwise use the default
        if (!empty($user['profile_pic'])) {
            $profileImage = htmlspecialchars($user['profile_pic']);
        }
    }
}

// ✅ Safer version of bt_cover_src – handles all cases
function bt_cover_src($val) {
    if (empty($val)) return "assets/placeholder.png"; // fallback image
    if (preg_match('/^https?:\\/\\//', $val)) return htmlspecialchars($val); // remote URL
    if (strpos($val, 'covers/') === 0) return htmlspecialchars($val); // already has "covers/"
    return 'covers/' . htmlspecialchars($val); // missing "covers/", add it
}


// Fetch book data
$heroBooks = $pdo->query("SELECT * FROM books ORDER BY created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
$recommendedBooks = $pdo->query("SELECT * FROM books ORDER BY RAND() LIMIT 12")->fetchAll(PDO::FETCH_ASSOC);

/* ---- UPDATED: mix in some premium without randomizing the overall order ---- */
/* New Releases: 9 newest non-premium + 3 newest premium, ordered by created_at DESC */
$newBooks = $pdo->query("
    SELECT * FROM (
        SELECT * FROM books
        WHERE (is_premium = 0 OR is_premium IS NULL)
        ORDER BY created_at DESC
        LIMIT 9
    ) AS normal
    UNION ALL
    SELECT * FROM (
        SELECT * FROM books
        WHERE is_premium = 1
        ORDER BY created_at DESC
        LIMIT 3
    ) AS prem
    ORDER BY created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

/* Popular: 9 most-viewed non-premium + 3 most-viewed premium, ordered by views DESC */
$popularBooks = $pdo->query("
    SELECT * FROM (
        SELECT * FROM books
        WHERE (is_premium = 0 OR is_premium IS NULL)
        ORDER BY views DESC
        LIMIT 9
    ) AS normal
    UNION ALL
    SELECT * FROM (
        SELECT * FROM books
        WHERE is_premium = 1
        ORDER BY views DESC
        LIMIT 3
    ) AS prem
    ORDER BY views DESC
")->fetchAll(PDO::FETCH_ASSOC);

/* Premium-only section (uses your is_premium column) */
$premiumBooks = $pdo->query("SELECT * FROM books WHERE is_premium = 1 ORDER BY created_at DESC LIMIT 12")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Book-Tune</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@500;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
/* Modern Load More Button */
.load-more {
    display: block;
    margin: 20px auto;
    padding: 10px 25px;
    background-color: var(--panel-2, #1c2530);
    color: var(--text, #e7edf6);
    border: 1px solid var(--border, #2a3440);
    border-radius: 8px;
    font-size: 0.95rem;
    cursor: pointer;
    transition: background 0.3s, transform 0.2s;
}
.load-more:hover {
    background-color: var(--brand, #7aa2ff);
    transform: scale(1.05);
}

/* Section Titles - More Bold & Noticeable */
.bt-section__title {
    font-weight: 800;
    font-size: clamp(1.3rem, 1.1rem + 0.8vw, 1.8rem);
    margin-bottom: 12px;
    border-left: 5px solid var(--brand);
    padding-left: 10px;
    color: var(--text);
}

/* Minimal premium tag to match your UI */
.premium-tag {
    display: inline-block;
    background: var(--brand-2, #ff7ac6);
    color: #fff;
    font-weight: 600;
    padding: 0.2rem 0.6rem;
    border-radius: 999px;
    font-size: 0.75rem;
    margin-top: 0.4rem;
    letter-spacing: 0.3px;
}

/* --- Added/Corrected CSS for header spacing --- */
.user-menu {
    display: flex;
    align-items: center;
    gap: 12px; /* Spacing between the profile link and logout button */
}
.user-profile-link {
    display: flex;
    align-items: center;
    gap: 8px; /* Spacing between the profile image and username */
    text-decoration: none;
    color: var(--text);
    transition: opacity 0.2s;
}
.user-profile-link:hover {
    opacity: 0.8;
}
.user-avatar {
    width: 32px;
    height: 32px;
    border-radius: 999px;
    object-fit: cover;
}
</style>
</head>
<body class="<?= isset($_SESSION['user_id']) ? 'logged-in' : '' ?>">

<aside class="bt-sidebar" id="sidebar">
    <div class="bt-sidebar__brand">
        Menu
        <button id="closeSidebar" class="bt-sidebar__toggle">
            <i class="fas fa-chevron-left"></i>
        </button>
    </div>

    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="profile.php" class="sidebar-profile">
            <img src="<?= $profileImage ?>" alt="Profile" class="sidebar-avatar">
            <span class="sidebar-username"><?= htmlspecialchars($_SESSION['username']) ?></span>
        </a>
    <?php endif; ?>

    <button id="sidebarCloseInside" class="bt-sidebar__close-top">
        <i class="fas fa-arrow-left"></i>
    </button>

    <nav class="bt-nav">
        <a href="index.php" class="bt-nav__item active">
            <i class="fas fa-home"></i><span class="bt-nav__text">Home</span>
        </a>
        <a href="genres.php" class="bt-nav__item">
            <i class="fas fa-th-large"></i><span class="bt-nav__text">Genres</span>
        </a>
        <a href="index.php#popular" class="bt-nav__item scroll-link">
            <i class="fas fa-fire"></i><span class="bt-nav__text">Popular</span>
        </a>
        <a href="index.php#new-releases" class="bt-nav__item scroll-link">
            <i class="fas fa-star"></i><span class="bt-nav__text">New Releases</span>
        </a>
        <a href="premium.php" class="bt-nav__item">
            <i class="fas fa-crown"></i><span class="bt-nav__text">Premium</span>
        </a>
        <a href="upload.php" class="bt-nav__item">
            <i class="fas fa-upload"></i><span class="bt-nav__text">Upload</span>
        </a>
    </nav>
</aside>

<script>
// Smooth scroll with header offset
document.querySelectorAll('.scroll-link').forEach(link => {
    const header = document.querySelector('#topbar');
    if (!header) return;
    link.addEventListener('click', function (e) {
        const url = new URL(this.href, window.location.origin);
        if (window.location.pathname.endsWith('index.php')) {
            e.preventDefault();
            const target = document.querySelector(url.hash);
            if (target) {
                const headerHeight = header.offsetHeight || 0;
                const targetPosition = target.getBoundingClientRect().top + window.scrollY - headerHeight - 10;
                window.scrollTo({ top: targetPosition, behavior: 'smooth' });
            }
        }
    });
});
</script>

<header class="bt-header" id="topbar">
    <div class="bt-header__left">
        <button id="toggleSidebar" class="bt-sidebar__toggle"><i class="fas fa-bars"></i></button>
        <div class="bt-logo">BOOK-TUNE</div>
        <form class="bt-search" method="GET" action="search.php">
            <input type="text" name="q" placeholder="Search books..." required>
            <button type="submit" class="bt-btn bt-btn--search"><i class="fas fa-search"></i></button>
        </form>
    </div>

    <nav class="bt-header__right">
        <?php if (isset($_SESSION['user_id'])): ?>
            <div class="user-menu">
                <a href="profile.php" class="user-profile-link">
                    <img src="<?= $profileImage ?>" alt="Profile" class="user-avatar">
                    <span class="username"><?= htmlspecialchars($_SESSION['username']) ?></span>
                </a>
                <a href="logout.php" class="bt-btn bt-btn--ghost">Logout</a>
            </div>
        <?php else: ?>
            <a class="bt-btn bt-btn--ghost" href="login.php">Login</a>
            <a class="bt-btn bt-btn--ghost" href="signup.php">Sign Up</a>
            <a class="bt-btn bt-btn--gold" href="premium.php">Go Premium</a>
        <?php endif; ?>
    </nav>
</header>

<main class="bt-main" id="mainContent">

    <div class="hero-slider" id="heroSlider">
        <?php foreach ($heroBooks as $index => $book): ?>
        <div class="hero-slide <?= $index === 0 ? 'active' : '' ?>">
            <div class="hero-cover">
                <img src="<?= bt_cover_src($book['cover']) ?>" 
                     alt="<?= htmlspecialchars($book['title']) ?>"
                     data-title="<?= htmlspecialchars($book['title']) ?>"
                     data-author="<?= htmlspecialchars($book['author']) ?>"
                     data-local="<?= preg_match('/^https?:\\/\\//', $book['cover']) ? '0' : '1' ?>">
            </div>
            <div class="hero-details">
                <h1><?= htmlspecialchars($book['title']) ?></h1>
                <div class="hero-tags">
                    <span class="category-chip"><?= htmlspecialchars($book['category']) ?></span>
                </div>
                <div class="hero-meta">
                    By <?= htmlspecialchars($book['author']) ?> • ⭐ <?= $book['rating'] ?> • 👁 <?= $book['views'] ?>
                </div>
                <p><?= htmlspecialchars($book['description']) ?></p>
                <a href="book.php?id=<?= $book['id'] ?>" class="bt-btn bt-btn--search">Read Now</a>
            </div>
        </div>
        <?php endforeach; ?>
        <button class="hero-prev" onclick="moveSlide(-1)">&#10094;</button>
        <button class="hero-next" onclick="moveSlide(1)">&#10095;</button>
    </div>

    <section class="bt-section" id="recommended">
        <h2 class="bt-section__title">Recommended</h2>
        <div class="bt-grid" id="recommended-grid">
            <?php foreach ($recommendedBooks as $book): ?>
                <article class="bt-card">
                    <a class="bt-card__cover" href="book.php?id=<?= $book['id'] ?>">
                        <img src="<?= bt_cover_src($book['cover']) ?>" 
                             alt="<?= htmlspecialchars($book['title']) ?>"
                             data-title="<?= htmlspecialchars($book['title']) ?>"
                             data-author="<?= htmlspecialchars($book['author']) ?>"
                             data-local="<?= preg_match('/^https?:\\/\\//', $book['cover']) ? '0' : '1' ?>">
                    </a>
                    <h3 class="bt-card__title"><a href="book.php?id=<?= $book['id'] ?>"><?= htmlspecialchars($book['title']) ?></a></h3>
                    <p class="bt-card__author"><?= htmlspecialchars($book['author']) ?></p>
                    <?php if (!empty($book['is_premium'])): ?>
                        <span class="premium-tag">Premium</span>
                    <?php endif; ?>
                    <div class="bt-card__meta">
                        <span>⭐ <?= $book['rating'] ?></span>
                        <span>👁 <?= $book['views'] ?></span>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        <button class="load-more" data-section="recommended" data-offset="<?= count($recommendedBooks) ?>">Load More</button>
    </section>

    <section class="bt-section" id="new-releases">
        <h2 class="bt-section__title">New Releases</h2>
        <div class="bt-grid" id="new-releases-grid">
            <?php foreach ($newBooks as $book): ?>
                <article class="bt-card">
                    <a class="bt-card__cover" href="book.php?id=<?= $book['id'] ?>">
                        <img src="<?= bt_cover_src($book['cover']) ?>" 
                             alt="<?= htmlspecialchars($book['title']) ?>"
                             data-title="<?= htmlspecialchars($book['title']) ?>"
                             data-author="<?= htmlspecialchars($book['author']) ?>"
                             data-local="<?= preg_match('/^https?:\\/\\//', $book['cover']) ? '0' : '1' ?>">
                    </a>
                    <h3 class="bt-card__title"><a href="book.php?id=<?= $book['id'] ?>"><?= htmlspecialchars($book['title']) ?></a></h3>
                    <p class="bt-card__author"><?= htmlspecialchars($book['author']) ?></p>
                    <?php if (!empty($book['is_premium'])): ?>
                        <span class="premium-tag">Premium</span>
                    <?php endif; ?>
                    <div class="bt-card__meta">
                        <span>⭐ <?= $book['rating'] ?></span>
                        <span>👁 <?= $book['views'] ?></span>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        <button class="load-more" data-section="new-releases" data-offset="<?= count($newBooks) ?>">Load More</button>
    </section>

    <section class="bt-section" id="popular">
        <h2 class="bt-section__title">Popular</h2>
        <div class="bt-grid" id="popular-grid">
            <?php foreach ($popularBooks as $book): ?>
                <article class="bt-card">
                    <a class="bt-card__cover" href="book.php?id=<?= $book['id'] ?>">
                        <img src="<?= bt_cover_src($book['cover']) ?>" 
                             alt="<?= htmlspecialchars($book['title']) ?>"
                             data-title="<?= htmlspecialchars($book['title']) ?>"
                             data-author="<?= htmlspecialchars($book['author']) ?>"
                             data-local="<?= preg_match('/^https?:\\/\\//', $book['cover']) ? '0' : '1' ?>">
                    </a>
                    <h3 class="bt-card__title"><a href="book.php?id=<?= $book['id'] ?>"><?= htmlspecialchars($book['title']) ?></a></h3>
                    <p class="bt-card__author"><?= htmlspecialchars($book['author']) ?></p>
                    <?php if (!empty($book['is_premium'])): ?>
                        <span class="premium-tag">Premium</span>
                    <?php endif; ?>
                    <div class="bt-card__meta">
                        <span>⭐ <?= $book['rating'] ?></span>
                        <span>👁 <?= $book['views'] ?></span>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        <button class="load-more" data-section="popular" data-offset="<?= count($popularBooks) ?>">Load More</button>
    </section>

    <section class="bt-section">
        <h2 class="bt-section__title">Premium</h2>
        <div class="bt-grid">
            <?php foreach ($premiumBooks as $book): ?>
                <article class="bt-card">
                    <a class="bt-card__cover" href="book.php?id=<?= $book['id'] ?>">
                        <img src="<?= !empty($book['cover']) ? bt_cover_src($book['cover']) : 'images/placeholder.png' ?>" 
                             alt="<?= htmlspecialchars($book['title']) ?>">
                    </a>
                    <h3 class="bt-card__title">
                        <a href="book.php?id=<?= $book['id'] ?>"><?= htmlspecialchars($book['title']) ?></a>
                    </h3>
                    <p class="bt-card__author"><?= htmlspecialchars($book['author']) ?></p>

                    <?php if (isset($book['premium']) && $book['premium'] == 1): ?>
                        <span class="premium-tag">Premium</span>
                    <?php endif; ?>

                    <div class="bt-card__meta">
                        <span>⭐ <?= $book['rating'] ?></span>
                        <span>👁 <?= $book['views'] ?></span>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

</main>
<script>
let currentSlide = 0;
const slides = document.querySelectorAll('.hero-slide');

function showSlide(index) {
    slides.forEach((slide, i) => slide.classList.toggle('active', i === index));
    currentSlide = index;
}

function moveSlide(direction) {
    let next = currentSlide + direction;
    if (next < 0) next = slides.length - 1;
    if (next >= slides.length) next = 0;
    showSlide(next);
}

setInterval(() => moveSlide(1), 5000);

document.getElementById('toggleSidebar').addEventListener('click', function() {
    document.getElementById('sidebar').classList.add('is-expanded');
    document.getElementById('mainContent').classList.add('is-shifted');
    document.getElementById('topbar').classList.add('is-shifted');
});
document.getElementById('closeSidebar').addEventListener('click', function() {
    document.getElementById('sidebar').classList.remove('is-expanded');
    document.getElementById('mainContent').classList.remove('is-shifted');
    document.getElementById('topbar').classList.remove('is-shifted');
});
document.getElementById('sidebarCloseInside').addEventListener('click', function() {
    document.getElementById('sidebar').classList.remove('is-expanded');
    document.getElementById('mainContent').classList.remove('is-shifted');
    document.getElementById('topbar').classList.remove('is-shifted');
});

// Open Library cover auto-fetch
(async function resolveCovers() {
  const imgs = document.querySelectorAll('img[data-title][data-author]');
  if (!imgs.length) return;
  const cache = new Map();
  const getCoverUrl = async (title, author) => {
    const key = (title + '|' + author).toLowerCase().trim();
    if (cache.has(key)) return cache.get(key);
    try {
      const q = new URLSearchParams({ title, author, limit: 1 });
      const res = await fetch(`https://openlibrary.org/search.json?${q.toString()}`);
      if (!res.ok) throw new Error('search failed');
      const data = await res.json();
      if (!data?.docs?.length) return cache.set(key, null), null;
      const doc = data.docs[0];
      let url = null;
      if (doc.cover_edition_key) {
        url = `https://covers.openlibrary.org/b/olid/${doc.cover_edition_key}-L.jpg`;
      } else if (doc.isbn?.length) {
        url = `https://covers.openlibrary.org/b/isbn/${doc.isbn[0]}-L.jpg`;
      } else if (typeof doc.cover_i === 'number') {
        url = `https://covers.openlibrary.org/b/id/${doc.cover_i}-L.jpg`;
      }
      cache.set(key, url);
      return url;
    } catch {
      cache.set(key, null);
      return null;
    }
  };
  for (const img of imgs) {
    const title = img.getAttribute('data-title') || '';
    const author = img.getAttribute('data-author') || '';
    const isLocal = img.getAttribute('data-local') === '1';
    if (!title || !author) continue;
    if (!img.src || isLocal) {
      const url = await getCoverUrl(title, author);
      if (url) img.src = url;
    }
  }
})();

// Load More functionality
document.querySelectorAll('.load-more').forEach(button => {
    button.addEventListener('click', async function() {
        const section = this.dataset.section;
        let offset = parseInt(this.dataset.offset, 10);
        const grid = document.getElementById(`${section}-grid`);

        const res = await fetch(`load_more.php?section=${section}&offset=${offset}`);
        const books = await res.json();

        if (!books.length) {
            this.style.display = "none";
            return;
        }

        books.forEach(book => {
            const card = document.createElement('article');
            card.className = 'bt-card';
            card.innerHTML = `
                <a class="bt-card__cover" href="book.php?id=${book.id}">
                    <img src="${book.cover && book.cover.startsWith('http') ? book.cover : 'covers/' + book.cover}" alt="${book.title}">
                </a>
                <h3 class="bt-card__title"><a href="book.php?id=${book.id}">${book.title}</a></h3>
                <p class="bt-card__author">${book.author}</p>
                ${book.is_premium ? '<span class="premium-tag">Premium</span>' : ''}
                <div class="bt-card__meta">
                    <span>⭐ ${book.rating}</span>
                    <span>👁 ${book.views}</span>
                </div>
            `;
            grid.appendChild(card);
        });

        this.dataset.offset = offset + books.length;
    });
});
</script>
</body>
</html>