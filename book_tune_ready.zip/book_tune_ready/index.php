<?php
session_start();
require_once "db.php";

$recommendedBooks = $pdo->query("SELECT * FROM books ORDER BY RAND() LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);
$newBooks = $pdo->query("SELECT * FROM books ORDER BY created_at DESC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);
$popularBooks = $pdo->query("SELECT * FROM books ORDER BY views DESC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Book-Tune</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
:root {
    --brand1: #b03060;
    --brand2: #cc4c78;
    --bg: #121212;
    --card: #1e1e1e;
    --text: #ffffff;
    --muted: #aaaaaa;
}
body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background: var(--bg);
    color: var(--text);
    display: flex;
}
.sidebar {
    width: 200px;
    background: #1a1a1a;
    padding: 20px;
    flex-shrink: 0;
}
.sidebar h1 {
    font-size: 1.3rem;
    margin-bottom: 20px;
    color: var(--brand2);
}
.sidebar a {
    display: block;
    color: var(--text);
    text-decoration: none;
    padding: 10px 8px;
    border-radius: 4px;
    margin-bottom: 6px;
}
.sidebar a:hover {
    background: var(--brand1);
}
.main-content {
    flex: 1;
    padding: 20px;
}
header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}
.search-bar {
    display: flex;
    background: rgba(255,255,255,0.1);
    border-radius: 50px;
    overflow: hidden;
}
.search-bar input {
    padding: 8px 12px;
    border: none;
    outline: none;
    background: transparent;
    color: white;
}
.search-bar button {
    background: var(--brand2);
    border: none;
    color: white;
    padding: 8px 14px;
    cursor: pointer;
}
.header-buttons a {
    text-decoration: none;
    color: white;
    padding: 6px 14px;
    background: rgba(255,255,255,0.1);
    border-radius: 50px;
    margin-left: 6px;
}
.header-buttons .go-premium {
    background: gold;
    color: black;
    font-weight: bold;
}
h2.section-title {
    margin: 25px 0 10px;
    border-left: 5px solid var(--brand1);
    padding-left: 10px;
}
.book-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    gap: 20px;
}
.book-card {
    background: var(--card);
    padding: 10px;
    border-radius: 8px;
    text-align: center;
    box-shadow: 0 2px 6px rgba(0,0,0,0.3);
    transition: transform .2s ease, box-shadow .2s ease;
}
.book-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.4);
}
.book-card img {
    width: 100%;
    height: 250px;
    object-fit: cover;
    border-radius: 6px;
    margin-bottom: 8px;
}
.book-card h3 {
    font-size: 0.95rem;
    margin: 6px 0 4px;
}
.book-card p.author {
    font-size: 0.8rem;
    color: var(--muted);
    margin: 0 0 6px;
}
.book-meta {
    font-size: 0.75rem;
    color: var(--muted);
    display: flex;
    justify-content: center;
    gap: 8px;
}
</style>
</head>
<body>
<div class="sidebar">
  <a href="popular.php">Popular</a>
<a href="new_releases.php">New Releases</a>
    <h1>Book-Tune</h1>
    <a href="index.php">Home</a>
    <a href="genres.php">Genres</a>
    <a href="#">Popular</a>
    <a href="#">New Releases</a>
    <a href="premium.php">Go Premium</a>
    <a href="upload.php">Upload Book</a>
</div>
<div class="main-content">
    <header>
        <form class="search-bar" method="GET" action="search.php">
            <input type="text" name="q" placeholder="Search books..." required>
            <button type="submit">Search</button>
        </form>
        <div class="header-buttons">
            <a href="login.php">Login</a>
            <a href="signup.php">Sign Up</a>
            <a href="premium.php" class="go-premium">Go Premium</a>
        </div>
    </header>

    <h2 class="section-title">Recommended</h2>
    <div class="book-grid">
        <?php foreach ($recommendedBooks as $book): ?>
        <div class="book-card">
            <a href="book.php?id=<?= $book['id'] ?>">
                <img src="covers/<?= htmlspecialchars($book['cover']) ?>">
            </a>
            <h3><?= htmlspecialchars($book['title']) ?></h3>
            <p class="author"><?= htmlspecialchars($book['author']) ?></p>
            <div class="book-meta">
                <span>⭐ <?= $book['rating'] ?></span>
                <span>👁 <?= $book['views'] ?></span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <h2 class="section-title">New Releases</h2>
    <div class="book-grid">
        <?php foreach ($newBooks as $book): ?>
        <div class="book-card">
            <a href="book.php?id=<?= $book['id'] ?>">
                <img src="covers/<?= htmlspecialchars($book['cover']) ?>">
            </a>
            <h3><?= htmlspecialchars($book['title']) ?></h3>
            <p class="author"><?= htmlspecialchars($book['author']) ?></p>
            <div class="book-meta">
                <span>⭐ <?= $book['rating'] ?></span>
                <span>👁 <?= $book['views'] ?></span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <h2 class="section-title">Popular</h2>
    <div class="book-grid">
        <?php foreach ($popularBooks as $book): ?>
        <div class="book-card">
            <a href="book.php?id=<?= $book['id'] ?>">
                <img src="covers/<?= htmlspecialchars($book['cover']) ?>">
            </a>
            <h3><?= htmlspecialchars($book['title']) ?></h3>
            <p class="author"><?= htmlspecialchars($book['author']) ?></p>
            <div class="book-meta">
                <span>⭐ <?= $book['rating'] ?></span>
                <span>👁 <?= $book['views'] ?></span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
</body>
</html>
